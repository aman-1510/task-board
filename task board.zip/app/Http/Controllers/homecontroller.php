<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\http\Requests;
use Illuminate\Http\Request;
use App\admin;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use Response;
use Validator;
use Mail;

class HomeController extends Controller
{   
	 use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
       /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    public function index()
    {
        return view('student_login');
    }
     public function home()
    {
        return view('board');
    }
   
       public function sign_up(Request $request){
        $otp = rand(100000, 999999);

          $where=['email'=>$request->email,'verified'=>'true','active'=>1];
           $count = 0;
           $count = admin::where($where)->count();
            $where1=['email'=>$request->email,'verified'=>'false','active'=>0];
           $count1 = 0;
           $count1 = admin::where($where1)->count();
           if ($count1>0) {
             $st = admin::where($where1)->delete();
           }
         
           if($count==0){
       $data = array('name'=>$request->name,'otp'=>$otp);
       $student = new admin();
       $student->email = $request->email;
       $student->password = Hash::make($request->password);
       $student->name = $request->name;
       $student->otp = $otp;
       $student->verified = 'false';
       $student->active = 0;
       $student->save();
      return Response::json($student->email);
                }
                else{ 
               return Response::json ( ['error' =>'email already registered'] );
                }
                 
      }

 public function otpcheck(Request $request){
           $count = 0;
           $where=['email'=>$request->email,'otp'=>$request->otp,'verified'=>'false','active'=>0];
           $count = admin::where($where)->count();
           if ($count>0) {
              $co = admin::where($where)->get();
              foreach ($co as $c) {
                $student = admin::find($c->id);
               $student->verified = 'true';
               $student->active = 1;
               $student->save();
               return response()->json($student->email);
              }
           }
           else{
               return Response::json ( ['error' =>'incorrect otp'] );
           }


 }

 public function updatepassword(Request $request){
           $count = 0;
           $where=['email'=>$request->email,'otp'=>$request->otp,'verified'=>'true','active'=>1];
           $count = admin::where($where)->count();
           if ($count>0) {
              $co = admin::where($where)->get();
              foreach ($co as $c) {
                $student = admin::find($c->id);
               $student->password = Hash::make($request->password);
               $student->save();
               return response()->json($student->email);
              }
           }
           else{
        
               return Response::json ( ['error' => 'incorrect otp'] );
           }

 }

 public function forgotpassword(Request $request){
           $otp = rand(100000, 999999);

          $where=['email'=>$request->email,'verified'=>'true','active'=>1];
           $count = 0;
           $count = admin::where($where)->count();
           if($count>0){
            $data = array('name'=>$request->name,'otp'=>$otp);
   
        $co = admin::where($where)->get();
              foreach ($co as $c) {
                $student = admin::find($c->id);
               $student->otp = $otp;
               $student->save();
               return response()->json($student->email);
              }
           }
                else{ 
               return Response::json ( ['error' => 'incorrect otp'] );
                }

 }
   

}
