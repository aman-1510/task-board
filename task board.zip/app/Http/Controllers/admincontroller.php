<?php
namespace App\Http\Controllers;
  use Validator;
  use Response;
  use File;
  use Storage;
  use disk;
  use Auth;
  use PDF;
  use Zip;
  use ZanySoft\Zip\ZipManager;
  use Illuminate\Support\Facades\Input;
  use Illuminate\Support\Facades\Hash;
  use App\http\Requests;
  use Illuminate\Http\Request;
  use App\admin;
  use App\board;
  use App\card;
  use App\checklist;
  use App\doc;
  use App\lable;
  use App\lists;
  use App\team;
  use Mail;

  
  class admincontroller extends Controller
  {
  	/**
       * Create a new controller instance.
       *
       * @return void
       */
      public function __construct()
      {
          $this->middleware('auth:admin');
      }
     public function index(Request $request){
      $team = team::where(['Uid'=>Auth::user()->id,'active'=>1])->get();
      $board = board::where(['Uid'=>Auth::user()->id,'active'=>1])->get();
      	return view('dashboard',compact('team','board'));
      }
     
public function addteam(Request $request){
           $count = 0;
           $where=['Tname'=>$request->teamname,'Uid'=>Auth::user()->id,'active'=>1];
           $count = team::where($where)->count();
           if ($count==0) {
               $team = new team();
              $team->Uid = Auth::user()->id; 
              $team->Aid = Auth::user()->id; 
              $team->Tname = $request->teamname; 
              $team->user_status = 'admin';
              $team->status = 'accepted';
              $team->members = 1;
              $team->active = 1;
               $team->save();

               $nteam = team::find($team->id);
                $nteam->Tid = $team->id; 
                $nteam->save();
               return response()->json($nteam);
           }
           else{
               return Response::json ( ['error' =>'team name exists'] );
           }
 }

public function addboard(Request $request){
  $dateinit = \Carbon\Carbon::parse($request->dateini);
    $datefim = \Carbon\Carbon::parse($request->datefim);

           $count = 0;
           $where=['title'=>$request->title,'Uid'=>Auth::user()->id,'active'=>1];
           $count = board::where($where)->count();
           if ($count==0) {
               $board = new board();
              $board->Uid = Auth::user()->id; 
              $board->Aid = Auth::user()->id; 
              $board->title = $request->title; 
              $board->Aname = Auth::user()->name;
              $board->Btype = 'Personal';
              $board->bg = '#61bd4f';
              $board->start_date = $dateinit->format('d/m/Y');
              $board->status = 'On going';
              $board->active = 1;
               $board->save();

               $nboard = board::find($board->id);
                $nboard->Bid = $board->id; 
                $nboard->save();
               return response()->json($nboard);
           }
           else{
               return Response::json ( ['error' =>'board name exists'] );
           }


 }




  }