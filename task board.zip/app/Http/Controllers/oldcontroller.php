<?php
namespace App\Http\Controllers;
  use Validator;
  use Response;
  use File;
  use Storage;
  use disk;
  use Auth;
  use PDF;
  use Zip;
  use ZanySoft\Zip\ZipManager;
  use Illuminate\Support\Facades\Input;
  use Illuminate\Support\Facades\Hash;
  use App\http\Requests;
  use Illuminate\Http\Request;
  use App\admin;
  use App\board;
  use App\card;
  use App\checklist;
  use App\doc;
  use App\lable;
  use App\list;
  use App\team;
  use Mail;

  
  class admincontroller extends Controller
  {
  	/**
       * Create a new controller instance.
       *
       * @return void
       */
      public function __construct()
      {
          $this->middleware('auth:admin');
      }
     public function index(){
      	return view('mail');
      }
      public function profile(){
          return view('admin.profile');
      }
      public function online_student(){
         $users = student::where('active','1')->get();
      return view('admin.online_student',compact('users'));
      }
       public function enquiries(){
       $users = enquiry::where('active','1')->get();
    return view('admin.enquiry',compact('users'));
    }
     public function enquiries_status(Request $request){
       $teacher = enquiry::find ($request->id);
       $teacher->status = $request->status;
       $teacher->save();
   return response()->json($teacher);
  }
       public function normalimage(Request $request){
          $where=['pid'=>$request->get('id'),'qtype'=>'normal',
        'active'=>'1'];
           $users = question::where($where)->orderBy('id','asc')->get();
          return view('layout.paperview',compact('users'));
       }
       public function advancedimage(Request $request){
          $where=['pid'=>$request->get('id'), 'qtype'=>'advanced',
        'active'=>'1'];
           $users = question::where($where)->orderBy('id','asc')->get();
          return view('layout.paperview',compact('users'));
       }

     //----------------------------------------------------------------
   public function teachers(Request $request){

        if($request->has('s')&&$request->get('s')!=''){
           $teachersearch = $request->get('s');
           $users = teacher::where('name', 'like', '%'.$teachersearch.'%')
           ->orWhere('username', 'like', '%'.$teachersearch.'%')
           ->orWhere('email', 'like', '%'.$teachersearch.'%')
           ->orWhere('mobile', 'like', '%'.$teachersearch.'%');
           $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
           return view('admin.teachers',compact('users'));
         }
         else{
          $users = teacher::where('active','1')->orderBy('id','desc')->paginate(7);
      return view('admin.teachers',compact('users'));
      }
      }
       public function teachers_page(Request $request){

        if($request->has('s')&&$request->get('s')!=''){
           $teachersearch = $request->get('s');
           $users = teacher::where('name', 'like', '%'.$teachersearch.'%')
           ->orWhere('username', 'like', '%'.$teachersearch.'%')
           ->orWhere('email', 'like', '%'.$teachersearch.'%')
           ->orWhere('mobile', 'like', '%'.$teachersearch.'%');
           $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
           return view('admin.teachers_reload',compact('users'));
         }
         else{
          $users = teacher::where('active','1')->orderBy('id','desc')->paginate(7);
      return view('admin.teachers_reload',compact('users'));
      }
      }
      public function addteacher(Request $request){
     $rules = array (
      'name' => 'required',
      'username' => 'required',
      'email' => 'required',
      'mobile' => 'required',
      'password' => 'required'
      ); 
    $validator = Validator::make ( Input::all (), $rules );
      if ($validator->fails ())
          return Response::json ( array ( 'errors' => $validator->getMessageBag ()->toArray ()) );
    else {
     
      $teacher = new teacher();
      $teacher->name = $request->name;
      $teacher->username = $request->username;
       $teacher->email = $request->email;
       $teacher->mobile = $request->mobile;
      $teacher->password = Hash::make($request->password);
       $teacher->active = '1';
      $teacher->save();
      return Response::json($teacher);
      }
  }

  public function editteacher(Request $request){
    $rules = array (
      'id' => 'required',
      'name' => 'required',
      'username' => 'required',
      'email' => 'required',
      'mobile' => 'required'
      ); 
    $validator = Validator::make ( Input::all (), $rules );
      if ($validator->fails ()){
          return Response::json ( array ( 'errors' => $validator->getMessageBag ()->toArray ()) );
   } else {
      if ($request->password !='') {
       $teacher = teacher::find($request->id);
      $teacher->username = $request->username;
       $teacher->password = Hash::make($request->password);
      $teacher->name = $request->name;
      $teacher->mobile = $request->mobile;
      $teacher->email = $request->email;
  $teacher->save();
  return response()->json($teacher);
      }
      else {
       $teacher = teacher::find($request->id);
      $teacher->username = $request->username;
      $teacher->name = $request->name;
      $teacher->mobile = $request->mobile;
      $teacher->email = $request->email;
  $teacher->save();
  return response()->json($teacher);
      }
  }
  }
  public function deleteteacher(Request $request){
  $teacher = teacher::find ($request->id);
  $teacher->active = '0';
      $teacher->save();
   return response()->json($teacher);
  }
      //....................................................
      public function students(Request $request){
         if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
         $users = student::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('username', 'like', '%'.$studentsearch.'%')
           ->orWhere('email', 'like', '%'.$studentsearch.'%')
           ->orWhere('mobile', 'like', '%'.$studentsearch.'%')
           ->orWhere('class', 'like', '%'.$studentsearch.'%')
           ->orWhere('course', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetype', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');

           if($request->has('class')&&$request->get('class')!=''){
            $where=['class'=>$request->get('class'),'active'=>'1'];
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);}
          else{$users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);}
             return view('admin.students',compact('users'));
          } 
          else{
             if($request->has('class')&&$request->get('class')!=''){
            $where=['class'=>$request->get('class'),'active'=>'1'];
         $users = student::where($where)->orderBy('id','desc')->paginate(7);}
          else{$users = student::where('active','1')->orderBy('id','desc')->paginate(7);}
            return view('admin.students',compact('users'));
        }
        }




       public function students_page(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
         $users = student::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('username', 'like', '%'.$studentsearch.'%')
           ->orWhere('email', 'like', '%'.$studentsearch.'%')
           ->orWhere('mobile', 'like', '%'.$studentsearch.'%')
           ->orWhere('class', 'like', '%'.$studentsearch.'%')
           ->orWhere('course', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetype', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');

           if($request->has('class')&&$request->get('class')!=''){
            $where=['class'=>$request->get('class'),'active'=>'1'];
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);}
          else{$users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);}
             return view('admin.students_reload',compact('users'));
          } 
          else{
             if($request->has('class')&&$request->get('class')!=''){
            $where=['class'=>$request->get('class'),'active'=>'1'];
         $users = student::where($where)->orderBy('id','desc')->paginate(7);}
          else{$users = student::where('active','1')->orderBy('id','desc')->paginate(7);}
            return view('admin.students_reload',compact('users'));
        }
        }
     
      
     
      //...................................................
      public function createpaper(){
          return view('admin.create_paper');
      }



      public function normalpaperupload(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
          $studentsearch = $request->get('s');
         $users = normal_paper::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('created_at', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
      return view('admin.normal_paper_upload_list',compact('users'));
          } 
        else{
          $users = normal_paper::where('active','1')->orderBy('id','desc')->paginate(7);
          return view('admin.normal_paper_upload_list',compact('users'));}
      }

      public function normalpaperupload_page(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
          $studentsearch = $request->get('s');
         $users = normal_paper::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('created_at', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
      return view('admin.normal_paper_upload_list_reload',compact('users'));
          } 
        else{
          $users = normal_paper::where('active','1')->orderBy('id','desc')->paginate(7);
          return view('admin.normal_paper_upload_list_reload',compact('users'));}
      }
       public function normalpaperquesupload(Request $request){
           $where=['pid'=>$request->get('id'),'qtype'=>'normal',
        'active'=>'1'];
        $where1=['pid'=>$request->get('id'),'qtype'=>'normal','quesimg'=>NULL,
        'active'=>'1'];
        $where2=['pid'=>$request->get('id'),'qtype'=>'normal','solimg'=>NULL,
        'active'=>'1'];
          $w = question::where($where)->count();
          $w1 = question::where($where1)->count();
          $w2 = question::where($where2)->count();
          $question=$w-$w1;
          $solution=$w-$w2;
          return view('admin.nr_ques_upload',compact('question','solution'));
      }
       public function normalpaperansupload(Request $request){
          $where=['pid'=>$request->id,'qtype'=>'normal',
        'active'=>'1'];
          $users = question::where($where)->orderBy('id','asc')->get();
          return view('admin.nr_ans_upload',compact('users'));
      }
       public function normalpaperpublish(Request $request){
          $where=['id'=>$request->get('id'),
        'active'=>'1'];
          $users = normal_paper::where($where)->get();
          return view('admin.nr_publish',compact('users'));
      }
  public function normalpaperquesuploadsubmit(Request $request)
      {$where=['id'=>$request->id,
        'active'=>'1'];
          $users = normal_paper::where($where)->select('pname')->get();
          foreach ($users as $user) {
           $pname=$user->pname;
            }
          $this->validate($request, [
                  'filenames' => 'required'
          ]);
          if($request->hasfile('filenames'))
           {
              foreach($request->file('filenames') as $file)
              {
                  $name=$file->getClientOriginalName();
                  $file_name = pathinfo($name, PATHINFO_FILENAME);
                  $path=base_path().'/public_html/Quiz/normal_paper/'.$pname.'/question';
                  $file->move($path,$name); 
                  $qpqtypeid=$file_name."X".$request->id."X".'normal'; 
                       $img='Quiz/normal_paper/'.$pname.'/question/'.$name;
                        $filea= question::where('qpqtypeid',$qpqtypeid)->update(['quesimg' => $img]);
              }
           }
          return back()->with('success', 'uploaded Successfully');
      }
   public function normalpapersoluploadsubmit(Request $request)
      {$where=['id'=>$request->id,
        'active'=>'1'];
          $users = normal_paper::where($where)->select('pname')->get();
          foreach ($users as $user) {
           $pname=$user->pname;
            }
          $this->validate($request, [
                  'filenames' => 'required'
          ]);
          if($request->hasfile('filenames'))
           {
              foreach($request->file('filenames') as $file)
              {
                  $name=$file->getClientOriginalName();
                  $file_name = pathinfo($name, PATHINFO_FILENAME);
                  $path=base_path().'/public_html/Quiz/normal_paper/'.$pname.'/solution';
                  $file->move($path,$name); 
                  $qpqtypeid=$file_name."X".$request->id."X".'normal'; 
                       $img='Quiz/normal_paper/'.$pname.'/solution/'.$name;
                        $filea= question::where('qpqtypeid',$qpqtypeid)->update(['solimg' => $img]); 
              }
           }
          return back()->with('success', 'uploaded Successfully');
      }



  public function normalpaperupdateresultpage(Request $request){
          $where=['pid'=>$request->get('id'),'qtype'=>'normal','active'=>'1'];
          $users = question::where($where)->orderBy('id','asc')->get();
          return view('admin.nr_ans_upload_updates',compact('users'));
      }

  public function normalpaperupdateresult(Request $request){
          $where=['pid'=>$request->pid,'type'=>'normal'];
          $where1=['qpqtypeid'=>$request->id."X".$request->pid."X".'normal','active'=>'1'];
           $pname =""; $PQ =""; $PM =""; $PN =""; $CQ =""; $CM =""; $CN =""; $MQ =""; $MM =""; $MN =""; $BQ =""; $BM =""; $BN =""; $TT="";$NOQ="";
       $where2=['id'=>$request->pid,'active'=>'1'];
        $papers = normal_paper::where($where2)->get();
        foreach ($papers as $paper) {
          $pname =$paper->pname; $PQ =$paper->PQ; $PM =$paper->PM; $PN =$paper->PN; $CQ =$paper->CQ; $CM =$paper->CM; $CN =$paper->CN; $MQ =$paper->MQ; $MM =$paper->MM; $MN =$paper->MN; $BQ =$paper->BQ; $BM =$paper->BM; $BN =$paper->BN; $TT=$paper->TT;$NOQ=$paper->NOQ; $total_marks=$paper->total_marks;
        }
        $PQN = $PQ; $CQN = $PQ + $CQ; $MQN = $PQ + $CQ + $MQ; $BQN = $PQ + $CQ + $MQ + $BQ;
         $questions = question::where($where1)->select('q1')->get();
          $users = paper_link::where($where)->get();
          foreach ($users as $user) {
             $where3=['pid'=>$request->pid,'qid'=>$request->id,'plid'=>$user->id,'active'=>'1'];
             foreach ($questions as $ques) {
                $q7=$ques->q1;
                $answer=answer::where($where3)->get();
                foreach ($answer as $anse) {
                 if ($ques->q1==$anse->a1) {
            $q2='Correct';
             $answerq = answer::find($anse->id)->update(['a7'=>$ques->q1,'answer'=>$q2]);
            
            }else{
              $q2='Incorrect';
               $answerq = answer::find($anse->id)->update(['a7'=>$ques->q1,'answer'=>$q2]);
                
            }
         $results=result::where(['plid'=>$user->id,'sid'=>$anse->sid])->get();
         foreach ($results as $res) {
            $where4=['pplsid'=>$request->pid."X".$user->id."X".$anse->sid,'active'=>'1'];
        $answers = answer::where($where4)->get();
        $no =0; $MinP=0; $CinP=0; $WinP=0; $MinC=0; $CinC=0; $WinC=0; $MinM=0; $CinM=0; $WinM=0; $MinB=0; $CinB=0; $WinB=0;
        foreach ($answers as $ans) {
          if($ans->qid<= $PQN){
            if (($ans->a1==$ans->a7 && $ans->a8=="save") || ($ans->a1==$ans->a7 && $ans->a8=="save_mark")) {
             $MinP = $MinP + $PM;
             $CinP++;
            }
            else if (($ans->a1!=$ans->a7 && $ans->a8=="save") || ($ans->a1!=$ans->a7 && $ans->a8=="save_mark")){
               $MinP = $MinP - $PN;
               $WinP++;
            }
          }
          else if($ans->qid<= $CQN && $ans->qid >$PQN){
            if (($ans->a1==$ans->a7 && $ans->a8=="save") || ($ans->a1==$ans->a7 && $ans->a8=="save_mark")) {
             $MinC = $MinC + $CM;
             $CinC++;
            }
            else if (($ans->a1!=$ans->a7 && $ans->a8=="save") || ($ans->a1!=$ans->a7 && $ans->a8=="save_mark")){
               $MinC = $MinC - $CN;
               $WinC++;
            }
          }
          else if($ans->qid<= $MQN && $ans->qid >$CQN){
            if (($ans->a1==$ans->a7 && $ans->a8=="save") || ($ans->a1==$ans->a7 && $ans->a8=="save_mark")) {
             $MinM = $MinM + $MM;
             $CinM++;
            }
            else if (($ans->a1!=$ans->a7 && $ans->a8=="save") || ($ans->a1!=$ans->a7 && $ans->a8=="save_mark")){
               $MinM = $MinM - $MN;
               $WinM++;
            }
          }
         else if($ans->qid<= $BQN && $ans->qid >$MQN){
            if (($ans->a1==$ans->a7 && $ans->a8=="save") || ($ans->a1==$ans->a7 && $ans->a8=="save_mark")) {
             $MinB = $MinB + $BM;
             $CinB++;
            }
            else if (($ans->a1!=$ans->a7 && $ans->a8=="save") || ($ans->a1!=$ans->a7 && $ans->a8=="save_mark")){
               $MinB = $MinB - $BN;
               $WinB++;
            }
          }
         
        }
         $totalS= $MinP +  $MinC + $MinM + $MinB;
           $totalQ = $NOQ;
           $totalC = $CinP + $CinC + $CinM + $CinB;
           $totalW = $WinP + $WinC + $WinM + $WinB;
            $totalA= $totalC + $totalW;

          $result = result::find($res->id);
              $result->type='normal';
              $result->totalQ=$totalQ;
             $result->totalA=$totalA;
             $result->totalC=$totalC;
             $result->totalW=$totalW;
              $result->totalS=$totalS;
             $result->totalCinP=$CinP;
             $result->totalWinP=$WinP;
             $result->totalSinP=$MinP;
              $result->totalCinC=$CinC;
             $result->totalWinC=$WinC;
             $result->totalSinC=$MinC;
              $result->totalCinM=$CinM;
             $result->totalWinM=$WinM;
             $result->totalSinM=$MinM;
              $result->totalCinB=$CinB;
             $result->totalWinB=$WinB;
             $result->totalSinB=$MinB;
               $result->save();
         }
         }
         }
         }
  return response()->json($users);
         
      }








  public function advancedpaperupdateresultpage(Request $request){
          $where=['pid'=>$request->get('id'),'qtype'=>'advanced','active'=>'1'];
          $users = question::where($where)->orderBy('id','asc')->get();
          return view('admin.adv_ans_upload_updates',compact('users'));
      }

  public function advancedpaperupdateresult(Request $request){
          $where=['pid'=>$request->pid,'type'=>'advanced'];
          $where1=['qpqtypeid'=>$request->id."X".$request->pid."X".'advanced','active'=>'1'];  $q2="";
          $users = paper_link::where($where)->get();
         $questions = question::where($where1)->get();
       foreach ($users as $user) {
         $where3=['pid'=>$request->pid,'qid'=>$request->id,'plid'=>$user->id,'active'=>'1'];
           foreach ($questions as $ques) {
                $q7=$ques->q1;
                $answer=answer::where($where3)->get();
                foreach ($answer as $anse) {
                $a5=$ques->q1; $a6=$ques->q2; $a7=$ques->q3; $a8=$ques->q4;
                if($ques->type=='single'||$ques->type=='integer'||$ques->type=='passage'||$ques->type=='match_column'){
                 if ($a5==$anse->a1) {
                  $q2='Correct';
                  $answerq = answer::find($anse->id)->update(['a5'=>$a5,'a6'=>$a6,'a7'=>$a7,'a8'=>$a8,'answer'=>$q2]);
               }else{
                   $q2='Incorrect';
                   $answerq = answer::find($anse->id)->update(['a5'=>$a5,'a6'=>$a6,'a7'=>$a7,'a8'=>$a8,'answer'=>$q2]);
                }
          }
           elseif($ques->type=='multiple'){
                 if ($a5==$anse->a1&&$a6==$anse->a2&&$a7==$anse->a3&&$a8==$anse->a4) {
                  $q2='Correct';
                  $answerq = answer::find($anse->id)->update(['a5'=>$a5,'a6'=>$a6,'a7'=>$a7,'a8'=>$a8,'answer'=>$q2]);
               }elseif(($a5!=$anse->a1&&$anse->a1!='')||($a6!=$anse->a2&&$anse->a2!='')||($a7!=$anse->a3&&$anse->a3!='')||($a8!=$anse->a4&&$anse->a4!='')){
                   $q2='Incorrect';
                   $answerq = answer::find($anse->id)->update(['a5'=>$a5,'a6'=>$a6,'a7'=>$a7,'a8'=>$a8,'answer'=>$q2]);
                }else{
                   $q2='Partially Correct';
                   $answerq = answer::find($anse->id)->update(['a5'=>$a5,'a6'=>$a6,'a7'=>$a7,'a8'=>$a8,'answer'=>$q2]);
                }
          }
          elseif($ques->type=='numerical'){
                 if ($a5<= $anse->a1 && $a6 >= $anse->a1) {
                  $q2='Correct';
                  $answerq = answer::find($anse->id)->update(['a5'=>$a5,'a6'=>$a6,'a7'=>$a7,'a8'=>$a8,'answer'=>$q2]);
               }else{
                   $q2='Incorrect';
                   $answerq = answer::find($anse->id)->update(['a5'=>$a5,'a6'=>$a6,'a7'=>$a7,'a8'=>$a8,'answer'=>$q2]);
                }
          }
           $results=result::where(['plid'=>$user->id,'sid'=>$anse->sid])->get();
         foreach ($results as $res) {
      $P1Q =""; $P1M =""; $P1N =""; $P2Q =""; $P2M =""; $P2N =""; $P3Q =""; $P3M =""; $P3N =""; $P4Q =""; $P4M =""; $P4N =""; $P5Q =""; $P5M =""; $P5N =""; $P6Q =""; $P6M =""; $P6N =""; $C1Q =""; $C1M =""; $C1N =""; $C2Q =""; $C2M =""; $C2N =""; $C3Q =""; $C3M =""; $C3N =""; $C4Q =""; $C4M =""; $C4N =""; $C5Q =""; $C5M =""; $C5N =""; $C6Q =""; $C6M =""; $C6N =""; $M1Q =""; $M1M =""; $M1N =""; $M2Q =""; $M2M =""; $M2N =""; $M3Q =""; $M3M =""; $M3N =""; $M4Q =""; $M4M =""; $M4N =""; $M5Q =""; $M5M =""; $M5N =""; $M6Q =""; $M6M =""; $M6N ="";
       $where=['id'=>$request->pid,'active'=>'1'];
        $papers = advance_paper::where($where)->get();
        foreach ($papers as $paper) {
           $P1Q = $paper->P1Q; $P1M = $paper->P1M; $P1N = $paper->P1N; $P2Q = $paper->P2Q; $P2M = $paper->P2M; $P2N = $paper->P2N; $P3Q = $paper->P3Q; $P3M = $paper->P3M; $P3N = $paper->P3N; $P4Q = $paper->P4Q; $P4M = $paper->P4M; $P4N = $paper->P4N; $P5Q = $paper->P5Q; $P5M = $paper->P5M; $P5N = $paper->P5N; $P6Q = $paper->P6Q; $P6M = $paper->P6M; $P6N = $paper->P6N; $C1Q = $paper->C1Q; $C1M = $paper->C1M; $C1N = $paper->C1N; $C2Q = $paper->C2Q; $C2M = $paper->C2M; $C2N = $paper->C2N; $C3Q = $paper->C3Q; $C3M = $paper->C3M; $C3N = $paper->C3N; $C4Q = $paper->C4Q; $C4M = $paper->C4M; $C4N = $paper->C4N; $C5Q = $paper->C5Q; $C5M = $paper->C5M; $C5N = $paper->C5N; $C6Q = $paper->C6Q; $C6M = $paper->C6M; $C6N = $paper->C6N; $M1Q = $paper->M1Q; $M1M = $paper->M1M; $M1N = $paper->M1N; $M2Q = $paper->M2Q; $M2M = $paper->M2M; $M2N = $paper->M2N; $M3Q = $paper->M3Q; $M3M = $paper->M3M; $M3N = $paper->M3N; $M4Q = $paper->M4Q; $M4M = $paper->M4M; $M4N = $paper->M4N; $M5Q = $paper->M5Q; $M5M = $paper->M5M; $M5N = $paper->M5N; $M6Q = $paper->M6Q; $M6M = $paper->M6M; $M6N = $paper->M6N;
        }
         $PQN = $P1Q + $P2Q  + $P3Q  + $P4Q  + $P5Q  + $P6Q;
         $PQN1 = $P1Q + $P2Q  + $P3Q  + $P4Q;
         $PQN2 = $P1Q + $P2Q  + $P3Q  + $P4Q  + $P5Q;
         $PQN3 = $P1Q;
         $PQN4= $P1Q + $P2Q;
         $PQN5 = $P1Q + $P2Q  + $P3Q;
         $CQN = $PQN + $C1Q + $C2Q  + $C3Q  + $C4Q  + $C5Q  + $C6Q;
         $CQN1 = $PQN + $C1Q + $C2Q  + $C3Q  + $C4Q;
         $CQN2 =$PQN + $C1Q + $C2Q  + $C3Q  + $C4Q  + $C5Q;
         $CQN3 = $PQN + $C1Q;
         $CQN4 = $PQN + $C1Q + $C2Q;
         $CQN5 = $PQN + $C1Q + $C2Q  + $C3Q;
         $MQN = $CQN + $M1Q + $M2Q  + $M3Q  + $M4Q  + $M5Q  + $M6Q;
         $MQN1 = $CQN + $M1Q + $M2Q  + $M3Q  + $M4Q;
         $MQN2 = $CQN + $M1Q + $M2Q  + $M3Q  + $M4Q  + $M5Q;
         $MQN3 = $CQN + $M1Q;
         $MQN4 = $CQN + $M1Q + $M2Q;
         $MQN5 = $CQN + $M1Q + $M2Q  + $M3Q;

          $where4=['pplsid'=>$request->pid."X".$user->id."X".$anse->sid,'active'=>'1'];
        $answers = answer::where($where4)->get();

        $no =0; $MinP=0; $CinP=0; $WinP=0; $MinC=0; $CinC=0; $WinC=0; $MinM=0; $CinM=0; $WinM=0;
       $bmw=1;
        foreach ($answers as $ans) {
          if($ans->qtype=='single'||$ans->qtype=='passage'||$ans->qtype=='match_column'){
           if($ans->qid<=$PQN){
             if($ans->qid<= $P1Q){
            if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinP = $MinP + $P1M;
             $CinP++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinP = $MinP - $P1N;
               $WinP++;
            }
          }
          else if($ans->qid<= $PQN2 && $ans->qid > $PQN1){
            if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinP = $MinP + $P5M;
             $CinP++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinP = $MinP - $P5N;
               $WinP++;
            }
          }
           else if($ans->qid<= $PQN && $ans->qid > $PQN2){
            if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinP = $MinP + $P6M;
             $CinP++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinP = $MinP - $P6N;
               $WinP++;
            }
          }
           }


           elseif($ans->qid>$PQN && $ans->qid<=$CQN){
             if($ans->qid<= $CQN3){
            if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinC = $MinC + $C1M;
             $CinC++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinC = $MinC - $C1N;
               $WinC++;
            }
          }
          else if($ans->qid<= $CQN2 && $ans->qid > $CQN1){
            if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinC = $MinC + $C5M;
             $CinC++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinC = $MinC - $C5N;
               $WinC++;
            }
          }
           else if($ans->qid<= $CQN && $ans->qid > $CQN2){
            if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinC = $MinC + $C6M;
             $CinC++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinC = $MinC - $C6N;
               $WinC++;
            }
          }
           }
         

          elseif($ans->qid>$CQN && $ans->qid<=$MQN){
             if($ans->qid<= $MQN3){
            if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinM = $MinM + $M1M;
             $CinM++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinM = $MinM - $M1N;
               $WinM++;
            }
          }
          else if($ans->qid<= $MQN2 && $ans->qid > $MQN1){
            if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinM = $MinM + $M5M;
             $CinM++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinM = $MinM - $M5N;
               $WinM++;
            }
          }
           else if($ans->qid<= $MQN && $ans->qid > $MQN2){
            if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinM = $MinM + $M6M;
             $CinM++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinM = $MinM - $M6N;
               $WinM++;
            }
          }
           }

          }
          elseif ($ans->qtype=='multiple') {
           if($ans->qid<=$PQN4&&$ans->qid>$PQN3){
            if (($ans->a1==$ans->a5 && $ans->a2==$ans->a6 && $ans->a3==$ans->a7 && $ans->a4==$ans->a8 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->a2==$ans->a6 && $ans->a3==$ans->a7 && $ans->a4==$ans->a8 && $ans->ans_type=="save_mark")) {
             $MinP = $MinP + $P2M;
             $CinP++;
            }
            elseif((($ans->a1!=$ans->a5 && $ans->a1!="")||($ans->a2!=$ans->a6 && $ans->a2!="")||($ans->a3!=$ans->a7 && $ans->a3!="")||($ans->a4!=$ans->a8 && $ans->a4!="")) && ($ans->ans_type=="save"||$ans->ans_type=="save_mark")){
               $MinP = $MinP - $P2N;
               $WinP++;
            }
            else{if($ans->a1==$ans->a5&&$ans->a1!=""){$MinP = $MinP + 1;}if($ans->a2==$ans->a6&&$ans->a2!=""){$MinP = $MinP + 1;}if($ans->a3==$ans->a7&&$ans->a3!=""){$MinP = $MinP + 1;}if($ans->a4==$ans->a8&&$ans->a4!=""){$MinP = $MinP + 1;}$CinP++;}
           }


           elseif($ans->qid<=$CQN4&&$ans->qid>$CQN3){
            if (($ans->a1==$ans->a5 && $ans->a2==$ans->a6 && $ans->a3==$ans->a7 && $ans->a4==$ans->a8 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->a2==$ans->a6 && $ans->a3==$ans->a7 && $ans->a4==$ans->a8 && $ans->ans_type=="save_mark")) {
             $MinC = $MinC + $C2M;
             $CinC++;
            }
            elseif((($ans->a1!=$ans->a5 && $ans->a1!="")||($ans->a2!=$ans->a6 && $ans->a2!="")||($ans->a3!=$ans->a7 && $ans->a3!="")||($ans->a4!=$ans->a8 && $ans->a4!="")) && ($ans->ans_type=="save"||$ans->ans_type=="save_mark")){
               $MinC = $MinC - $C2N;
               $WinC++;
            }
            else{if($ans->a1==$ans->a5&&$ans->a1!=""){$MinC = $MinC + 1;}if($ans->a2==$ans->a6&&$ans->a2!=""){$MinC = $MinC + 1;}if($ans->a3==$ans->a7&&$ans->a3!=""){$MinC = $MinC + 1;}if($ans->a4==$ans->a8&&$ans->a4!=""){$MinC = $MinC + 1;}$CinC++;}
           }


           elseif($ans->qid<=$MQN4&&$ans->qid>$MQN3){
            if (($ans->a1==$ans->a5 && $ans->a2==$ans->a6 && $ans->a3==$ans->a7 && $ans->a4==$ans->a8 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->a2==$ans->a6 && $ans->a3==$ans->a7 && $ans->a4==$ans->a8 && $ans->ans_type=="save_mark")) {
             $MinM = $MinM + $M2M;
             $CinM++;
            }
            elseif((($ans->a1!=$ans->a5 && $ans->a1!="")||($ans->a2!=$ans->a6 && $ans->a2!="")||($ans->a3!=$ans->a7 && $ans->a3!="")||($ans->a4!=$ans->a8 && $ans->a4!="")) && ($ans->ans_type=="save"||$ans->ans_type=="save_mark")){
               $MinM = $MinM - $M2N;
               $WinM++;
            }
            else{if($ans->a1==$ans->a5&&$ans->a1!=""){$MinM = $MinM + 1;}if($ans->a2==$ans->a6&&$ans->a2!=""){$MinM = $MinM + 1;}if($ans->a3==$ans->a7&&$ans->a3!=""){$MinM = $MinM + 1;}if($ans->a4==$ans->a8&&$ans->a4!=""){$MinM = $MinM + 1;}$CinM++;}
           }
          }
          elseif ($ans->qtype=='integer') {
            if($ans->qid<=$PQN5&&$ans->qid>$PQN4){
              if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinP = $MinP + $P3M;
             $CinP++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinP = $MinP - $P3N;
               $WinP++;
            }
            }
            elseif($ans->qid<=$CQN5&&$ans->qid>$CQN4){
              if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinC = $MinC + $C3M;
             $CinC++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinC = $MinC - $C3N;
               $WinC++;
            }
            }
            elseif($ans->qid<=$MQN5&&$ans->qid>$MQN4){
              if (($ans->a1==$ans->a5 && $ans->ans_type=="save") || ($ans->a1==$ans->a5 && $ans->ans_type=="save_mark")) {
             $MinM = $MinM + $M3M;
             $CinM++;
            }
            else if (($ans->a1!=$ans->a5 && $ans->ans_type=="save") || ($ans->a1!=$ans->a5 && $ans->ans_type=="save_mark")){
               $MinM = $MinM - $M3N;
               $WinM++;
            }
            }

          }
          elseif ($ans->qtype=='numerical') {
           if($ans->qid<=$PQN1&&$ans->qid>$PQN5){
              if (($ans->a1>=$ans->a5 && $ans->a1<=$ans->a6 && $ans->ans_type=="save") || ($ans->a1>=$ans->a5 && $ans->a1<=$ans->a6 && $ans->ans_type=="save_mark")) {
             $MinP = $MinP + $P4M;
             $CinP++;
            }
            else if ((($ans->a1<$ans->a5||$ans->a1>$ans->a6) && $ans->ans_type=="save") || (($ans->a1<$ans->a5||$ans->a1>$ans->a6) && $ans->ans_type=="save_mark")){
               $MinP = $MinP - $P4N;
               $WinP++;
            }
            }
            elseif($ans->qid<=$CQN1&&$ans->qid>$CQN5){
              if (($ans->a1>=$ans->a5 && $ans->a1<=$ans->a6 && $ans->ans_type=="save") || ($ans->a1>=$ans->a5 && $ans->a1<=$ans->a6 && $ans->ans_type=="save_mark")) {
             $MinC = $MinC + $C4M;
             $CinC++;
            }
            else if ((($ans->a1<$ans->a5||$ans->a1>$ans->a6) && $ans->ans_type=="save") || (($ans->a1<$ans->a5||$ans->a1>$ans->a6) && $ans->ans_type=="save_mark")){
               $MinC = $MinC - $C4N;
               $WinC++;
            }
            }
            elseif($ans->qid<=$MQN1&&$ans->qid>$MQN5){
              if (($ans->a1>=$ans->a5 && $ans->a1<=$ans->a6 && $ans->ans_type=="save") || ($ans->a1>=$ans->a5 && $ans->a1<=$ans->a6 && $ans->ans_type=="save_mark")) {
             $MinM = $MinM + $M4M;
             $CinM++;
            }
            else if ((($ans->a1<$ans->a5||$ans->a1>$ans->a6) && $ans->ans_type=="save") || (($ans->a1<$ans->a5||$ans->a1>$ans->a6) && $ans->ans_type=="save_mark")){
               $MinM = $MinM - $M4N;
               $WinM++;
            }
            }
          }
          
        }
         $totalS= $MinP +  $MinC + $MinM;
           $totalC = $CinP + $CinC + $CinM;
           $totalW = $WinP + $WinC + $WinM;
            $totalA= $totalC + $totalW;
          $result =  result::find($res->id);  
          $result->type='advanced';
             $result->totalA=$totalA;
             $result->totalC=$totalC;
             $result->totalW=$totalW;
              $result->totalS=$totalS;
             $result->totalCinP=$CinP;
             $result->totalWinP=$WinP;
             $result->totalSinP=$MinP;
              $result->totalCinC=$CinC;
             $result->totalWinC=$WinC;
             $result->totalSinC=$MinC;
              $result->totalCinM=$CinM;
             $result->totalWinM=$WinM;
             $result->totalSinM=$MinM;
               $result->save();

         }
         }
         }
         }
       return response()->json($result);
      }


       public function normalpaperansuploadsubmit(Request $request){
          $where=['qpqtypeid'=>$request->qpqtypeid,
        'active'=>'1'];
          $users = question::where($where)->update(['q1' => $request->q1]); 
          return response()->json($users);
      }
       public function normalpaperpublishsubmit(Request $request){
           $this->validate($request, [
                  'class' => 'required',
                  'course' => 'required',
                  'coursetype' => 'required',
                  'publishtime' => 'required',
                  'radio' => 'required',
                  'radio1' => 'required',
                  'pname' => 'required',
                  'plink' => 'required',
                  'pid' => 'required',
                  'hardness' => 'required'
          ]);
                  $file= new paper_link();
                  $file->pid=$request->pid;
                  $file->classid=$request->class;
                  $file->courseid=$request->course;
                  $file->coursetypeid=$request->coursetype;
                  $file->groupid=$request->radio;
                  $file->cccgid=$request->class.$request->course.$request->coursetype.$request->radio;
                  $file->paper=$request->pname;
                  $file->plink=$request->plink;
                  $file->hardness=$request->hardness;
                  $file->rank=$request->radio1;
                  $file->publishtime=$request->publishtime;
                  $file->type='normal'; 
                  $file->active=1;
                  $file->save();
                  return back()->with('success', 'uploaded Successfully');
      }

















        public function advancedpaperupload(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
          $studentsearch = $request->get('s');
         $users = advance_paper::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('created_at', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
      return view('admin.advanced_paper_upload_list',compact('users'));
          } 
        else{
          $users = advance_paper::where('active','1')->orderBy('id','desc')->paginate(7);
          return view('admin.advanced_paper_upload_list',compact('users'));}
      }

      public function advancedpaperupload_page(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
          $studentsearch = $request->get('s');
         $users = advance_paper::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('created_at', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
      return view('admin.advanced_paper_upload_list_reload',compact('users'));
          } 
        else{
          $users = advance_paper::where('active','1')->orderBy('id','desc')->paginate(7);
          return view('admin.advanced_paper_upload_list_reload',compact('users'));}
      }
      public function advancedpaperquesupload(Request $request){
          $where=['pid'=>$request->get('id'),'qtype'=>'advanced',
        'active'=>'1'];
        $where1=['pid'=>$request->get('id'),'qtype'=>'advanced','quesimg'=>NULL,
        'active'=>'1'];
        $where2=['pid'=>$request->get('id'),'qtype'=>'advanced','solimg'=>NULL,
        'active'=>'1'];
          $w = question::where($where)->count();
          $w1 = question::where($where1)->count();
          $w2 = question::where($where2)->count();
          $question=$w-$w1;
          $solution=$w-$w2;
          return view('admin.adv_ques_upload',compact('question','solution'));
      }


      public function advancedpaperansupload(Request $request){
          $where=['pid'=>$request->get('id'),'qtype'=>'advanced',
        'active'=>'1'];
          $users = question::where($where)->orderBy('id','asc')->get();
          return view('admin.adv_ans_upload',compact('users'));
      }
      public function advancedpaperpublish(Request $request){
          $where=['id'=>$request->get('id'),
        'active'=>'1'];
          $users = advance_paper::where($where)->get();
          return view('admin.adv_publish',compact('users'));
      }
      public function advancedpaperquesuploadsubmit(Request $request)
      {$where=['id'=>$request->id,
        'active'=>'1'];
          $users = advance_paper::where($where)->select('pname')->get();
          foreach ($users as $user) {
           $pname=$user->pname;
            }
          $this->validate($request, [
                  'filenames' => 'required'
                
          ]);
          if($request->hasfile('filenames'))
           {
              foreach($request->file('filenames') as $file)
              {
                  $name=$file->getClientOriginalName();
                  $file_name = pathinfo($name, PATHINFO_FILENAME);
                  $path=base_path().'/public_html/Quiz/advanced_paper/'.$pname.'/question';
                  $file->move($path,$name);  
                 $qpqtypeid=$file_name."X".$request->id."X".'advanced'; 
                       $img='Quiz/advanced_paper/'.$pname.'/question/'.$name;
                       if($name!='syllabus.png'){
                        $filea= question::where('qpqtypeid',$qpqtypeid)->update(['quesimg' => $img]);
                      }
              }
           }
          return back()->with('success', 'uploaded Successfully');
      }
   public function advancedpapersoluploadsubmit(Request $request)
      {$where=['id'=>$request->id,
        'active'=>'1'];
          $users = advance_paper::where($where)->select('pname')->get();
          foreach ($users as $user) {
           $pname=$user->pname;
            }
          $this->validate($request, [
                  'filenames' => 'required'
          ]);
          if($request->hasfile('filenames'))
           {
              foreach($request->file('filenames') as $file)
              {
                  $name=$file->getClientOriginalName();
                  $file_name = pathinfo($name, PATHINFO_FILENAME);
                  $path=base_path().'/public_html/Quiz/advanced_paper/'.$pname.'/solution';
                  $file->move($path,$name); 
                  $qpqtypeid=$file_name."X".$request->id."X".'advanced'; 
                       $img='Quiz/advanced_paper/'.$pname.'/solution/'.$name;
                        $filea= question::where('qpqtypeid',$qpqtypeid)->update(['solimg' => $img]);  
              }
           }
          return back()->with('success', 'uploaded Successfully');
      }
   public function advancedpaperansuploadsubmit(Request $request){
          $where=['qpqtypeid'=>$request->qpqtypeid,
        'active'=>'1'];
        $done=0;
         if ($request->q5!='') {
           $done=1;
            $users = question::where($where)->update(['q1' =>$request->q5]); 
        }
        if ($request->q1=='A') {
           $done=1;
            $users = question::where($where)->update(['q1' =>'A']); 
        }elseif($request->q1=='blank1'){
          $done=1;
            $users = question::where($where)->update(['q1' =>'']); 
        }
        if ($request->q1=='B') {
          $done=1;
            $users = question::where($where)->update(['q2' =>'B']); 
        }elseif($request->q1=='blank2'){
          $done=1;
            $users = question::where($where)->update(['q2' =>'']); 
        }
        if ($request->q1=='C') {
          $done=1;
            $users = question::where($where)->update(['q3' =>'C']); 
        }elseif($request->q1=='blank3'){
          $done=1;
            $users = question::where($where)->update(['q3' =>'']); 
        }
        if ($request->q1=='D') {
          $done=1;
            $users = question::where($where)->update(['q4' =>'D']); 
        }elseif($request->q1=='blank4'){
          $done=1;
            $users = question::where($where)->update(['q4' =>'']); 
        }
        if ($request->q2!='') {
             $done=1;
             $users = question::where($where)->update(['q1' =>$request->q2]);
        }
        if ($request->q3!='') {
             $done=1;
             $users = question::where($where)->update(['q1' =>$request->q3,'q2'=>$request->q4]);
        }

          return response()->json($users);
      }

      public function advancedpaperpublishsubmit(Request $request){
           $this->validate($request, [
                  'class' => 'required',
                  'course' => 'required',
                  'coursetype' => 'required',
                  'publishtime' => 'required',
                  'radio' => 'required',
                  'radio1' => 'required',
                  'pname' => 'required',
                  'plink' => 'required',
                  'pid' => 'required',
                  'hardness' => 'required'
          ]);
                  $file= new paper_link();
                  $file->pid=$request->pid;
                  $file->classid=$request->class;
                  $file->courseid=$request->course;
                  $file->coursetypeid=$request->coursetype;
                  $file->groupid=$request->radio;
                  $file->cccgid=$request->class.$request->course.$request->coursetype.$request->radio;
                  $file->paper=$request->pname;
                  $file->plink=$request->plink;
                  $file->hardness=$request->hardness;
                  $file->rank=$request->radio1;
                  $file->publishtime=$request->publishtime;
                  $file->type='advanced'; 
                  $file->active=1;
                  $file->save();
                  return back()->with('success', 'uploaded Successfully');
      }



















      public function uploadedpaper(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
          $users = paper_link::where('paper', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
           $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
              return view('admin.uploaded_paper',compact('users'));
          } 
        else{
        $users = paper_link::where('active','1')->orderBy('id','desc')->paginate(7);
          return view('admin.uploaded_paper',compact('users'));
        }
      }

      public function uploadedpaper_page(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
          $users = paper_link::where('paper', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
           $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
              return view('admin.uploaded_paper_reload',compact('users'));
          } 
        else{
        $users = paper_link::where('active','1')->orderBy('id','desc')->paginate(7);
          return view('admin.uploaded_paper_reload',compact('users'));
        }
      }


     function studentresult(Request $request){
       if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
            $where=['sid'=>$request->get('id'),'active'=>'1']; 
         $users = result::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);
      return view('admin.s_result',compact('users'));
         }else{
          $where=['sid'=> $request->get('id'),'active'=>'1'];
          $users = result::where($where)->orderBy('id','desc')->paginate(7);
      return view('admin.s_result',compact('users'));
      }
      }

   function studentresult_page(Request $request){
       if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
            $where=['sid'=>$request->get('id'),'active'=>'1']; 
         $users = result::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);
      return view('admin.s_result_reload',compact('users'));
         }else{
          $where=['sid'=> $request->get('id'),'active'=>'1'];
          $users = result::where($where)->orderBy('id','desc')->paginate(7);
      return view('admin.s_result_reload',compact('users'));
      }
      }    
     function paperresult(Request $request){
       if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
           $where=['plid'=>$request->get('id'),'active'=>'1']; 
         $users = result::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);
      return view('admin.p_result',compact('users'));
         }else{
          $where=['plid'=>$request->get('id'),'active'=>'1'];
          $users = result::where($where)->orderBy('id','desc')->paginate(7);
      return view('admin.p_result',compact('users'));
      }
      }
      function paperresult_page(Request $request){
       if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
           $where=['plid'=>$request->get('id'),'active'=>'1']; 
         $users = result::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);
      return view('admin.p_result_reload',compact('users'));
         }else{
          $where=['plid'=>$request->get('id'),'active'=>'1'];
          $users = result::where($where)->orderBy('id','desc')->paginate(7);
      return view('admin.p_result_reload',compact('users'));
      }
      }
       public function resultshow(Request $request){
          $where=['id'=>$request->get('id'),
        'active'=>'1'];
          $users = result::where($where)->orderBy('id','desc')->paginate(7);
      return view('layout.resultview',compact('users'));
      }
      function paperlist(Request $request){
         $counts = result::where('active','1')->select('plid')->get();
          if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
            $users = paper_link::where('paper', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
           $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
      return view('admin.results',compact('users','counts'));
        }else{
          $users = paper_link::where('active','1')->orderBy('id','desc')->paginate(7);
    return view('admin.results',compact('users','counts'));
  }
      }

       function paperlist_page(Request $request){
         $counts = result::where('active','1')->select('plid')->get();
          if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
            $users = paper_link::where('paper', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
           $users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);
      return view('admin.results_reload',compact('users','counts'));
        }else{
          $users = paper_link::where('active','1')->orderBy('id','desc')->paginate(7);
    return view('admin.results_reload',compact('users','counts'));
  }
      }


     public function addstudent(Request $request){
     $rules = array (
      'class' => 'required',
      'coursetype' => 'required',
      'course' => 'required',
      'group' => 'required',
      'name' => 'required',
      'username' => 'required',
      'email' => 'required',
      'mobile' => 'required',
      'password' => 'required'
      ); 
    $validator = Validator::make ( Input::all (), $rules );
      if ($validator->fails ())
          return Response::json ( array ( 'errors' => $validator->getMessageBag ()->toArray ()) );
    else {
     
      $student = new student();
      $student->class = $request->class;
       $student->course = $request->course;
      $student->coursetype = $request->coursetype;
       $student->groupid = $request->group;
      $student->name = $request->name;
      $student->username = $request->username;
       $student->email = $request->email;
       $student->mobile = $request->mobile;
      $student->password = Hash::make($request->password);
       $student->active = '1';
      $student->save();
      return Response::json($student);
      }
  }

  public function editstudent(Request $request){
    $rules = array (
      'id' => 'required',
      'class' => 'required',
      'coursetype' => 'required',
      'course' => 'required',
      'group' => 'required',
      'name' => 'required',
      'username' => 'required',
      'email' => 'required',
      'mobile' => 'required'
      ); 
    $validator = Validator::make ( Input::all (), $rules );
      if ($validator->fails ()){
          return Response::json ( array ( 'errors' => $validator->getMessageBag ()->toArray ()) );
   } else {
      if ($request->password !='') {
       $student = student::find($request->id);
      $student->username = $request->username;
       $student->password = Hash::make($request->password);
      $student->name = $request->name;
      $student->mobile = $request->mobile;
      $student->email = $request->email;
      $student->class = $request->class;
      $student->coursetype = $request->coursetype;
      $student->course = $request->course;
      $student->groupid = $request->group;
  $student->save();
  return response()->json($student);
      }
      else {
       $student = student::find($request->id);
      $student->username = $request->username;
      $student->name = $request->name;
      $student->mobile = $request->mobile;
      $student->email = $request->email;
      $student->class = $request->class;
      $student->coursetype = $request->coursetype;
      $student->course = $request->course;
      $student->groupid = $request->group;
  $student->save();
  return response()->json($student);
      }
  }
  }
  public function deletestudent(Request $request){
  $student = student::find ($request->id);
  $student->active = '0';
      $student->save();
   return response()->json($student);
  }


  //--------------------------------------------advaced paper-------------------------------------------------
   function submitadvancedpaper(Request $request){
      if(advance_paper::Where(['pname'=>$request->papername,'active'=>'1'])->count()>0){
    $validator = Validator::make ( Input::all (), ['papername' => 'email'] );
          return Response::json ( ['error' => $validator->errors()->all()] );
   }
  else{
       File::makeDirectory('Quiz/advanced_paper/'.$request->papername);
       File::makeDirectory('Quiz/advanced_paper/'.$request->papername.'/question');
       File::makeDirectory('Quiz/advanced_paper/'.$request->papername.'/solution');
       $uniquename=time().uniqid(rand());
      $File = $uniquename.'.blade.php';
      $results='$results';
      $contents = "@extends($results==0 ? 'layout/advanced_paper' : 'layout/advanced_papershow')
      @extends('layout/details')";
      Storage::disk('advanced_paper')->put($File,$contents);

  $total_marks = $request->P1Q*$request->P1M + $request->P2Q*$request->P2M + $request->P3Q*$request->P3M + $request->P4Q*$request->P4M + $request->P5Q*$request->P5M + $request->P6Q*$request->P6M + $request->C1Q*$request->C1M + $request->C2Q*$request->C2M + $request->C3Q*$request->C3M + $request->C4Q*$request->C4M + $request->C5Q*$request->C5M + $request->C6Q*$request->C6M + $request->M1Q*$request->M1M + $request->M2Q*$request->M2M + $request->M3Q*$request->M3M + $request->M4Q*$request->M4M + $request->M5Q*$request->M5M + $request->M6Q*$request->M6M;

       $paper = new advance_paper();
      $paper->pname = $request->papername;
       $paper->plink = $File;
      $paper->active = '1';
       $paper->type = 'advanced';
       $paper->NOQ = $request->NOQ;
       $paper->TT  = $request->TT;
       $paper->PQ  = $request->PQ;
       $paper->CQ  = $request->CQ;
       $paper->MQ  = $request->MQ;
       $paper->P1Q = $request->P1Q;
       $paper->P1M = $request->P1M;
       $paper->P1N = $request->P1N;
       $paper->P2Q = $request->P2Q;
       $paper->P2M = $request->P2M;
       $paper->P2N = $request->P2N;
       $paper->P3Q = $request->P3Q;
       $paper->P3M = $request->P3M;
       $paper->P3N = $request->P3N;
       $paper->P4Q = $request->P4Q;
       $paper->P4M = $request->P4M;
       $paper->P4N = $request->P4N;
       $paper->P5Q = $request->P5Q;
       $paper->P5M = $request->P5M;
       $paper->P5N = $request->P5N;
       $paper->P6Q = $request->P6Q;
       $paper->P6M = $request->P6M;
       $paper->P6N = $request->P6N;
       $paper->C1Q = $request->C1Q;
       $paper->C1M = $request->C1M;
       $paper->C1N = $request->C1N;
       $paper->C2Q = $request->C2Q;
       $paper->C2M = $request->C2M;
       $paper->C2N = $request->C2N;
       $paper->C3Q = $request->C3Q;
       $paper->C3M = $request->C3M;
       $paper->C3N = $request->C3N;
       $paper->C4Q = $request->C4Q;
       $paper->C4M = $request->C4M;
       $paper->C4N = $request->C4N;
       $paper->C5Q = $request->C5Q;
       $paper->C5M = $request->C5M;
       $paper->C5N = $request->C5N;
       $paper->C6Q = $request->C6Q;
       $paper->C6M = $request->C6M;
       $paper->C6N = $request->C6N;
       $paper->M1Q = $request->M1Q;
       $paper->M1M = $request->M1M;
       $paper->M1N = $request->M1N;
       $paper->M2Q = $request->M2Q;
       $paper->M2M = $request->M2M;
       $paper->M2N = $request->M2N;
       $paper->M3Q = $request->M3Q;
       $paper->M3M = $request->M3M;
       $paper->M3N = $request->M3N;
       $paper->M4Q = $request->M4Q;
       $paper->M4M = $request->M4M;
       $paper->M4N = $request->M4N;
       $paper->M5Q = $request->M5Q;
       $paper->M5M = $request->M5M;
       $paper->M5N = $request->M5N;
       $paper->M6Q = $request->M6Q;
       $paper->M6M = $request->M6M;
       $paper->M6N = $request->M6N;
       $paper->total_marks = $total_marks;
       $paper->save();
       $i=1;
   for ($a=1; $a <= $request->P1Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='single';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->P2Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='multiple';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->P3Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='integer';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->P4Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='numerical';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->P5Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='passage';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->P6Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='match_column';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
  for ($a=1; $a <= $request->C1Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='single';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->C2Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='multiple';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->C3Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='integer';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->C4Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='numerical';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->C5Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='passage';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->C6Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='match_column';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
    
  for ($a=1; $a <= $request->M1Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='single';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->M2Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='multiple';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->M3Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='integer';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->M4Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='numerical';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->M5Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='passage';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->M6Q; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'advanced'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='advanced';
                  $filea->type='match_column';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   
      return Response::json($paper);
  }
  }
  //-----------------------------------------------normal paper----------------------------------
  function submitnormalpaper(Request $request){
      if(normal_paper::Where(['pname'=>$request->papername,'active'=>'1'])->count()>0){
    $validator = Validator::make ( Input::all (), ['papername' => 'email'] );
          return Response::json ( ['error' => $validator->errors()->all()] );
   }
  else{
       File::makeDirectory('Quiz/normal_paper/'.$request->papername);
       File::makeDirectory('Quiz/normal_paper/'.$request->papername.'/question');
       File::makeDirectory('Quiz/normal_paper/'.$request->papername.'/solution');
      $uniquename=time().uniqid(rand());
      $File =$uniquename.'.blade.php';
      $results='$results';
      $contents = "@extends($results==0 ? 'layout/normal_paper' : 'layout/normal_papershow')
      @extends('layout/details')";
      Storage::disk('normal_paper')->put($File,$contents);
      $total_marks = $request->PQ*$request->PM + $request->CQ*$request->CM + $request->MQ*$request->MM + $request->BQ*$request->BM;
       $paper = new normal_paper();
      $paper->pname = $request->papername;
      $paper->plink = $File;
      $paper->active = '1';
      $paper->type = 'normal';
       $paper->NOQ = $request->NOQ;
       $paper->TT  = $request->TT;
       $paper->total_marks  = $total_marks;
       $paper->PQ = $request->PQ;
       $paper->PM = $request->PM;
       $paper->PN = $request->PN;
       $paper->CQ = $request->CQ;
       $paper->CM = $request->CM;
       $paper->CN = $request->CN;
       $paper->MQ = $request->MQ;
       $paper->MM = $request->MM;
       $paper->MN = $request->MN;
       $paper->BQ = $request->BQ;
       $paper->BM = $request->BM;
       $paper->BN = $request->BN;
     $paper->save();

          $i=1;
   for ($a=1; $a <= $request->PQ; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'normal'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='normal';
                  $filea->type='normal';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->CQ; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'normal'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='normal';
                  $filea->type='normal';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->MQ; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'normal'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='normal';
                  $filea->type='normal';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
   for ($a=1; $a <= $request->BQ; $a++) { 
     $qpqtypeid=$i."X".$paper->id."X".'normal'; 
                  $filea= new question();
                  $filea->qid=$i;
                  $filea->pid=$paper->id;
                  $filea->qpid = $i."X".$paper->id;
                  $filea->qtype='normal';
                  $filea->type='normal';
                  $filea->qpqtypeid=$qpqtypeid;
                   $filea->active=1;
                   $filea->save();
                   $i++;
   }
      return Response::json($paper);
  }
  }
   public function uploaded_paper_edit(Request $request){
          
                  $users = paper_link::where(['id'=>$request->get('id'),'active'=>'1'])->get();
          return view('admin.edit_publish_paper',compact('users'));
      }

      public function uploaded_paper_edit_submit(Request $request){
           $this->validate($request, [
                  'class' => 'required',
                  'course' => 'required',
                  'coursetype' => 'required',
                  'publishtime' => 'required',
                  'radio' => 'required',
                  'radio1' => 'required',
                  'id' => 'required',
                  'hardness' => 'required'
          ]);

            $inv = paper_link::where('id',$request->id)->update(['classid'=>$request->class,'courseid'=>$request->course,'coursetypeid'=>$request->coursetype,'groupid'=>$request->radio,'cccgid'=>$request->class.$request->course.$request->coursetype.$request->radio,'hardness'=>$request->hardness,'publishtime'=>$request->publishtime,'rank'=>$request->radio1]);
                  return back()->with('success', 'uploaded Successfully');
      }


  public function deletenrpaper(Request $request){
  $teacher = normal_paper::find ($request->id);
  $teacher->active = '0';
      $teacher->save();
   $teacher = paper_link::where(['pid'=>$request->id,'type'=>'normal'])->update(['active' =>'2']);
   return response()->json($teacher);
  }
  public function deleteadvpaper(Request $request){
  $teacher = advance_paper::find ($request->id);
  $teacher->active = '0';
      $teacher->save();
  $teacher = paper_link::where(['pid'=>$request->id,'type'=>'advanced'])->update(['active' => '2']);
   return response()->json($teacher);
  }
  public function deletelink(Request $request){
  $teacher = paper_link::find ($request->id);
  $teacher->active = '0';
      $teacher->save();
   return response()->json($teacher);
  }
  public function deleteresult(Request $request){
  $teacher = result::find ($request->id);
  $teacher->active = '0';
      $teacher->save();
   return response()->json($teacher);
  }
  //--------------------------------------------------------------------------------------

  public function recycle_student(Request $request){
         if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
         $users = student::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('username', 'like', '%'.$studentsearch.'%')
           ->orWhere('email', 'like', '%'.$studentsearch.'%')
           ->orWhere('mobile', 'like', '%'.$studentsearch.'%')
           ->orWhere('class', 'like', '%'.$studentsearch.'%')
           ->orWhere('course', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetype', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');

           if($request->has('class')&&$request->get('class')!=''){
            $where=['class'=>$request->get('class'),'active'=>'0'];
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);}
          else{$users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);}
             return view('admin.recycle_students',compact('users'));
          } 
          else{
             if($request->has('class')&&$request->get('class')!=''){
            $where=['class'=>$request->get('class'),'active'=>'0'];
         $users = student::where($where)->orderBy('id','desc')->paginate(7);}
          else{$users = student::where('active','0')->orderBy('id','desc')->paginate(7);}
            return view('admin.recycle_students',compact('users'));
        }
        }




       public function recycle_student_page(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
         $users = student::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('username', 'like', '%'.$studentsearch.'%')
           ->orWhere('email', 'like', '%'.$studentsearch.'%')
           ->orWhere('mobile', 'like', '%'.$studentsearch.'%')
           ->orWhere('class', 'like', '%'.$studentsearch.'%')
           ->orWhere('course', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetype', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');

           if($request->has('class')&&$request->get('class')!=''){
            $where=['class'=>$request->get('class'),'active'=>'0'];
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);}
          else{$users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);}
             return view('admin.recycle_students_reload',compact('users'));
          } 
          else{
             if($request->has('class')&&$request->get('class')!=''){
            $where=['class'=>$request->get('class'),'active'=>'0'];
         $users = student::where($where)->orderBy('id','desc')->paginate(7);}
          else{$users = student::where('active','0')->orderBy('id','desc')->paginate(7);}
            return view('admin.recycle_students_reload',compact('users'));
        }
        }
     
  public function recycle_student_submit(Request $request){
  $teacher = student::find ($request->id);
  $teacher->active = '1';
      $teacher->save();
   return response()->json($teacher);
  }
  public function p_delete_student_submit(Request $request){
  $teacher = student::where('id',$request->id)->delete();
  $teacher = result::where('sid',$request->id)->delete();
  $teacher = answer::where('sid',$request->id)->delete();
  $teacher = time_left::where('sid',$request->id)->delete();
   return response()->json($teacher);
  }



  public function recycle_teacher(Request $request){

        if($request->has('s')&&$request->get('s')!=''){
           $teachersearch = $request->get('s');
           $users = teacher::where('name', 'like', '%'.$teachersearch.'%')
           ->orWhere('username', 'like', '%'.$teachersearch.'%')
           ->orWhere('email', 'like', '%'.$teachersearch.'%')
           ->orWhere('mobile', 'like', '%'.$teachersearch.'%');
           $users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);
           return view('admin.recycle_teachers',compact('users'));
         }
         else{
          $users = teacher::where('active','0')->orderBy('id','desc')->paginate(7);
      return view('admin.recycle_teachers',compact('users'));
      }
      }
       public function recycle_teacher_page(Request $request){

        if($request->has('s')&&$request->get('s')!=''){
           $teachersearch = $request->get('s');
           $users = teacher::where('name', 'like', '%'.$teachersearch.'%')
           ->orWhere('username', 'like', '%'.$teachersearch.'%')
           ->orWhere('email', 'like', '%'.$teachersearch.'%')
           ->orWhere('mobile', 'like', '%'.$teachersearch.'%');
           $users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);
           return view('admin.recycle_teachers_reload',compact('users'));
         }
         else{
          $users = teacher::where('active','0')->orderBy('id','desc')->paginate(7);
      return view('admin.recycle_teachers_reload',compact('users'));
      }
      }
      public function recycle_teacher_submit(Request $request){
  $teacher = teacher::find ($request->id);
  $teacher->active = '1';
      $teacher->save();
   return response()->json($teacher);
  }
  public function p_delete_teacher_submit(Request $request){
  $teacher = teacher::find ('id',$request->id)->delete();
   return response()->json($teacher);
  }

   public function recycle_normal_paper(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
          $studentsearch = $request->get('s');
         $users = normal_paper::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('created_at', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);
      return view('admin.recycle_normal_paper_upload_list',compact('users'));
          } 
        else{
          $users = normal_paper::where('active','0')->orderBy('id','desc')->paginate(7);
          return view('admin.recycle_normal_paper_upload_list',compact('users'));}
      }

      public function recycle_normal_paper_page(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
          $studentsearch = $request->get('s');
         $users = normal_paper::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('created_at', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);
      return view('admin.recycle_normal_paper_upload_list_reload',compact('users'));
          } 
        else{
          $users = normal_paper::where('active','0')->orderBy('id','desc')->paginate(7);
          return view('admin.recycle_normal_paper_upload_list_reload',compact('users'));}
      }
       public function recycle_normal_paper_submit(Request $request){
  $teacher = normal_paper::find ($request->id);
  $teacher->active = '1';
      $teacher->save();
      $teacher = paper_link::where(['pid'=>$request->id,'type'=>'normal','active'=>'2'])->update(['active'=>'1']);
   return response()->json($teacher);
  }

  public function p_delete_normal_paper_submit(Request $request){
    $advs = normal_paper::where('id',$request->id)->get();
  foreach ($advs as $adv) {
    File::deleteDirectory('Quiz/normal_paper/'.$adv->pname);
     Storage::disk('normal_paper')->delete($adv->plink);
  }
  $teacher = normal_paper::where('id',$request->id)->delete();
     $teachers = paper_link::where(['pid'=>$request->id,'type'=>'normal'])->select('id')->get();
  foreach ($teachers as $teach) {
   $teacher = answer::where(['plid'=>$teach->id])->delete();
  $teacher = result::where(['plid'=>$teach->id])->delete();
  $teacher = time_left::where(['plid'=>$teach->id])->delete();
  }
      $teacher = paper_link::where(['pid'=>$request->id,'type'=>'normal'])->delete();
       $teacher = question::where(['pid'=>$request->id,'qtype'=>'normal'])->delete();
   return response()->json($teacher);
  }

   public function recycle_advanced_paper(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
          $studentsearch = $request->get('s');
         $users = advance_paper::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('created_at', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);
      return view('admin.recycle_advanced_paper_upload_list',compact('users'));
          } 
        else{
          $users = advance_paper::where('active','0')->orderBy('id','desc')->paginate(7);
          return view('admin.recycle_advanced_paper_upload_list',compact('users'));}
      }

      public function recycle_advanced_paper_page(Request $request){
        if($request->has('s')&&$request->get('s')!=''){
          $studentsearch = $request->get('s');
         $users = advance_paper::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('created_at', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);
      return view('admin.recycle_advanced_paper_upload_list_reload',compact('users'));
          } 
        else{
          $users = advance_paper::where('active','0')->orderBy('id','desc')->paginate(7);
          return view('admin.recycle_advanced_paper_upload_list_reload',compact('users'));}
      }

       public function recycle_advanced_paper_submit(Request $request){
  $teacher = advance_paper::find ($request->id);
  $teacher->active = '1';
      $teacher->save();
      $teacher = paper_link::where(['pid'=>$request->id,'type'=>'advanced','active'=>'2'])->update(['active'=>'1']);
   return response()->json($teacher);
  }

  public function p_delete_advanced_paper_submit(Request $request){
  $advs = advance_paper::where('id',$request->id)->get();
  foreach ($advs as $adv) {
   File::deleteDirectory('Quiz/advanced_paper/'.$adv->pname);
     Storage::disk('advanced_paper')->delete($adv->plink);
  }
  $teacher = advance_paper::where('id',$request->id)->delete();
  $teachers = paper_link::where(['pid'=>$request->id,'type'=>'advanced'])->select('id')->get();
  foreach ($teachers as $teach) {
   $teacher = answer::where(['plid'=>$teach->id])->delete();
  $teacher = result::where(['plid'=>$teach->id])->delete();
  $teacher = time_left::where(['plid'=>$teach->id])->delete();
  }
      $teacher = paper_link::where(['pid'=>$request->id,'type'=>'advanced'])->delete();
       $teacher = question::where(['pid'=>$request->id,'qtype'=>'advanced'])->delete();
   return response()->json($teacher);
  }
  //---------------------------------------------------------------------------------------------



  function recycle_result(Request $request){
       if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
         $users = result::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
             ->orWhere('paper', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);
      return view('admin.recycle_result',compact('users'));
         }else{
          $users = result::where('active','0')->orderBy('id','desc')->paginate(7);
      return view('admin.recycle_result',compact('users'));
      }
      }

   function recycle_result_page(Request $request){
       if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');   
         $users = result::where('name', 'like', '%'.$studentsearch.'%')
           ->orWhere('classid', 'like', '%'.$studentsearch.'%')
             ->orWhere('paper', 'like', '%'.$studentsearch.'%')
           ->orWhere('courseid', 'like', '%'.$studentsearch.'%')
           ->orWhere('coursetypeid', 'like', '%'.$studentsearch.'%')
           ->orWhere('groupid', 'like', '%'.$studentsearch.'%');
          $users = $users->where('active','0')->orderBy('id', 'desc')->paginate(7);
      return view('admin.recycle_result_reload',compact('users'));
         }else{
          $users = result::where('active','0')->orderBy('id','desc')->paginate(7);
      return view('admin.recycle_result_reload',compact('users'));
      }
      }   

      public function recycle_result_submit(Request $request){
  $teacher = result::find ($request->id);
  $teacher->active = '1';
      $teacher->save();
   return response()->json($teacher);
  } 
  public function p_delete_result_submit(Request $request){
  $teacher = result::where('id',$request->id)->get();
  foreach ($teacher as $teach) {
    $no=0;
    $teachers = result::where('id',$request->id)->delete();
    $no=result::where(['plid'=>$teach->plid,'sid'=>$teach->sid])->count();
    if($no==0){
   $users=answer::where(['plid'=>$teach->plid,'sid'=>$teach->sid])->delete();
   $user=time_left::where(['plid'=>$teach->plid,'sid'=>$teach->sid])->delete();
  }
  }
  
   return response()->json($teachers);
  } 
  public function pp_delete_result_submit(Request $request){
  $teachers = result::where('id',$request->id)->delete();
   return response()->json($teachers);
  } 
  //-----------------------------------------------------------------------------------

   public function settings(){

          return view('admin.settings');
      }
      public function change_password(Request $request)
  {  
     $old = Auth::user()->password;
  if(Hash::check($request->old,$old)){ 
      $inv = admin::where('id',Auth::user()->id)->update(['password'=> Hash::make($request->new)]);
      return Response::json($inv);
  }
  else{
      return Response::json ( array ( 'errors' => 'fail') );
  }
  }
   public function hiii(Request $request)
   {
    $users=answer::all();
    foreach ($users as $user) {
     $qid=$user->qid;
      $pid=$user->pid;
       $plid=$user->plid;
        $qtype=$user->qtype;
        $sid=$user->sid;
        $id=$user->id;
        $q=answer::where(['id'=>$id])->update(['pplsid'=>$pid."X".$plid."X".$sid,'qplsid'=>$qid."X".$plid."X".$sid,'qplsqtypeid'=>$qid."X".$plid."X".$sid."X".$qtype]);

    }
     $userss=time_left::all();
      foreach ($userss as $user) {
         $plid=$user->plid;
        $sid=$user->sid;
         $id=$user->id;
          $q=time_left::where(['id'=>$id])->update(['plsid'=>$plid."X".$sid]);
      }
       $usersss=question::all();
      foreach ($usersss as $user) {
         $qid=$user->qid;
        $pid=$user->pid;
         $qtype=$user->qtype;
         $id=$user->id;
          $q=question::where(['id'=>$id])->update(['qpid'=>$qid."X".$pid,'qpqtypeid'=>$qid."X".$pid."X".$qtype]);
      }
   }


    public function pl_summary(Request $request){
      $id=$request->get('id');
     $no=0;
      $no=result::where(['plid'=>$id,'active'=>'1'])->count();
      if($no>0){
       $users = result::where(['plid'=>$id,'active'=>'1'])->orderBy('totalS','desc')->get();
       $users=$users->sortByDesc('totalS');
       foreach ($users as $user) {
         $name=$user->paper;
       }

       $pdf = \App::make('dompdf.wrapper');
       $pdf->loadview('admin.result_summary',compact('users'));
       return $pdf->download($name.' full result summary.pdf');
    }
    return back();
  }
    public function adv_p_summary(Request $request){
     $id=$request->get('id');
      $no=0;
      $no=result::where(['pid'=>$id,'type'=>'advanced','active'=>'1'])->count();
      if($no>0){
     $users = result::where(['pid'=>$id,'type'=>'advanced','active'=>'1'])->orderBy('totalS','desc')->get();
       $users=$users->sortByDesc('totalS');
       foreach ($users as $user) {
         $name=$user->paper;
       }

       $pdf = \App::make('dompdf.wrapper');
       $pdf->loadview('admin.result_summary',compact('users'));
       return $pdf->download($name.' full result summary.pdf');
    }
    return back();
  }
    public function nr_p_summary(Request $request){
      $id=$request->get('id');
      $no=0;
      $no=result::where(['pid'=>$id,'type'=>'normal','active'=>'1'])->count();
      if($no>0){
       $users = result::where(['pid'=>$id,'type'=>'normal','active'=>'1'])->orderBy('totalS','desc')->get();
       $users=$users->sortByDesc('totalS');
       foreach ($users as $user) {
         $name=$user->paper;
       }

       $pdf = \App::make('dompdf.wrapper');
       $pdf->loadview('admin.result_summary',compact('users'));
       return $pdf->download($name.' full result summary.pdf');
    }
    return back();
  }
   public function nr_paper_download(Request $request)  {
    if(Auth::user()->admin=='yes'){
    $id=$request->get('id');
    $users = normal_paper::where('id',$id)->get();
    foreach ($users as $user) {
      $pname = $user->pname;
      
    }
    $userss=question::where(['pid'=>$id,'qtype'=>'normal','active'=>'1'])->get();
  $path=base_path().'/public_html/Quiz/normal_paper/'.$pname; 
  if(file_exists($path.'.zip')){
  $path1=base_path().'/public_html/Quiz/normal_paper/'.$pname.'.zip'; 
  $File = $pname.'.txt';
  $File1 = $pname.'_ans.txt';
  File::delete($path1);
  File::delete($File);
  File::delete($File1);
  $zip = Zip::create(base_path().'/public_html/Quiz/normal_paper/'.$pname.'.zip');

      Storage::disk('downn')->put($File,$users);
       Storage::disk('downn')->put($File1,$userss);
       $zip->add($path);
       $zip->add($path.'.txt');
       $zip->add($path.'_ans.txt');
      $zip->close();
    }
    else{
      $File = $pname.'.txt';
  $File1 = $pname.'_ans.txt';
  $zip = Zip::create(base_path().'/public_html/Quiz/normal_paper/'.$pname.'.zip');

      Storage::disk('downn')->put($File,$users);
       Storage::disk('downn')->put($File1,$userss);
       $zip->add($path);
       $zip->add($path.'.txt');
       $zip->add($path.'_ans.txt');
      $zip->close();
    }

  return response()->download(base_path().'/public_html/Quiz/normal_paper/'.$pname.'.zip');
    }
  }
     public function nr_paper_upload(Request $request)  {
       if(Auth::user()->admin=='yes'){
       return view('admin.nr_ppr_upload');
     }
     }
    public function nr_paper_upload_submit(Request $request)  {
       if(Auth::user()->admin=='yes'){
  $data = json_decode($request->paper, true);
  $data2 = json_decode($request->answer, true);

  // processing the array of objects
  foreach ($data as $user) {
      $File = $user['plink'];
      $NOQ = $user['NOQ'];
       $TT = $user['TT'];
        $total_marks = $user['total_marks'];
         $PQ = $user['PQ'];
          $PM = $user['PM'];
           $PN = $user['PN'];
           $CQ = $user['CQ'];
          $CM = $user['CM'];
           $CN = $user['CN'];
           $MQ = $user['MQ'];
          $MM = $user['MM'];
           $MN = $user['MN'];
           $BQ = $user['BQ'];
          $BM = $user['BM'];
           $BN = $user['BN'];
          
       $paper = new normal_paper();
      $paper->pname = $request->papername;
      $paper->plink = $File;
      $paper->active = '1';
      $paper->type = 'normal';
       $paper->NOQ = $NOQ;
       $paper->TT  = $TT;
       $paper->total_marks  = $total_marks;
       $paper->PQ = $PQ;
       $paper->PM = $PM;
       $paper->PN = $PN;
       $paper->CQ = $CQ;
       $paper->CM = $CM;
       $paper->CN = $CN;
       $paper->MQ = $MQ;
       $paper->MM = $MM;
       $paper->MN = $MN;
       $paper->BQ = $BQ;
       $paper->BM = $BM;
       $paper->BN = $BN;
     $paper->save();
     File::makeDirectory('Quiz/normal_paper/'.$request->papername);
       File::makeDirectory('Quiz/normal_paper/'.$request->papername.'/question');
       File::makeDirectory('Quiz/normal_paper/'.$request->papername.'/solution');
      $results='$results';
      $contents = "@extends($results==0 ? 'layout/normal_paper' : 'layout/normal_papershow')";
      Storage::disk('normal_paper')->put($user['plink'],$contents);
     $pid=$paper->id;

  }
  foreach ($data2 as $user) {
    

      $paper = new question();

   $paper->qid = $user['qid'];
     $paper->pid = $pid;
     $paper->qtype = $user['qtype'];
     $paper->qpid = $user['qid']."X".$pid;
     $paper->qpqtypeid = $user['qid']."X".$pid."X".$user['qtype'];
     $paper->type = $user['type'];  
     $paper->q1 = $user['q1'];
     $paper->q2 = $user['q2'];
     $paper->q3 = $user['q3'];
     $paper->q4 = $user['q4'];
     $paper->q5 = $user['q5'];
     $paper->q6 = $user['q6'];
     $paper->q7 = $user['q7'];
     $paper->q8 = $user['q8'];
     $paper->active = '1';
      $paper->save();

    }

     return back(); 
   }
    }
     public function adv_paper_download(Request $request)  {
      if(Auth::user()->admin=='yes'){
    $id=$request->get('id');
    $users = advance_paper::where('id',$id)->get();
    foreach ($users as $user) {
      $pname = $user->pname;
      
    }
    $userss=question::where(['pid'=>$id,'qtype'=>'advanced','active'=>'1'])->get();
  $path=base_path().'/public_html/Quiz/advanced_paper/'.$pname; 
  if(file_exists($path.'.zip')){
  $path1=base_path().'/public_html/Quiz/advanced_paper/'.$pname.'.zip'; 
  $File = $pname.'.txt';
  $File1 = $pname.'_ans.txt';
  File::delete($path1);
  File::delete($File);
  File::delete($File1);
  $zip = Zip::create(base_path().'/public_html/Quiz/advanced_paper/'.$pname.'.zip');
      Storage::disk('downa')->put($File,$users);
       Storage::disk('downa')->put($File1,$userss);
       $zip->add($path);
       $zip->add($path.'.txt');
       $zip->add($path.'_ans.txt');
      $zip->close();
    }
    else{
  $File = $pname.'.txt';
  $File1 = $pname.'_ans.txt';
  $zip = Zip::create(base_path().'/public_html/Quiz/advanced_paper/'.$pname.'.zip');

      Storage::disk('downa')->put($File,$users);
       Storage::disk('downa')->put($File1,$userss);
       $zip->add($path);
       $zip->add($path.'.txt');
       $zip->add($path.'_ans.txt');
      $zip->close();
    }

  return response()->download(base_path().'/public_html/Quiz/advanced_paper/'.$pname.'.zip');
    }
  }
     public function adv_paper_upload(Request $request)  {
       if(Auth::user()->admin=='yes'){
      return view('admin.adv_ppr_upload');
    }
    }

      public function adv_paper_upload_submit(Request $request)  {
       if(Auth::user()->admin=='yes'){
  $data = json_decode($request->paper, true);
  $data2 = json_decode($request->answer, true);

  // processing the array of objects
  foreach ($data as $user) {
       $paper = new advance_paper();
       $paper->pname = $request->papername;
       $paper->plink =  $user['plink'];
      $paper->active = '1';
       $paper->type = 'advanced';
       $paper->NOQ = $user['NOQ'];
       $paper->TT  = $user['TT'];
       $paper->PQ  = $user['PQ'];
       $paper->CQ  = $user['CQ'];
       $paper->MQ  = $user['MQ'];
       $paper->P1Q = $user['P1Q'];
       $paper->P1M = $user['P1M'];
       $paper->P1N = $user['P1N'];
       $paper->P2Q = $user['P2Q'];
       $paper->P2M = $user['P2M'];
       $paper->P2N = $user['P2N'];
       $paper->P3Q = $user['P3Q'];
       $paper->P3M = $user['P3M'];
       $paper->P3N = $user['P3N'];
       $paper->P4Q = $user['P4Q'];
       $paper->P4M = $user['P4M'];
       $paper->P4N = $user['P4N'];
       $paper->P5Q = $user['P5Q'];
       $paper->P5M = $user['P5M'];
       $paper->P5N = $user['P5N'];
       $paper->P6Q = $user['P6Q'];
       $paper->P6M = $user['P6M'];
       $paper->P6N = $user['P6N'];
       $paper->C1Q = $user['C1Q'];
       $paper->C1M = $user['C1M'];
       $paper->C1N = $user['C1N'];
       $paper->C2Q = $user['C2Q'];
       $paper->C2M = $user['C2M'];
       $paper->C2N = $user['C2N'];
       $paper->C3Q = $user['C3Q'];
       $paper->C3M = $user['C3M'];
       $paper->C3N = $user['C3N'];
       $paper->C4Q = $user['C4Q'];
       $paper->C4M = $user['C4M'];
       $paper->C4N = $user['C4N'];
       $paper->C5Q = $user['C5Q'];
       $paper->C5M = $user['C5M'];
       $paper->C5N = $user['C5N'];
       $paper->C6Q = $user['C6Q'];
       $paper->C6M = $user['C6M'];
       $paper->C6N = $user['C6N'];
       $paper->M1Q = $user['M1Q'];
       $paper->M1M = $user['M1M'];
       $paper->M1N = $user['M1N'];
       $paper->M2Q = $user['M2Q'];
       $paper->M2M = $user['M2M'];
       $paper->M2N = $user['M2N'];
       $paper->M3Q = $user['M3Q'];
       $paper->M3M = $user['M3M'];
       $paper->M3N = $user['M3N'];
       $paper->M4Q = $user['M4Q'];
       $paper->M4M = $user['M4M'];
       $paper->M4N = $user['M4N'];
       $paper->M5Q = $user['M5Q'];
       $paper->M5M = $user['M5M'];
       $paper->M5N = $user['M5N'];
       $paper->M6Q = $user['M6Q'];
       $paper->M6M = $user['M6M'];
       $paper->M6N = $user['M6N'];
       $paper->total_marks = $user['total_marks'];
       $paper->save();
    File::makeDirectory('Quiz/advanced_paper/'.$request->papername);
       File::makeDirectory('Quiz/advanced_paper/'.$request->papername.'/question');
       File::makeDirectory('Quiz/advanced_paper/'.$request->papername.'/solution');
      $results='$results';
     $contents = "@extends($results==0 ? 'layout/advanced_paper' : 'layout/advanced_papershow')";
      Storage::disk('advanced_paper')->put($user['plink'],$contents);
     $pid=$paper->id;

  }
  foreach ($data2 as $user) {
    

      $paper = new question();

   $paper->qid = $user['qid'];
     $paper->pid = $pid;
     $paper->qtype = $user['qtype'];
     $paper->qpid = $user['qid']."X".$pid;
     $paper->qpqtypeid = $user['qid']."X".$pid."X".$user['qtype'];
     $paper->type = $user['type'];  
     $paper->q1 = $user['q1'];
     $paper->q2 = $user['q2'];
     $paper->q3 = $user['q3'];
     $paper->q4 = $user['q4'];
     $paper->q5 = $user['q5'];
     $paper->q6 = $user['q6'];
     $paper->q7 = $user['q7'];
     $paper->q8 = $user['q8'];
     $paper->active = '1';
      $paper->save();

    }

     return back(); 
    }
  }




  public function dpp(Request $request)
  {
      if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
         $users = dpp::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('subject', 'like', '%'.$studentsearch.'%')
           ->orWhere('reg_name', 'like', '%'.$studentsearch.'%');

           if($request->has('sub')&&$request->get('sub')!=''){
            $where=['subject'=>$request->get('sub'),'active'=>'1'];
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);}
          else{$users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);}
             return view('admin.dpp',compact('users'));
          } 
          else{
             if($request->has('sub')&&$request->get('sub')!=''){
            $where=['subject'=>$request->get('sub'),'active'=>'1'];
         $users = dpp::where($where)->orderBy('id','desc')->paginate(7);}
          else{$users = dpp::where('active','1')->orderBy('id','desc')->paginate(7);}
            return view('admin.dpp',compact('users'));
        }
  }

  public function dpp_page(Request $request)
  {
    if($request->has('s')&&$request->get('s')!=''){
           $studentsearch = $request->get('s');
         $users = dpp::where('pname', 'like', '%'.$studentsearch.'%')
           ->orWhere('subject', 'like', '%'.$studentsearch.'%')
           ->orWhere('reg_name', 'like', '%'.$studentsearch.'%');

           if($request->has('sub')&&$request->get('sub')!=''){
            $where=['subject'=>$request->get('sub'),'active'=>'1'];
          $users = $users->where($where)->orderBy('id', 'desc')->paginate(7);}
          else{$users = $users->where('active','1')->orderBy('id', 'desc')->paginate(7);}
             return view('admin.dpp_reload',compact('users'));
          } 
          else{
             if($request->has('sub')&&$request->get('sub')!=''){
            $where=['subject'=>$request->get('sub'),'active'=>'1'];
         $users = dpp::where($where)->orderBy('id','desc')->paginate(7);}
          else{$users = dpp::where('active','1')->orderBy('id','desc')->paginate(7);}
            return view('admin.dpp_reload',compact('users'));
        }
  }

  public function dpp_link(Request $request)
  {  

    $where=['dpp_id'=>$request->get('id'),'active'=>'1'];
          $users = dpp_link::where($where)->orderBy('id', 'desc')->get();
           $userss = dpp::where('id',$request->get('id'))->get();
          return view('admin.dpp_link',compact('users','userss'));
  }

  public function add_dpp(Request $request)
  {  $this->validate($request, [
                  'pname' => 'required',
                  'subject' => 'required'
          ]); 
    $uniquename=time().uniqid(rand());
      $name = $uniquename.'.pdf';
      $name_ans = $uniquename.'_1.pdf';
      $ques='';
      $ans='';
      $file1=$request->file('ques');
       $file2=$request->file('ans');
        if($request->hasfile('ques')){
                  $path=base_path().'/public_html/Quiz/dpp';
                  $file1->move($path,$name); 
                  $ques='Quiz/dpp/'.$name;
                }
                 if($request->hasfile('ans')){
                  $file2->move($path,$name_ans); 
                  $ans='Quiz/dpp/'.$name_ans;
                }
             $paper = new dpp();
       $paper->pname = $request->pname;
       $paper->subject = $request->subject;
        $paper->ques = $ques;
        $paper->ans = $ans;
       $paper->reg_id = Auth::user()->id;
       $paper->reg_name = Auth::user()->name;
       $paper->active = '1';
        $paper->save();
          return back()->with('success', 'uploaded Successfully');
  }

  public function add_dpp_link(Request $request){ 

  $rules = array (
                'dpp_id' => 'required',
                  'pname' => 'required',
                  'subject' => 'required',
                  'class' => 'required',
                  'course' => 'required',
                  'coursetype' => 'required',
                  'publishtime' => 'required',
                  'radio' => 'required'
      ); 
    $validator = Validator::make ( Input::all (), $rules );
      if ($validator->fails ()){
          return Response::json ( array ( 'errors' => $validator->getMessageBag ()->toArray ()) );
   } else {

        $paper = new dpp_link();
        $paper->dpp_id = $request->dpp_id;
        $paper->pname = $request->pname;
        $paper->subject = $request->subject;
        $paper->ques = $request->ques;
        $paper->ans = $request->ans;
        $paper->classid = $request->class;
        $paper->courseid = $request->course;
        $paper->coursetypeid = $request->coursetype;
        $paper->groupid = $request->radio;
        $paper->cccgid = $request->class.$request->course.$request->coursetype.$request->radio;
        $paper->publish_time= $request->publishtime;
        $paper->reg_id = Auth::user()->id;
        $paper->reg_name = Auth::user()->name;
        $paper->active = '1';
        $paper->save();
          return Response::json ($paper);
        }
  }

  public function delete_dpp(Request $request)
  {
    $teacher = dpp::where('id',$request->id)->get();
    foreach ($teacher as $tec) {
      $path=base_path().'/public_html/Quiz/dpp';
      file::delete($path.'/'.$tec->ques);
      file::delete($path.'/'.$tec->ans);
    }
    $teachers = dpp::where('id',$request->id)->delete();
    $teachers = dpp_link::where('dpp_id',$request->id)->delete();
   return response()->json($teachers);
  }

  public function delete_dpp_link(Request $request)
  {
   $teachers = dpp_link::where('id',$request->id)->delete();
   return response()->json($teachers);
  }
   public function delete_image(Request $request)
  {
    if($request->img_type=='ques'){
   $teachers = question::where('quesimg',$request->img)->update(['quesimg'=>NULL]);
    File::delete($request->img);
   return response()->json($teachers);
 
}
   else if($request->img_type=='sol'){
    $teachers = question::where('solimg',$request->img)->update(['solimg'=>NULL]);
    File::delete($request->img);
   return response()->json($teachers);
 
   }
  }
  }