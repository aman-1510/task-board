<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class normal_paper extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['pname', 'plink', 'type', 'active', 'NOQ', 'TT', 'PQ', 'PM', 'PN', 'CQ', 'CM', 'CN', 'MQ', 'MM', 'MN', 'BQ', 'BM', 'BN'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'remember_token',
    ];

    protected $table = 'normal_papers';
}
