<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lists extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
          'Tid','Uid','Bid','Lid','Aid','title','active'
    ];


    protected $table = 'lists';
}
