<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class checklist extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
          'Bid','Cid','Aid','description','complete','do','undo','active'
    ];


    protected $table = 'checklists';
}
