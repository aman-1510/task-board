<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lable extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
         'Bid','Aid','lable_id','lable_name','lable_colour','active'
    ];


    protected $table = 'lables';
}
