<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class card extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
         'Tid','Uid','Bid','Lid','Cid','Aid','title','description','lable_id','lable_name','lable_colour','checklist','docs_id','start_date','end_date','status','active'
    ];


    protected $table = 'cards';
}
