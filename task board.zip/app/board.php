<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class board extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
          'Tid','Uid','Bid','Aid','Btype','title','description','Aname','bg','start_date','end_date','status','active'
    ];


    protected $table = 'boards';
}
