<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class doc extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
         'Bid','Cid','Aid','title','link','active'
    ];


    protected $table = 'docs';
}
