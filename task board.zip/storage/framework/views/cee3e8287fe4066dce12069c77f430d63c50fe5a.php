<html>
<head>
<?php echo $__env->yieldContent('title'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- css files -->
<link href="<?php echo e(asset('website/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/team.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<!-- /css files -->
<!-- fonts -->
<link href='fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
<link href='fonts.googleapis.com/css?family=Nunito:400,300,700' rel='stylesheet' type='text/css'>
<!-- /fonts -->
<!-- js files -->
<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=devanagari,latin-ext"
	 rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<!-- /js files -->
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
	
	<!-- navigation -->
<header>
			<div class="container-fluid" style="margin-top: 15px;">
				<div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
					<!-- logo -->
					<div id="logo">
						<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.jpg')); ?>"></a>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav_w3ls">
						<nav>
							<label for="drop" class="toggle">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu" style="color: #777; `margin-top: 5px;">
								<li><a class="active" href="<?php echo e(route('home')); ?>" > Home </a></li>
								<li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Courses <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Courses <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
									<li><a href="<?php echo e(route('regular_courses')); ?>" class="drop-text">Regular Batch</a></li>
									<li><a href="<?php echo e(route('foundation_courses')); ?>" class="drop-text">Foundation Batch</a></li>
									</ul>
								</li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="<?php echo e(route('faq')); ?>" class="drop-text">Faq's</a></li>
										<li><a href="<?php echo e(route('gallery')); ?>" class="drop-text">Gallery</a></li>
										<li><a href="<?php echo e(route('team')); ?>" class="drop-text">Our Faculty</a></li>
									</ul>
								</li>
								<li><a href="<?php echo e(route('student-form')); ?>">Log In</a></li>
							</ul>
						</nav>
					</div>
					<!-- //nav -->
				</div>
			</div>
		</header>
<!-- /navigation -->

	<!-- faq -->
	<div class="about-inner py-5">
		<div class="container pb-xl-5 pb-lg-3">
			<div class="row py-xl-4">
				<div class="col-lg-6 welcome-right text-center mb-lg-0 mb-5">
					<img src="images/faq.png" alt="" class="img-fluid" />
				</div>
				<div class="col-lg-6 about-right-faq">
					<h3 class="mt-2 mb-3">Frequently asked questions</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse porta erat sit.</p>
					<p class="mt-3">Suspendisse porta erat sit amet eros sagittis, quis hendrerit libero aliquam. Fusce semper augue
						ac dolor
						efficitur.</p>
					<a href="about.html" class="btn button-style mt-sm-5 mt-4">Read More</a>
				</div>
			</div>
			<!-- accordions -->
			<ul class="accordion css-accordion mt-5">
				<li class="accordion-item">
					<input class="accordion-item-input" type="checkbox" name="accordion" id="item1" />
					<label for="item1" class="accordion-item-hd">At vero eos et accusamus et iusto odio dignissimos ducimus <span
						 class="accordion-item-hd-cta">&#9650;</span></label>
					<div class="accordion-item-bd">
						<h6 class="accordion-textm">AmetLorem ipsum dolor sit amet</h6>
						<p>Sodales quis.At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit ametLorem ipsum
							dolor sit amet,sed diam nonumy. Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
							dolore magna aliqua.</p>
					</div>
				</li>
				<li class="accordion-item">
					<input class="accordion-item-input" type="checkbox" name="accordion" id="item2" />
					<label for="item2" class="accordion-item-hd">Lorem ipsum dolor sit amet <span class="accordion-item-hd-cta">&#9650;</span></label>
					<div class="accordion-item-bd">
						<h6 class="accordion-textm">Dolores et ea rebum lorem ipsum</h6>
						<p>Duo dolores et ea rebum. Lorem ipsum dolor sit ametLorem ipsum
							dolor sit amet,sed diam nonumy. Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
							dolore magna aliqua.</p>
					</div>
				</li>
				<li class="accordion-item">
					<input class="accordion-item-input" type="checkbox" name="accordion" id="item3" />
					<label for="item3" class="accordion-item-hd">Tque corrupti quos dolores et quas molestias excepturi sint occaecati
						<span class="accordion-item-hd-cta">&#9650;</span></label>
					<div class="accordion-item-bd">
						<h6 class="accordion-textm">At vero eos et accusam et</h6>
						<p>sodales quis. At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit ametLorem ipsum
							dolor sit amet,sed diam nonumy. Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
							dolore magna aliqua.</p>
					</div>
				</li>
				<li class="accordion-item">
					<input class="accordion-item-input" type="checkbox" name="accordion" id="item4" />
					<label for="item4" class="accordion-item-hd">Dolores et quas molestias excepturi sint occaecati <span class="accordion-item-hd-cta">&#9650;</span></label>
					<div class="accordion-item-bd">
						<h6 class="accordion-textm">Lorem ipsum dolor sit amet</h6>
						<p>Sodales quis at vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit ametLorem ipsum
							dolor sit amet,sed diam nonumy. Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
							dolore magna aliqua.</p>
					</div>
				</li>
			</ul>
			<!-- //accordions -->
		</div>
	</div>
	<!-- //faq -->
				
<!--footer-->
<section class="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="links">
					<a href="index.html">Home</a>
					<a href="#about">About</a>
					<a href="#service">Services</a>
					<a href="#gallery">Gallery</a>
					<a href="#team">Team</a>
					<a href="#contact">Contact</a>
				</div>
			</div>
			<div class="col-md-6">
				<div class="copyright">
					<p> 2020 Inspire Academy. All Rights Reserved | Design by Delta-Trek </a></p>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- js files -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/SmoothScroll.min.js')); ?>"> </script>
<!-- js for banner -->
<script src="<?php echo e(asset('js/index.js')); ?>"></script>
<!-- /js for banner -->
<!-- js for gallery -->
<script src="<?php echo e(asset('js/darkbox.js')); ?>"></script>
<!-- /js for gallery -->
<!-- js for smooth navigation -->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

  // Store hash
  var hash = this.hash;

  // Using jQuery's animate() method to add smooth page scroll
  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
  $('html, body').animate({
    scrollTop: $(hash).offset().top
  }, 900, function(){

    // Add hash (#) to URL when done scrolling (default click behavior)
    window.location.hash = hash;
    });
  });
})
</script>
<!-- /js for smooth navigation -->
<!-- js for sliding animations -->
<script>
$(window).scroll(function() {
  $(".slideanim").each(function(){
    var pos = $(this).offset().top;

    var winTop = $(window).scrollTop();
    if (pos < winTop + 600) {
      $(this).addClass("slide");
    }
  });
});
</script>
<!-- /js for sliding animations -->
<!-- /js files -->
</body>
</html>

<?php echo $__env->make('layout/details', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>