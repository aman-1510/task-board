<?php $__env->startSection('head'); ?>
<title>Inspire Academy || IIT-JEE, NEET & MHT-CET</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Best success rate in all over maharashtra in JEE, NEET, CET & Olympiads.Inspire Academy achieves more than 80% selections from classroom courses and crash courses each year.Branches : Kolhapur,Karad & Satara
Add.: 2nd floor,Tathastu Corner,Shahupuri,Opp.railway Gate-416001 Contact:7972961299">
<meta name="keywords" content="inspire kolhapur, inspire, inspire Academy, inspire portal, inspirekolhapur, inspirekolhapur.in,Best institute for IIT coaching, iitjee Kolhapur, iit scholarship exam, iit top rankers, Aieee coaching, AIPMT, NEET coaching">
<link rel="canonical" href="https://inspirekolhapur.in"/>
 <script type="application/ld+json">
    {"@context":"https://schema.org",
    "@type":"Article",
    "mainEntityOfPage":
    {"@type":"WebPage",
    "@id":" https://inspirekolhapur.in/#webpage",
    "name":" Inspire Academy || IIT-JEE, NEET & MHT-CET",
    "url":" https://inspirekolhapur.in/", 
    "inLanguage":"en-US"},
    "headline":" Inspire Academy || IIT-JEE, NEET & MHT-CET",
    "description":" Best success rate in all over maharashtra in JEE, NEET, CET & Olympiads.Inspire Academy achieves more than 80% selections from classroom courses and crash courses each year.Branches : Kolhapur,Karad & Satara.",

    "image":" https://inspirekolhapur.in/adminsa/images/logo.png ",

    "keywords":" inspire kolhapur, inspire, inspire Academy, inspire portal, inspirekolhapur, inspirekolhapur.in,Best institute for IIT coaching, iitjee Kolhapur, re iit scholarship exam, iit top rankers, Aieee coaching, AIPMT, NEET coaching",

    "datePublished":"2020-10-12T11:14:27+00:00",
    "dateModified":"2020-01-15T10:15:38+00:00",
    "author":{"@id":"https://inspirekolhapur.in/#person",
    "@type":"Person",
    "name":"Inspire Kolhapur"}, 
    "publisher":
    {"@type":"Organization",
    "@id":"https://inspirekolhapur.in/#organization",
    "name":"Inspire Academy",
    "description":"Best success rate in all over maharashtra in JEE, NEET, CET & Olympiads.Inspire Academy achieves more than 80% selections from classroom courses and crash courses each year.Branches : Kolhapur,Karad & Satara.",
    "logo":
    {"@type":"ImageObject",
    "@id":"https://inspirekolhapur.in/#logo",
    "url":"https://inspirekolhapur.in/adminsa/images/logo.png",
    "width":275,"height":60,
    "caption":"Inspire Academy || IIT-JEE, NEET & MHT-CET"}
    }}
    }
    </script>
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "url": "https://inspirekolhapur.in/",
  "logo": "https://inspirekolhapur.in/adminsa/images/logo.png",
  "contactPoint": [{
    "@type": "ContactPoint",
    "telephone": "7972961299, 0231-2522422, 9146814500",
    "contactType": "enquiry service"
  }]
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">SignUp For Free Test Series.</h4>
        </div>
        <div class="modal-body">
        <p id="add-error" class="add-error text-center alert alert-danger" style="display: none;"></p>
        <p id="add-success" class=" text-center alert alert-success" style="display: none;">OTP successfully verified...</p>
         <div class="container" id="container">
    <div class="form-container sign-up-container">
      <form id="form1" class="form-horizontal" role="modal">
        <?php echo csrf_field(); ?>
        <h2>Sign Up</h2>
        <span>Use mobile number for registration</span>
        <input type="text" placeholder="Name"  id="add-name" name="add-name" required="">
        <input type="text" placeholder="Institute Name"  id="add-insname" name="add-insname" required="">
        <input type="number" placeholder="mobile number" id="add-mobile" name="add-mobile" required="">
        <input type="password" placeholder="password (minimum 6 characters)" id="add-password" name="add-password2" required="">
        <p id="addpserror"></p>
        <input type="password" placeholder="Conform password" id="add-password1" name="add-password" required="">
        <div class="col-sm-12 row">
        <div  class="col-sm-4"> 
        <label>JEE&nbsp;<input type="radio" name="add-cat" value="JEE (Main + Advance)" required=""></label>
        </div>
        <div class="col-sm-4">        
        <label>NEET&nbsp;<input type="radio" name="add-cat" value="NEET + AIIMS" required=""></label>
    </div>
    </div>
        <button type="button" id="signupattemt">Sign up</button>
   
      </form>
       <form id="form2" class="form-horizontal" role="modal" style="display: none;">
        <?php echo csrf_field(); ?>
        <h2>Mobile Verification</h2>
        <span>please inter you OTP here.</span>
        <input type="number" placeholder="OTP"  name="otp" required="">
       
        <button type="button" id="otpattemt">Verify OTP</button>
      </form>
       <form method="POST" action="<?php echo e(route('student-login')); ?>" style="display: none;">
        <?php echo csrf_field(); ?>
        <input type="hidden" placeholder="OTP"  name="username"  id="loguser" required="">
        <input type="hidden" placeholder="OTP"  name="password"  id="logpass" required="">
       
        <button type="submit" id="signin"></button>
      </form>
    </div>
   
      </div>
        </div>
      </div>
      
    </div>
  </div>
<script type="text/javascript">
  function modal() {
  $('#myModal').modal("show");
  $('.modal-backdrop').css('display','none');
  }
$('#add-password1').keyup(function(){
    var add_password = $('#add-password').val();
  var add_password1 = $('#add-password1').val();
  if(add_password==add_password1) {
    $('#addpserror').html('');
    $('#signupattemt').attr('disabled',false);
  }
  else{
    $('#addpserror').html('** password are not matching');
    $('#addpserror').css('color','red');
    $('#signupattemt').attr('disabled',true);
  }
});
   $('#add-mobile').keyup(function(){
    var mob = document.getElementById('add-mobile').value;
    if(mob.length==10){
    $('#add-error').css('display','none');  
    }

   });
   $('#signupattemt').click(function() {
    if($('#add-name').val()!=''&& $('#add-name').val()!='' && $('#add-insname').val()!=''&& $('#add-mobile').val()!='' && $('#add-password').val()!='' &&$('#add-password1').val()!='' && $("input:radio[name='add-cat']").is(":checked")){
      $('#add-error').css('display','none');
  var add_password = $('#add-password').val();
  var add_password1 = $('#add-password1').val();
  if(add_password!=add_password1) {
    $('#addpserror').html('** password are not matching');
    $('#addpserror').css('color','red');
    $('#signupattemt').attr('disabled',true);
  }
  else{

    var mob = document.getElementById('add-mobile').value;
    var pass = document.getElementById('add-password1').value;
    if(mob.length==10){
    $('#addpserror').html('');
    if(pass.length<6){
    $('#add-error').html('** password should contain atleast 6 characters.');
    $('#add-error').css('display','block');
    }
    else{
      $.ajax({
      type: 'POST',
      url: '<?php echo e(route('home-sign_up')); ?>',
      data: {
        '_token': $('input[name=_token]').val(),
        'cat': $("input[name='add-cat']:checked").val(),
        'name': $('input[name=add-name]').val(),
        'insname': $('input[name=add-insname]').val(),
        'mobile': $('input[name=add-mobile]').val(),
        'password': $('input[name=add-password]').val()
      },
      success: function(data){
        if ((data.error)) {
     $('#add-error').html('** Mobile number already registered.');
    $('#add-error').css('display','block');
        }
        else{
        $('#form1').css('display','none');
        $('#form2').css('display','block');
    }

      },

    });
  }
  }else{
    $('#add-error').html('** Invalid mobile number.');
    $('#add-error').css('display','block');
  }
    }
}
else{
$('#add-error').html('** please fill all details.');
    $('#add-error').css('display','block');
}
  });

$('#otpattemt').click(function() {
 $.ajax({
      type: 'POST',
      url: '<?php echo e(route('home-otpcheck')); ?>',
      data: {
        '_token': $('input[name=_token]').val(),
        'mobile': $('input[name=add-mobile]').val(),
        'otp': $('input[name=otp]').val()
      },
      success: function(data){
          if ((data.error)) {
     $('#add-error').html('** please inter correct OTP.');
    $('#add-error').css('display','block');
        }
        else{
        $('#loguser').val($('input[name=add-mobile]').val());
        $('#logpass').val($('input[name=add-password]').val());
        $('input[name=add-mobile]').val('');
        $('input[name=add-name]').val('');
        $('input[name=add-insname]').val('');
        $('input[name=add-password]').val('');
        document.getElementById("signin").click();
    }
      },

    });
});
</script>
<section class="banner" >
  <img class="mySlides w3-animate-fading" src="<?php echo e(asset('website/images/banner4.jpg')); ?>" style="width: 100%; align-items: center;">
  <img class="mySlides w3-animate-fading" src="<?php echo e(asset('website/images/banner1.jpg')); ?>" style="width: 100%; align-items: center;">
  <img class="mySlides w3-animate-fading" src="<?php echo e(asset('website/images/banner2.jpg')); ?>" style="width: 100%; align-items: center;">
  <img class="mySlides w3-animate-fading" src="<?php echo e(asset('website/images/banner3.jpg')); ?>" style="width: 100%; align-items: center;">
<div class="signup_div"><h4>Free revision test series as per new JEE Mains & NEET Pattern  designed by expert IITian faculties to strengthen your exam preparation while at home. </h4>
<a class="btn btn-success" style="box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);" onclick="modal()"><b>Click here to enroll</b></a></div>
</section>  
<!-- /banner section -->

<!-- About Section -->
<section class="about-us" id="about">
  <div class="container-fluid">
    <div class="row"> 
      <div class="col-lg-6 about-info1 " style="padding: 30px 0px 0px 5px; ">
        <img src="website/images/about-img.jpg" alt="about" class="img-responsive">
      </div>
      <div class="col-lg-6 about-info2 ">
        <div class="about-details" style="">
          <div class="row" >
   <div class="col-md-12">
       <div class="widget-item" style="zoom:0.92;">
            <h2>Welcome to&nbsp;Inspire Academy</h2>
<p><strong>Inspire Academy is a&nbsp;premier coaching institute in Kohlapur, Satara and Karad&nbsp;which trains students preparing for JEE (Mains), JEE (Advanced), NEET, MHT-CET and other engineering and medical entrance exams.</strong></p>
<p>What&nbsp;was started in 2017 with the purpose of providing the students a world class studying experience and prepare them for competitive exams, Inspire Academy has turned into one of the successful coaching institutes since then. Inspire Academy is about consistency in results, commitment , dedication and culture.&nbsp; We believe in maintaining quality and giving our best to the student.</p>

                        </div> <!-- /.widget-item -->
                    </div> <!-- /.col-md-12 -->
                                   </div>
        </div>  
      </div>
    </div>
  </div>    
</section>
<!-- /About Section -->
<!-- Service Section -->
<section class="our-services slideanim" id="service" >
  <h3 class="text-center slideanim">Our Advantages </h3>
  <p class="text-center slideanim">Stay ahead with all-round performance in your chosen stream.</p>
  <div class="container">
    <div class="row">
      
      
      <div class="col-lg-4 col-md-6 col-sm-6 serv-part">
        <div class="row">
          <div class="col-xs-6 slideanim">
            <i class="fa fa-graduation-cap" aria-hidden="true"></i>
          </div>
          <div class="col-xs-6 slideanim">
            <div class="serv-info">
              <h4>Experienced IITian Faculty</h4>
              <p class="serv">With a large pool of highly qualified and experienced faculty members.</p>
            </div>  
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 col-sm-6 serv-part">
        <div class="row">
          <div class="col-xs-6 slideanim">
            <i class="fa fa-signal" aria-hidden="true"></i>
          </div>
          <div class="col-xs-6 slideanim">
            <div class="serv-info">
              <h4> Excelent Selection Performance</h4>
              <p class="serv">We have a good selection ratio in every type of exams. </p>
            </div>  
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 col-sm-6 serv-part">
        <div class="row">
          <div class="col-xs-6 slideanim">
            <i class="fa fa-bars" aria-hidden="true"></i>
          </div>
          <div class="col-xs-6 slideanim">
            <div class="serv-info">
              <h4>Comprehensive Study Material</h4>
              <p class="serv">We provide complete study material package with regular assignment for daily practice.</p>
            </div>  
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 col-sm-6 serv-part">
        <div class="row">
          <div class="col-xs-6 slideanim">
            <i class="fa fa-desktop" aria-hidden="true"></i>
          </div>
          <div class="col-xs-6 slideanim">
            <div class="serv-info">
              <h4>Weekly Tests</h4>
              <p class="serv">We conduct our Tests weekly in both formats, online as well as offline. </p>
            </div>  
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 col-sm-6 serv-part">
        <div class="row">
          <div class="col-xs-6 slideanim">
            <i class="fa fa-video-camera" aria-hidden="true"></i>
          </div>
          <div class="col-xs-6 slideanim">
            <div class="serv-info">
              <h4>Motivational Lectures</h4>
              <p class="serv">Stories for mentally happiness and satisfaction by which students get motivated for better learning. </p>
            </div>  
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 col-sm-6 serv-part">
        <div class="row">
          <div class="col-xs-6 slideanim">
            <i class="fa fa-hourglass" aria-hidden="true"></i>
          </div>
          <div class="col-xs-6 slideanim">
            <div class="serv-info">
              <h4>Parents Teacher Meeting</h4>
              <p class="serv">PTM are conducted on a regular basis for interaction with guardians.</p>
            </div>  
          </div>
        </div>
      </div>
      
      
  </div>
</section>
<!-- /Service Section -->
<!-- Team -->
<section class="our-team" id="team">
  <h3 class="text-center slideanim">Best Of The Best, Our Faculty</h3>
  <p class="text-center slideanim">A teacher is a compass that activates the magnets of curiosity, knowledge, and wisdom in the pupils.</p>
  <div class="container">
    <section class="main">
      <ul class="ch-grid">
        <li class="t1" style="margin-bottom: 100px;">
          <div class="ch-item slideanim">       
            <div class="ch-info">
              <div class="ch-info-front ch-img-1"></div>
              <div class="ch-info-back1">
                <ul class="social-icons">
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                </ul>
              </div>  
            </div>
          </div>
          <h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Dipak Gupta</h4>
              <p class="card-text" >
                <h5 style="color: #fff;">B-Tech IIT-Kharagpur</h5>
                <p style="color: #fff;">Physics</p>
              </p>
        </li>
        <li class="t2" style="margin-bottom: 100px;">
          <div class="ch-item slideanim">
            <div class="ch-info">
              <div class="ch-info-front ch-img-2"></div>
              <div class="ch-info-back2">
                <ul class="social-icons">
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
          <h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Vasu Guduri</h4>
              <p class="card-text" >
                <h5 style="color: #fff;">B-Tech IIT-Bombay</h5>
                <p style="color: #fff;">Chemistry</p>
              </p>
        </li>
        <li class="t3" style="margin-bottom: 100px;">
          <div class="ch-item slideanim">
            <div class="ch-info">
              <div class="ch-info-front ch-img-3"></div>
              <div class="ch-info-back3">
                <ul class="social-icons">
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
          <h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Shubham Kr. Bansal</h4>
              <p class="card-text" >
                <h5 style="color: #fff;">B-Tech IIT-Varanasi</h5>
                <p style="color: #fff;">Mathematics</p>
              </p>
        </li>
        <li class="t4" style="margin-bottom: 130px;">
          <div class="ch-item slideanim">
            <div class="ch-info">
              <div class="ch-info-front ch-img-4"></div>
              <div class="ch-info-back4">
                <ul class="social-icons">
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
          <h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Sajid Shaikh</h4>
              <p class="card-text" >
                <h5 style="color: #fff;">PhD Shivaji University</h5>
                <p style="color: #fff;">Biology</p>
              </p>
        </li>
        <li class="t5" style="margin-bottom: 100px;">
          <div class="ch-item slideanim">
            <div class="ch-info">
              <div class="ch-info-front ch-img-5"></div>
              <div class="ch-info-back5">
                <ul class="social-icons">
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
            <h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Varsha Sankpal</h4>
              <p class="card-text" >
                <p style="color: #fff;">Manager</p>
              </p>
        </li>
      </ul>
    </section>           
    </div>

</section>  
<!-- /Team -->
<!-- services -->
  <section class="banner-bottom-bg-li py-5 slideanim" id="services" >
    <div class="container py-xl-5 py-lg-3" style=" line-height: 1.9em; letter-spacing: 1px;">
      <h3 class="tittle text-center font-weight-bold " style="margin-top: 25px;">Testimonials</h3>
      <p class="sub-tittle text-center mt-3 mb-sm-5 mb-4" style="font-size: 24px;">What students say about us</p>
      <div class="row pt-lg-4">
        <div class="col-lg-4 about-in text-center slideanim" style="padding: 15px 15px 15px 15px;">
          <div class="card">
            <img class="card-img-top" src="<?php echo e(asset('website/images/student1.jpg')); ?>" width="80%" style="max-height: 280px; max-width: 250px;" alt="Card image cap">
            <div class="card-body"style="font-size: 15px;">
              <h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Prasad Bhosale
                <p style="font-size: 15px;"><br>JEE Main Jan 2020(percentile-99.86)</p></h4>
              <p class="card-text">
                <br>I have been a student of Inspire Academy from past 2 years. Throughout my study, I mostly focused on what had been taught in the class rather than books. It wouldn’t be possible without the great efforts of my teachers and parents. I always focus on the concepts which is the main reason behind my success.
                
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 about-in text-center slideanim" style="padding: 15px 15px 15px 15px;">
          <div class="card">
            <img class="card-img-top" src="<?php echo e(asset('website/images/student4.jpg')); ?>" width="80%" style="max-height: 280px; max-width: 250px;" alt="Card image cap">
            <div class="card-body"style="font-size: 15px;">
              <h4 class="card-title mt-4 mb-3"style="font-size: 22px; padding: 25px 0px 5px 0px;">Harsh Kurne
                <p style="font-size: 15px;"><br>(IIT Kharagpur)</p></h4>
              <p class="card-text">
                <br>I’m grateful to entire Inspire Academy for their constant support and motivation. My teachers always had complete faith on my capability. I thank Inspire Academy for my success in IIT-JEE.
              
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 about-in text-center slideanim" style="padding: 15px 15px 15px 15px;">
          <div class="card">
            <img class="card-img-top" src="<?php echo e(asset('website/images/student6.jpg')); ?>" width="80%" style="max-height: 280px; max-width: 250px;" alt="Card image cap">
            <div class="card-body"style="font-size: 15px;">
              <h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Soham Joshi 
                <p style="font-size: 15px;"><br>(IIIT Banglore JEE Advance Rank-4106)</p></h4>
              <p class="card-text">
                <br>I have joined Inspire Academy in 12th class. My main focus was always on the concept taught in the class. I relied on the experience of my faculties. I always focused on the basic concepts instead of quantity of questions.<br><br>
                
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 about-in text-center slideanim" style="padding: 15px 15px 15px 15px;">
          <div class="card">
            <img class="card-img-top" src="<?php echo e(asset('website/images/student5.jpg')); ?>" width="80%" style="max-height: 280px; max-width: 250px;" alt="Card image cap">
            <div class="card-body"style="font-size: 15px;">
              <h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Arya Phalke
                <p style="font-size: 15px;"><br>(NTSE Maharashtra Rank -09)</p></h4>
              <p class="card-text">
                <br>Inspire Academy the best coaching found the best teachers and friends-a new and loving family. learnt so much.Best years of my Life. <br><br><br><br>
              </p>
            </div>
          </div>
        </div>
        
        
        
      </div>
    </div>
  </section>
<!-- Gallery Section -->
<section class="our-gallery" id="gallery" style="background-color: rgb(255,255,255);">
  <h3 class="text-center ">Our Gallery</h3>
  <p class="text-center ">Our Institute gallery showing various picture of events,student,location and many other thing about our institute.</p>
  <div class="container" style="background-color: rgb(255,255,255);">
    <img src="website/images/g1.jpg" data-darkbox="website/images/g1.jpg" class="img-responsive slideanim">
        <img src="website/images/g2.jpg" data-darkbox="website/images/g2.jpg" class="img-responsive slideanim">
    <img src="website/images/g14.jpg" data-darkbox="website/images/g14.jpg" class="img-responsive slideanim">
    <img src="website/images/g6.jpg" data-darkbox="website/images/g6.jpg" class="img-responsive slideanim">
    <img src="website/images/g5.jpg" data-darkbox="website/images/g5.jpg" class="img-responsive slideanim">
    <img src="website/images/g4.jpg" data-darkbox="website/images/g4.jpg" class="img-responsive slideanim">
    <img src="website/images/g7.jpg" data-darkbox="website/images/g7.jpg" class="img-responsive slideanim">
    <img src="website/images/g8.jpg" data-darkbox="website/images/g8.jpg" class="img-responsive slideanim">
    <img src="website/images/g9.jpg" data-darkbox="website/images/g9.jpg" class="img-responsive slideanim">
    <img src="website/images/g10.jpg" data-darkbox="website/images/g10.jpg" class="img-responsive slideanim">
    <img src="website/images/g11.jpg" data-darkbox="website/images/g11.jpg" class="img-responsive slideanim">
    <img src="website/images/g12.jpg" data-darkbox="website/images/g12.jpg" class="img-responsive slideanim">
    <img src="website/images/g13.jpg" data-darkbox="website/images/g13.jpg" class="img-responsive slideanim">
    <img src="website/images/g3.jpg" data-darkbox="website/images/g3.jpg" class="img-responsive slideanim">
    <img src="website/images/g15.jpg" data-darkbox="website/images/g15.jpg" class="img-responsive slideanim">
    <img src="website/images/g16.jpg" data-darkbox="website/images/g16.jpg" class="img-responsive slideanim">
  </div>
</section>  
<!-- /Gallery section -->

<section class="banner-bottom-bg-li py-5" id="services" >
    <div class="container py-xl-5 py-lg-3" style=" line-height: 1.9em; letter-spacing: 1px;">
      <h3 class="tittle text-center font-weight-bold  slideanim" style="margin-top: 25px;">Our Branches</h3>
      <div class="row pt-lg-4">
        <div class="col-lg-4 about-in text-center  slideanim" style="padding: 8px 8px 8px 8px;">
          <div class="card">
            <div class="card-body"style="font-size: 15px;">
            <h4 class="card-title mt-4 mb-3"style="font-size: 18px;"><i class="fa fa-map-marker"></i> Kolhapur Branch</h4>
              <p class="card-text">
                <br><i class="fa fa-home"></i> 2nd Floor, Tathastu Corner, Shahupuri, Opp. Railway Gate, Kolhapur - 416001.
                <br><i class="fa fa-phone"></i> 7972961299 | 0231-2522422 | 9146814500. 
                
              </p>
            </div>
          </div>
        </div>
            <div class="col-lg-4 about-in text-center  slideanim" style="padding: 8px 8px 8px 8px;">
          <div class="card">
            <div class="card-body"style="font-size: 15px;">
            <h4 class="card-title mt-4 mb-3"style="font-size: 18px;"><i class="fa fa-map-marker"></i> Satara Branch</h4>
              <p class="card-text">
                <br><i class="fa fa-home"></i> 1st Floor, Lucky Plaza, Opp. Sainik School Ground, Z.P. Chowk, Satara - 415001.
                <br><i class="fa fa-phone"></i> 9145550011 | 02162-234333.
                <br>
                <br>
              </p>
            </div>
          </div>
        </div>
          <div class="col-lg-4 about-in text-center  slideanim" style="padding: 8px 8px 8px 8px;">
          <div class="card">
            <div class="card-body"style="font-size: 15px;">
            <h4 class="card-title mt-4 mb-3"style="font-size: 18px;"><i class="fa fa-map-marker"></i> Karad Branch</h4>
              <p class="card-text">
                <br><i class="fa fa-home"></i> Plot No. 49-50, Yashwant Colony, Vidyanagar, Karad - 415110.
                <br><i class="fa fa-phone"></i> 7775050058 | 9921992192.
                <br>
                <br>
                <br>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><!-- /Contact -->
<!-- Google Map -->
<section class="map">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 slideanim">
        <iframe class="googlemaps" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d19396.72988070512!2d74.23992354330721!3d16.701944511800782!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc100401e5815d7%3A0xec1c1df0f7a2d0e3!2sInspire%20Academy!5e0!3m2!1sen!2sin!4v1580742009413!5m2!1sen!2sin" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>  
    </div>
  </div>
</section>
<!-- /Google Map -->
<!-- Contact -->

<section class="contact-us slideanim" id="contact">
  <h3 class="text-center slideanim">Contact Us</h3>
  <p class="text-center slideanim"></p>
  <div class="container">   
    <div class="row">
      <div class="col-lg-5 col-md-5">
        <div class="contact-info">
          <h4>Connect With Us :-</h4>
          <p><strong>Phone :</strong> 7972961299 | 0231-2522422 | 9146814500</p>
          <p><strong>Email :</strong> <a href="mailto:support@inspirekolhapur.in">support@inspirekolhapur.in</a></p>
          <p class="addr"><strong>Address :</strong> 2nd-floor, Tathastu Corner,Shahupuri, Kolhapur, Maharashtra</p>
          <ul class="social-icons2">
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-7 col-md-7">
        <form action="<?php echo e(route('ThankYou')); ?>" method="post" >
          <?php echo csrf_field(); ?>
          <div class="row" style="color: black;">
            <div class="col-sm-12 form-group slideanim">
              <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
            </div>
          </div>
          <div class="row" style="color: black;">
            <div class="col-sm-12 form-group slideanim">
              <input class="form-control" id="mobile" name="Mobile" placeholder="Mobile no." type="text" required>
            </div>
          </div>
          <div class="row email-bar">
            <div class="col-sm-12 form-group slideanim">
              <input class="form-control" id="email" name="email" placeholder="Email" type="email">
               <input type="hidden" name="class" value="">
                <input type="hidden" name="course" value="">
            </div>
          </div>
          <textarea class="form-control slideanim" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
          <div class="row">
            <div class="col-sm-12 form-group">
              <button class="btn btn-outline1 btn-lg" type="submit">Send</button>
            </div>
          </div>
        </form>     
      </div>
    </div>
  </div>
</section>
<style type="text/css">
  .modal-backdrop.in{
    opacity: 0;
  }
.signup_div{
text-align: center;
width: 90%;
margin-left: 5%;
 margin-top: 10px;
 padding: 20px;
 color: #fff;
 background-color: #31b0d5;
  box-shadow: 0 14px 28px rgba(0,0,0,0.35), 0 10px 10px rgba(0,0,0,0.32);
}
.container{
  border-radius: 10px;
  position: relative;
  overflow: hidden;
  width:1200px;
  max-width: 100%;
}

.form-container form {
  background: #fff;
  display: flex;
  flex-direction: column;
  padding: 0 5%;
  width: 100%;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.form-container input {
  background: #eee;
  border: none;
  padding: 12px 15px;
  margin: 8px 0;
  width: 100%;
}
button {
  border-radius: 20px;
  border: 1px solid #ff4b2b;
  background: #ff4b2b;
  color: #fff;
  font-size: 12px;
  font-weight: bold;
  padding: 12px 45px;
  letter-spacing: 1px;
  text-transform: uppercase;
  transition: transform 80ms ease-in;
}
button:active {
  transform: scale(0.95);
}
button:focus{
  outline: none;
}
button.ghost{
  background: transparent;
  border-color: #fff;
}
.form-container{
  top: 0;
  transition: all 0.6s ease-in-out;
}

</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>