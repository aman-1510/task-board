<?php $__env->startSection('title'); ?>
<title> || IIT-JEE, NEET</title>
<meta name="description" content="Contrivance IIT and Medical is a premier institute for the preparation of NEET/IIT-JEE/MHT-CET/Boards/KVPY and the competitive examinations based on PCMB syllabus. We are based out of Pune and we have a pool of experienced and qualified faculties from IITs/ NITs/ GFTIs. We have special batches for CBSE/ICSE/State Board students to cater the specific requirements of the students. You can contact us @ 7378944442/3/5/6 or visit our office at 156, C Wing, Shoppers Orbit, Pune Alandi Road, Vishrantwadi, Pune-411015">
<meta name="keywords" content="contrivanceonline, contrivance, contrivance portal, contrivance maharashtra, contrivanceonline.in , iit ,neet, MHT-CET,CET,Kvpy,Olympiads,Bestinstitute,Maharashtra CET">
<link rel="canonical" href="https://deltatrek.in" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<p>© 2019 Delta Trek | Designed by  <a>Delta Trek</a> </p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footers'); ?>

           <div class="col-md-12" style="min-height: 5vh; max-height: 5vh;padding-top: 6px;background-color: rgba(43, 43, 51, 0.9);">
                      <p style=" color: #fff" class="text-center">© 2019 Delta Trek. | Designed by  <a style=" color: #fff">Delta Trek</a> </p>
                    </div>  
<?php $__env->stopSection(); ?>