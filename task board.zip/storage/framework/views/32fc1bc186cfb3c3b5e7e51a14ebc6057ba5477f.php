<html>
<head>
<?php echo $__env->yieldContent('title'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- css files -->
<link href="<?php echo e(asset('website/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/team.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<!-- /css files -->

<!-- js files -->
<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<!-- /js files -->
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
	<!-- navigation -->
<header>
			<div class="container-fluid" style="margin-top: 15px;">
				<div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
					<!-- logo -->
					<div id="logo">
						<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.jpg')); ?>"></a>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav_w3ls">
						<nav>
							<label for="drop" class="toggle">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu" style="color: #777; `margin-top: 5px;">
								<li><a  href="<?php echo e(route('home')); ?>" > Home </a></li>
								<li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Courses <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Courses <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
									<li><a class="active" href="<?php echo e(route('regular_courses')); ?>" class="drop-text">Regular Batch</a></li>
									<li><a href="<?php echo e(route('foundation_courses')); ?>" class="drop-text">Foundation Batch</a></li>
									</ul>
								</li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="<?php echo e(route('faq')); ?>" class="drop-text">Faq's</a></li>
										<li><a href="<?php echo e(route('gallery')); ?>" class="drop-text">Gallery</a></li>
										
										<li><a href="<?php echo e(route('team')); ?>" class="drop-text">Our Faculty</a></li>
									</ul>
								</li>
								<li><a href="<?php echo e(route('student-form')); ?>">Log In</a></li>
							</ul>
						</nav>
					</div>
					<!-- //nav -->
				</div>
			</div>
		</header>
<!-- /navigation -->
<!-- services -->
	<section class="banner-bottom-bg-li py-5" id="services" >
		<div class="container py-xl-5 py-lg-3">
			<h3 class="tittle text-center font-weight-bold">Courses</h3>
			<p class="sub-tittle text-center mt-3 mb-sm-5 mb-4">Our Regular Classroom Courses</p>
			<div class="row pt-lg-4">
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;" style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;" style="font-size: 18px;">Engineering Classroom Course <br> for Class XI</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">2nd April & 20 April 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Medical Classroom Course <br> for Class XI</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">2nd April & 20 April 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Engineering Classroom Course <br> for Class XII</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">1st March 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Medical Classroom Course <br> for Class XII</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">1st March 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Engineering Classroom Course <br> for Dropers</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">20 April 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Medical Classroom Course <br> for Dropers</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">20 April 2020</p><br>
							</p>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- //services -->
	<!-- stats -->
	<section class="bottom-count py-5" id="stats">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-lg-5 left-img-w3ls">
					<img src="images/b2.png" alt="" class="img-fluid" />
				</div>
				<div class="col-lg-7 right-img-w3ls pl-lg-4 mt-lg-2 mt-4">
					<div class="bott-w3ls mr-xl-5">
						<h3 class="title-w3 text-bl mb-3 font-weight-bold">Salient features of the course are:</h3> <br>
						<p style="font-size: 16px;">The level of the X standard is very easy in comparison to the level which students face in engineering entrance exams. In order to bridge the gap, a student must be given a clear understanding&nbsp;of the basics through simplified&nbsp;concepts and exercises which not only help them in cracking&nbsp;entrance exams&nbsp;but also in his academics. To accomplish this delicate task, we have designed our course that prepares students for IIT-JEE and Board exams at a stress-free and comfortable pace.</p>
						<p style="font-size: 16px;">We have designed our course to cover both subjective and objective type questions so that our students can fare well at both JEE as well as Board examination and succeed.</p>
					</div>
					<div style="zoom:1.5; align-self: center; margin-top: 20px; ">
								<p style="font-size: 20px;">For free demo lectures & futher enquiry</p>
								<a href="<?php echo e(route('form')); ?>"> <button type="button" class="btn btn-primary"  >Click Here</button> </a>
							</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //stats -->
<section class="footer">
	<div class="container">
				<div class="copyright">
					<p style="text-align: center;"> 2020 Inspire Academy. All Rights Reserved | Design by Delta-Trek </a></p>
				</div>
			</div>
</section>

<!-- js files -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/SmoothScroll.min.js')); ?>"> </script>
<!-- js for banner -->
<script src="<?php echo e(asset('js/index.js')); ?>"></script>
<!-- /js for banner -->
<!-- js for gallery -->
<script src="<?php echo e(asset('js/darkbox.js')); ?>"></script>
<!-- /js for gallery -->
<!-- js for smooth navigation -->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

  // Store hash
  var hash = this.hash;

  // Using jQuery's animate() method to add smooth page scroll
  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
  $('html, body').animate({
    scrollTop: $(hash).offset().top
  }, 900, function(){

    // Add hash (#) to URL when done scrolling (default click behavior)
    window.location.hash = hash;
    });
  });
})
</script>
<!-- /js for smooth navigation -->
<!-- js for sliding animations -->
<script>
$(window).scroll(function() {
  $(".slideanim").each(function(){
    var pos = $(this).offset().top;

    var winTop = $(window).scrollTop();
    if (pos < winTop + 600) {
      $(this).addClass("slide");
    }
  });
});
</script>
<!-- /js for sliding animations -->
<!-- /js files -->
</body>
</html>

<?php echo $__env->make('layout/details', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>