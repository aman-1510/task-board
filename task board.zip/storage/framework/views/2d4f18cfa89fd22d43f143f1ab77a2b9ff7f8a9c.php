<?php $__env->startSection('title'); ?>
<title>Inspire Academy || IIT-JEE, NEET & MHT-CET</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Best success rate in all over maharashtra in JEE, NEET, CET & Olympiads.Inspire Academy achieves more than 80% selections from classroom courses and crash courses each year.Branches : Kolhapur,Karad & Satara
Add.: 2nd floor,Tathastu Corner,Shahupuri,Opp.railway Gate-416001 Contact:7972961299">
<meta name="keywords" content="inspire kolhapur, inspire, inspire Academy, inspire portal, inspirekolhapur, inspirekolhapur.com">
<link rel="canonical" href="https://inspirekolhapur.in" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<p>2020 Inspire Academy. | Designed by Delta Trek</a> </p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footers'); ?>

           <div class="col-md-12" style="min-height: 5vh; max-height: 5vh;padding-top: 6px;background-color: rgba(43, 43, 51, 0.9);">
                      <p style=" color: #fff" class="text-center">2020 Inspire Academy. | Designed by  <a style=" color: #fff">Delta Trek</a>  </p>
                    </div>  
<?php $__env->stopSection(); ?>