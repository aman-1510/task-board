<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Eazy FOOD | Sign in/Sign up</title>
  <script src="https://kit.fontawesome.com/e30a91579f.js"></script>
  <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
   <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
  <script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
</head>
<body>
  <style media="screen">
    body{
      background:url("<?php echo e(asset('img/inspire.jpg')); ?>");
      background-size: cover;
      background-repeat: no-repeat;
    }
  </style>

  <div class="container" id="container">
    <div class="form-container sign-up-container">
    	<p id="add-error1" class="add-error text-center alert alert-danger" style="display: none;"></p>
      <form id="formsignup" class="form-horizontal" role="modal">
        <h1>Create Account</h1>
        <span>Use email for registration</span>
        <input type="text" placeholder="Name" name="name" id="signup-name" required="">
        <input type="email" placeholder="Email" name="email" id="signup-email" required="">
        <input type="password" placeholder="password" name="password" id="signup-password" required="">
        <button  type="button" id="signupattempt">Sign Up</button>
      </form>
        <form id="formotp1" class="form-horizontal" role="modal" style="display: none;padding-top: 30%;">
        <?php echo csrf_field(); ?>
        <h2>Mobile Verification</h2>
        <span>please enter you OTP here.</span>
        <input type="number" placeholder="OTP"  name="otp" id="signup-otp" required="">
        <input type="hidden" placeholder="OTP"  name="email" id="signup-email-otp" required="">
        <button type="button" id="otpattempt">Verify OTP</button>
         <br>
        <a id="showsigninform">Cancel?</a>
      </form>
    </div>
    <div class="form-container sign-in-container">
    <p id="add-error" class="add-error text-center alert alert-danger" style="display: none;"></p>
    <p id="add-success" class=" text-center alert alert-success" style="display: none;">Password Updated successfully...</p>
        <?php if($errors->any()): ?>
       <p id="add-error2" class="add-error text-center alert alert-danger" >Incorrect Email or Password...</p>
        <?php endif; ?>        
      <form id="formlogin" action="<?php echo e(route('admin-login')); ?>" method="post">
      	<?php echo csrf_field(); ?>
        <h1>Sign in</h1>
        <span>use Email for Sign in</span>
        <input type="email" placeholder="Email" name="email" id="login-email" required="">
        <input type="password" placeholder="Password" name="password" id="login-password" required="">
        <br>
        <button id="loginsubmit" type="submit">Sign In</button>
        <br>
         <a id="forgotpassword">Forgot your password?</a>
      </form>
       <form id="formforgotpassword" class="form-horizontal" role="modal" style="display: none; padding-top: 30%;">
        <?php echo csrf_field(); ?>
        <h2>Forgot Password</h2>
        <span>Please enter email here.</span>
        <input type="email" placeholder="Email"  name="email" id="forgotemail" required="">
        <br>
        <button type="button" id="otpsent">Verify Email</button>
        <br>
        <a id="showloginform">Cancel?</a>
      </form>
        <form id="formotp2" class="form-horizontal" role="modal" style="display: none;padding-top: 20%;">
        <?php echo csrf_field(); ?>
        <h2>Email Verification</h2>
        <span>please enter you OTP here.</span>
         <input type="hidden" placeholder="OTP"  name="email" id="forgotpasswordemail" required="">
        <input type="number" placeholder="OTP"  name="otp" id="forgotpasswordotp" required="">
       <input type="password" placeholder="New password (minimum 6 characters)" id="new-password1" name="password1" required="">
       <p id="addpserror" style="display: none;"></p>
        <input type="password" placeholder="Conform password" id="new-password2" name="password" required="">
        <br>
        <button type="button" id="forgotpasswordattempt">Update</button>
        <br>
        <a id="showloginform">Cancel?</a>
      </form>
    </div>
    <div class="overlay-container">
      <div class="overlay">
        <div class="overlay-panel overlay-left">
          <h1>Welcome Back!</h1>
          <p>To keep connected with us please login with your personal info</p>
          <button class="ghost" id="signIn">Sign In</button>
        </div>
        <div class="overlay-panel overlay-right">
          <h1>Hello, Friend!</h1>
          <p>Enter your personal data to have a look at the Task Board.</p>
          <button class="ghost" id="signUp">Sign Up</button>
        </div>
      </div>
    </div>
  </div>
<script type="text/javascript">
	const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => container.classList.add('right-panel-active'));
signInButton.addEventListener('click', () => container.classList.remove('right-panel-active'));

$('#forgotpassword').click(function () {
	$('#add-error').css('display','none');
	$('#add-error1').css('display','none');
	$('#add-error2').css('display','none');
	$('#formlogin').css('display','none');
	$('#formforgotpassword').css('display','block');
});
$('#showloginform').click(function () {
	$('#add-error').css('display','none');
	$('#add-error1').css('display','none');
	$('#add-error2').css('display','none');
	$('#formforgotpassword').css('display','none');
	$('#formotp2').css('display','none');
	$('#formlogin').css('padding-top','30%');
	$('#formlogin').css('display','block');
	
});
$('#showsigninform').click(function () {
	$('#add-error').css('display','none');
	$('#add-error1').css('display','none');
	$('#add-error2').css('display','none');
	$('#formotp1').css('display','none');
	$('#formsignup').css('padding-top','30%');
	$('#formsignup').css('display','block');
	
});
$('#otpsent').click(function () {
$('#add-error').css('display','none');
	$('#add-error2').css('display','none');
	$('#add-error1').css('display','none');
	if($('#forgotemail').val()!=''){
		   $.ajax({
      type: 'POST',
      url: '<?php echo e(route('home-forgotpassword')); ?>',
      data: {
        '_token': $('input[name=_token]').val(),
        'email': $('#forgotemail').val()
      },
      success: function(data){
        if ((data.error)) {
     $('#add-error').html('** Email id not registered.');
    $('#add-error').css('display','block');
        }
        else{
     $('#forgotpasswordemail').val($('#forgotemail').val());
    $('#formforgotpassword').css('display','none');
	$('#formlogin').css('display','none');
	$('#formotp2').css('display','block');
      }},
    });
  }
	else{
	$('#add-error').html('** Please enter valid email.');
    $('#add-error').css('display','block');
	}
});
$('#forgotpasswordattempt').click(function () {
	$('#add-error').css('display','none');
	$('#add-error2').css('display','none');
	$('#add-error1').css('display','none');
	if($('#forgotpasswordotp').val()!=''&&$('#new-password1').val()!=''&&$('#new-password2').val()!=''){
		   $.ajax({
      type: 'POST',
      url: '<?php echo e(route('home-updatepassword')); ?>',
      data: {
        '_token': $('input[name=_token]').val(),
        'email': $('#forgotpasswordemail').val(),
        'otp': $('#forgotpasswordotp').val(),
        'password': $('#new-password2').val()
      },
      success: function(data){
        if ((data.error)) {
     $('#add-error').html('** Please enter correct OTP.');
    $('#add-error').css('display','block');
        }
        else{
      $('#add-error').css('display','none');
    $('#formforgotpassword').css('display','none');
	$('#formotp2').css('display','none');
    $('#add-success').css('display','block');
    $('#formlogin').css('padding-top','20%');
	$('#formlogin').css('display','block');
      }},
    });
  }
	else{
	$('#add-error').html('** Please Fill all fields.');
    $('#add-error').css('display','block');
	}
});


$('#signupattempt').click(function () {
	$('#add-error').css('display','none');
	$('#add-error2').css('display','none');
	$('#add-error1').css('display','none');
	var email = $("#signup-email").val();
	if(validateEmail(email)){
	 if($('#signup-name').val()!=''&& $('#signup-email').val()!=''&& $('#signup-password').val()!=''){
		   $.ajax({
      type: 'POST',
      url: '<?php echo e(route('home-sign_up')); ?>',
      data: {
        '_token': $('input[name=_token]').val(),
        'name': $('#signup-name').val(),
        'email': $('#signup-email').val(),
        'password': $('#signup-password').val()
      },
      success: function(data){
        if ((data.error)) {
     $('#add-error1').html('** Email id is already registered.');
    $('#add-error1').css('display','block');
        }
        else{
        	$('#signup-email-otp').val($('#signup-email').val());
      $('#add-error1').css('display','none');
	$('#formotp1').css('display','block');
    $('#formsignup').css('padding-top','20%');
	$('#formsignup').css('display','none');
      }},
    });
  }
	else{
	$('#add-error1').html('** Please Fill all fields.');
	$('#formsignup').css('margin-top','-7%');
    $('#add-error1').css('display','block');
	}
}else{
	$('#add-error1').html('** Please enter Valid Email id.');
	$('#formsignup').css('margin-top','-7%');
    $('#add-error1').css('display','block');
}
});

function validateEmail(email) {
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);

}

$('#otpattempt').click(function() {
 $.ajax({
      type: 'POST',
      url: '<?php echo e(route('home-otpcheck')); ?>',
      data: {
        '_token': $('input[name=_token]').val(),
         'email': $('#signup-email-otp').val(),
          'otp': $('#signup-otp').val()
      },
      success: function(data){
      if ((data.error)) {
         $('#add-error1').html('** please enter correct OTP.');
         $('#add-error1').css('display','block');
        }
        else{
        $('#signup-email').val($('#login-email').val());
        $('#signup-password').val($('#login-password').val());
        $('#signup-name').val('');
        $('#signup-email').val('');
        $('#signup-password').val('');
        $('#signup-otp').val('');
         $('#signup-email-otp').val('');
        document.getElementById("loginsubmit").click();
    }
      },

    });
});


$('#new-password2').keyup(function(){
    var add_password = $('#new-password1').val();
  var add_password1 = $('#new-password2').val();
  if(add_password==add_password1) {
    $('#addpserror').css('display','none');
    $('#forgotpasswordattempt').attr('disabled',false);
  }
  else{
  	$('#addpserror').css('display','block');
    $('#addpserror').html('** password are not matching');
    $('#addpserror').css('color','red');
    $('#forgotpasswordattempt').attr('disabled',true);
  }
});
   
</script>
</body>
</html>
