Hi, <?php echo e($name); ?>


Your OTP is <?php echo e($otp); ?>.