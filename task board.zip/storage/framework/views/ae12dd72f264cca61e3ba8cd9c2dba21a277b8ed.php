<?php $n=1;?>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><b>Question <?php echo e($user->qid); ?></b></li>
<?php if($user->quesimg!=''): ?>
<li><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_ques" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="fst" data-id="<?php echo e($user->quesimg); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$user->quesimg")); ?>" />
<?php $name = explode(".", $user->quesimg);
$img_1 = $name[0].'_1.'.$name[1]; $img_2 = $name[0].'_2.'.$name[1];?>
<?php if(file_exists($img_1)): ?><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_ques" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="scnd" data-id="<?php echo e($img_1); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$img_1")); ?>" class="img-responsive"></div><?php endif; ?> 
<?php if(file_exists($img_2)): ?><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_ques" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="scnd" data-id="<?php echo e($img_2); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$img_2")); ?>" class="img-responsive"></div><?php endif; ?></li>
<?php else: ?>
<li style="color: #d9d9d9">Question Not Available</li>
<?php endif; ?>
<li><b>Solution <?php echo e($user->qid); ?></b></li>
<?php if($user->solimg!=''): ?>
<li><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_sol" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="fst" data-id="<?php echo e($user->solimg); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$user->solimg")); ?>" /></div>
<?php $name = explode(".", $user->solimg);
$img_1 = $name[0].'_1.'.$name[1]; $img_2 = $name[0].'_2.'.$name[1];?>
<?php if(file_exists($img_1)): ?><div class="<?php echo e('hide'.$n++); ?>"><a  style="margin-top: 5px;float: right;"><i  class="glyphicon glyphicon-trash delete_sol" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="scnd" data-id="<?php echo e($img_1); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$img_1")); ?>" class="img-responsive"></div><?php endif; ?> 
<?php if(file_exists($img_2)): ?><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_sol" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="scnd" data-id="<?php echo e($img_2); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$img_2")); ?>" class="img-responsive"></div><?php endif; ?></li>
<?php else: ?>
<li  style="color: #d9d9d9">Solution Not Available</li>
<?php endif; ?>
<li style=" height: 3px;background-color: rgba(244,132,83,0.8);"></li>
<script type="text/javascript">$("#loading").fadeOut(500);</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
	
	$('.delete_ques').on('click', function() {
		var img = $(this).data('id');
		var n = $(this).data('no');
		var dt = $(this).data('ty');
		var q = $(this).data('q');
		var no ='hide'+n;
		var img_type = 'ques';
		var answer = window.confirm("Are you sure to delete Question no.("+q+") ?")
if (answer) {
   var loading = document.getElementById('loading');
		$("#loading").attr('style','z-index:99999;display:none;');
    loading.style.display='';
	 $.ajax({
     type: "POST",
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }, 
    url: "delete_image",  
    data: {img:img,img_type:img_type},
    success: function(data) {
    $('.'+no).empty().html('<li style="color: #d9d9d9">Question Not Available</li>');
   $("#loading").fadeOut(500);
     },

  }); 
	 if(dt=='scnd'){
	 	  $('.'+no).empty().html('<li style="color: #d9d9d9">Question Not Available</li>');
   $("#loading").fadeOut(500);
	 }
}	
	});
	$('.delete_sol').on('click', function() {
		var img = $(this).data('id');
		var n = $(this).data('no');
		var dt = $(this).data('ty');
		var q = $(this).data('q');
		var no ='hide'+n;
		var img_type = 'sol';
			var answer = window.confirm("Are you sure to delete Solution no.("+q+") ?")
if (answer) {
		var loading = document.getElementById('loading');
		$("#loading").attr('style','z-index:99999;display:none;');
    loading.style.display='';
	 $.ajax({
     type: "POST",
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }, 
    url: "delete_image",  
    data: {img:img,img_type:img_type},
    success: function(data) {
    	 $('.'+no).empty().html('<li style="color: #d9d9d9">Solution Not Available</li>');
   $("#loading").fadeOut(500);
     },
  }); 
	 if(dt=='scnd'){
	  $('.'+no).empty().html('<li style="color: #d9d9d9">Solution Not Available</li>');
   $("#loading").fadeOut(500);
	 }
	}
	});
	
	
</script>