<html>
<head>
<?php echo $__env->yieldContent('title'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- css files -->
<link href="<?php echo e(asset('website/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/team.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
<!-- /css files -->
<!-- fonts -->
<link href='fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
<link href='fonts.googleapis.com/css?family=Nunito:400,300,700' rel='stylesheet' type='text/css'>
<!-- /fonts -->
<!-- js files -->
<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
<!-- /js files -->
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
	<!-- navigation -->
<header>
			<div class="container-fluid" >
				<div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
					<!-- logo -->
					<div id="logo" style="padding: 10px;">
						<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.jpg')); ?>"></a>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav_w3ls">
						<nav>
							<label for="drop" class="toggle">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu" style="color: #777; `margin-top: 5px;">
								<li><a  href="<?php echo e(route('home')); ?>" > Home </a></li>
								<li><a class="active" href="<?php echo e(route('about_us')); ?>">About Us</a></li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Courses <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Courses <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
									<li><a href="<?php echo e(route('regular_courses')); ?>" class="drop-text">Regular Batch</a></li>
									<li><a href="<?php echo e(route('foundation_courses')); ?>" class="drop-text">Foundation Batch</a></li>
									</ul>
								</li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="<?php echo e(route('faq')); ?>" class="drop-text">Faq's</a></li>
										<li><a href="<?php echo e(route('gallery')); ?>" class="drop-text">Gallery</a></li>
									
										<li><a href="<?php echo e(route('team')); ?>" class="drop-text">Our Faculty</a></li>
									</ul>
								</li>
								<li><a href="<?php echo e(route('student-form')); ?>">Log In</a></li>
							</ul>
						</nav>
					</div>
					<!-- //nav -->
				</div>
			</div>
		</header>
<div class=" about-in text-center" style="padding: 0px 60px 0px 60px; line-height: 1.9em; letter-spacing: 1px;">
					<div class="card">
						<div class="card-body" style="font-size: 15px;">
							<h2 class="card-title mt-4 mb-3"><strong> Welcome to&nbsp;Inspire Academy </strong></h2><br>
							<p class="card-text" >
								<p>Inspire Academy is a&nbsp;premier coaching institute in Kohlapur&nbsp;which trains students preparing for JEE (Mains), JEE (Advanced), NEET, MHT-CET and other engineering and medical entrance exams.</p> <br>
<p>What&nbsp;was started in 2017 with the purpose of providing the students a world class studying experience and prepare them for competitive exams, Inspire Academy has turned into one of the successful coaching institutes since then. Inspire Academy is about consistency in results, commitment , dedication and culture.&nbsp; We believe in maintaining quality and giving our best to the student.</p><br>
<p>We actually started to make a difference in the way Students think and approach problems. We started to develop ways to enhance Students’ IQ. We started to leave an indelible mark on the Students who have undergone training. We believe that Students having sound understanding of fundamental concepts & practising varied types of problems will always outperform the Students who confine their preparation to the exam pattern only, rather than understanding the concepts.
</p>
							</p>
						</div>
					</div>
				</div>


<!-- why choose us -->
<section class="choose py-5" id="services">
	<div class="container py-md-3" style="margin-top: 30px;">
		<h3 class="heading mb-5"> About Us</h3>
		<div class="feature-grids row about-in text-center " style="font-size: 16px;">
			<div class="col-lg-3 col-sm-6 mt-sm-0 mt-4" style="padding: 15px 15px 15px 15px;">
				<div class="f1 icon1 p-4">
					<br><h3 class="my-3">Success</h3><br>
					<p style=" line-height: 1.9em; letter-spacing: 1px;padding: 0px 15px 0px 15px;">We provide the students right path for there future to become successful.</p><br><br>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6 mt-sm-0 mt-4" style="padding: 15px 15px 15px 15px;">
				<div class="f1 icon2 p-4">
					<br><h3 class="my-3">Board Result</h3><br>
					<p style=" line-height: 1.9em; letter-spacing: 1px;padding: 0px 15px 0px 15px;">Our many students secured above 90% in 12th boards every year.</p><br><br>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6 mt-lg-0 mt-4" style="padding: 12px 15px 15px 15px;">
				<div class="f1 icon3 p-4">
					
					<br> <h3 class="my-3">Our Mission</h3> <br>
					<p style=" line-height: 1.9em; letter-spacing: 1px; padding: 0px 15px 0px 15px;">To provide best education that not only gives Knowledge but also provide the practical experience.</p><br>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6 mt-lg-0 mt-4" style="padding: 9px 15px 15px 15px;">
				<div class="f1 icon4 p-4">
					
					<br><h3 class="my-3">Our Vission</h3><br>
					<p style=" line-height: 1.9em; letter-spacing: 1px; padding: 0px 15px 0px 15px;">Inspire Academy is committed to impart best training & create healthy competitive environment for aspirants.</p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- //why choose us -->
<!-- services -->
	<section class="banner-bottom-bg-li py-5" id="services" >
		<div class="container py-xl-5 py-lg-3" style=" line-height: 1.9em; letter-spacing: 1px;"">
			<h3 class="tittle text-center font-weight-bold " style="margin-top: 25px;">Testimonials</h3>
			<p class="sub-tittle text-center mt-3 mb-sm-5 mb-4" style="font-size: 24px;">What students say about us</p>
			<div class="row pt-lg-4">
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('images/team2.jpg')); ?>" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 22px; padding: 25px 0px 5px 0px;">Harsh Kurne
								<p style="font-size: 15px;"><br>(IIT Kharagpur)</p></h4>
							<p class="card-text">
								<br>I’m grateful to entire Inspire Academy for their constant support and motivation. My teachers always had complete faith on my capability. I thank Shikhar coaching for my success in IIT-JEE.
							
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('images/team1.jpg')); ?>" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Soham Joshi	
								<p style="font-size: 15px;"><br>(IIIT Banglore JEE Advance Rank-4133)</p></h4>
							<p class="card-text">
								<br>I have joined Inspire Academy in 11th class. My main focus was always on the concept taught in the class. I relied on the experience of my faculties. I always focused on the basic concepts instead of quantity of questions.<br><br>
								
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('images/team3.jpg')); ?>" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Arya Phalke
								<p style="font-size: 15px;"><br>(NTSE Maharashtra Rank -09)</p></h4>
							<p class="card-text">
								<br>Inspire Academy the best coaching found the best teachers and friends-a new and loving family. learnt so much.Best years of my Life. <br><br><br><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('images/team4.jpg')); ?>" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Prasad Bhosale
								<p style="font-size: 15px;"><br>(percentile-99.86))</p></h4>
							<p class="card-text">
								<br>I have been a student of Shikhar from past 2 years. Throughout my study, I mostly focused on what had been taught in the class rather than books. It wouldn’t be possible without the great efforts of my teachers and parents. I always focus on the concepts which is the main reason behind my success.
								
							</p>
						</div>
					</div>
				</div>
				
				
			</div>
		</div>
	</section>
<section class="footer">
	<div class="container">
				<div class="copyright">
					<p style="text-align: center;"> 2020 Inspire Academy. All Rights Reserved | Design by Delta-Trek </a></p>
				</div>
			</div>
</section>
<!-- /Footer Section -->


<!-- js files -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/SmoothScroll.min.js')); ?>"> </script>
<!-- js for banner -->
<script src="<?php echo e(asset('js/index.js')); ?>"></script>
<!-- /js for banner -->
<!-- js for gallery -->
<script src="<?php echo e(asset('js/darkbox.js')); ?>"></script>
<!-- /js for gallery -->
<!-- js for smooth navigation -->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

  // Store hash
  var hash = this.hash;

  // Using jQuery's animate() method to add smooth page scroll
  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
  $('html, body').animate({
    scrollTop: $(hash).offset().top
  }, 900, function(){

    // Add hash (#) to URL when done scrolling (default click behavior)
    window.location.hash = hash;
    });
  });
})
</script>
<!-- /js for smooth navigation -->
<!-- js for sliding animations -->
<script>
$(window).scroll(function() {
  $(".slideanim").each(function(){
    var pos = $(this).offset().top;

    var winTop = $(window).scrollTop();
    if (pos < winTop + 600) {
      $(this).addClass("slide");
    }
  });
});
</script>
<!-- /js for sliding animations -->
<!-- /js files -->
</body>
</html>

<?php echo $__env->make('layout/details', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>