<?php $__env->startSection('head'); ?>
<title>Regular Courses</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Our Regular Classroom Courses.">
<meta name="keywords" content="Regular Classroom Courses, Regular classes in kolhapur, inspire Academy Courses,inspirekolhapur.in,Best institute for Regular Courses for IIT coaching, Regular course coaching for AIPMT NEET coaching">
<link rel="canonical" href="https://inspirekolhapur.in/Regular_courses"/>
 <script type="application/ld+json">
    {"@context":"https://schema.org",
    "@type":"Article",
    "mainEntityOfPage":
    {"@type":"WebPage",
    "@id":" https://inspirekolhapur.in/#webpage",
    "name":" Regular Courses",
    "url":" https://inspirekolhapur.in/Regular_courses/",	
    "inLanguage":"en-US"},
    "headline":" Regular Courses",
    "description":" Our Regular Classroom Courses.",

    "image":" https://inspirekolhapur.in/adminsa/images/logo.png ",

    "keywords":" Regular Classroom Courses, Regular classes in kolhapur, inspire Academy Courses,inspirekolhapur.in,Best institute for Regular Courses for IIT coaching, Regular course coaching for AIPMT NEET coaching",

    "datePublished":"2020-10-12T11:14:27+00:00",
    "dateModified":"2020-01-15T10:15:38+00:00",
    "author":{"@id":"https://inspirekolhapur.in/#person",
    "@type":"Person",
    "name":"Inspire Kolhapur"},	
    "publisher":
    {"@type":"Organization",
    "@id":"https://inspirekolhapur.in/#organization",
    "name":"Inspire Academy",
    "description":"Our Regular Classroom Courses.",
    "logo":
    {"@type":"ImageObject",
    "@id":"https://inspirekolhapur.in/#logo",
    "url":"https://inspirekolhapur.in/adminsa/images/logo.png",
    "width":275,"height":60,
    "caption":"Inspire Academy || IIT-JEE, NEET & MHT-CET"}
    }}
    }
    </script>
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "url": "https://inspirekolhapur.in/",
  "logo": "https://inspirekolhapur.in/adminsa/images/logo.png",
  "contactPoint": [{
    "@type": "ContactPoint",
    "telephone": "7972961299, 0231-2522422, 9146814500",
    "contactType": "enquiry service"
  }]
}
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

	<section class="banner-bottom-bg-li py-5" id="services" >
		<div class="container py-xl-5 py-lg-3">
			<h3 class="tittle text-center font-weight-bold">Courses</h3>
			<p class="sub-tittle text-center mt-3 mb-sm-5 mb-4">Our Regular Classroom Courses</p>
			<div class="row pt-lg-4">
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;" style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;" style="font-size: 18px;">Engineering Classroom Course <br> for Class XI</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">2nd April & 20 April 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Medical Classroom Course <br> for Class XI</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">2nd April & 20 April 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Engineering Classroom Course <br> for Class XII</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">1st March 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Medical Classroom Course <br> for Class XII</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">1st March 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Engineering Classroom Course <br> for Repeater</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">20 April 2020</p><br>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px;">Medical Classroom Course <br> for Repeater</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="text-align: left;">Frequency</h5>
								<p style="text-align: left;">6 days a week.</p><br>
								<h5 style="text-align: left;">Batch Starting On</h5>
								<p style="text-align: left;">1st June 2020</p><br>
							</p>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- //services -->
	<!-- stats -->
	<section class="bottom-count py-5" id="stats">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-lg-5 left-img-w3ls">
					
				</div>
				<div class="col-lg-7 right-img-w3ls pl-lg-4 mt-lg-2 mt-4">
					<div class="bott-w3ls mr-xl-5">
						<h3 class="title-w3 text-bl mb-3 font-weight-bold">Salient features of the course are:</h3> <br>
						<p style="font-size: 16px;">The level of the X standard is very easy in comparison to the level which students face in engineering entrance exams. In order to bridge the gap, a student must be given a clear understanding&nbsp;of the basics through simplified&nbsp;concepts and exercises which not only help them in cracking&nbsp;entrance exams&nbsp;but also in his academics. To accomplish this delicate task, we have designed our course that prepares students for IIT-JEE and Board exams at a stress-free and comfortable pace.</p>
						<p style="font-size: 16px;">We have designed our course to cover both subjective and objective type questions so that our students can fare well at both JEE as well as Board examination and succeed.</p>
					</div>
					<div style="zoom:1.5; align-self: center; margin-top: 20px; ">
								<p style="font-size: 20px;">For free demo lectures & futher enquiry</p>
								<a href="<?php echo e(route('form')); ?>"> <button type="button" class="btn btn-primary"  >Click Here</button> </a>
							</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>