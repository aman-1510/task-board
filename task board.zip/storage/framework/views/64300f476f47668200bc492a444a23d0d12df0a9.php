<html>
<head>
<title>Inspire Academy || IIT-JEE, NEET & MHT-CET</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Best success rate in all over maharashtra in JEE, NEET, CET & Olympiads.Inspire Academy achieves more than 80% selections from classroom courses and crash courses each year.Branches : Kolhapur,Karad & Satara
Add.: 2nd floor,Tathastu Corner,Shahupuri,Opp.railway Gate-416001 Contact:7972961299">
<meta name="keywords" content="inspire kolhapur, inspire, inspire Academy, inspire portal, inspirekolhapur, inspirekolhapur.com">
<link rel="canonical" href="https://inspirekolhapur.in" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico')); ?>"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- css files -->
<link href="<?php echo e(asset('website/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/team.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
<!-- /css files -->

<!-- js files -->
<script
  src="https://code.jquery.com/jquery-2.2.4.js"></script>
<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
<!-- /js files -->
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
<!-- navigation -->
<header>
			<div class="container-fluid" >
				<div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
					<!-- logo -->
					<div id="logo" style="padding: 10px;">
						<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.jpg')); ?>"></a>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav">
						<nav>
							<label for="drop" class="toggle">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu" style="color: #777; `margin-top: 5px;">
								<li><a class="active" href="<?php echo e(route('home')); ?>" > Home </a></li>
								<li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Courses <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Courses <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
									<li><a href="<?php echo e(route('regular_courses')); ?>" class="drop-text">Regular Batch</a></li>
									<li><a href="<?php echo e(route('foundation_courses')); ?>" class="drop-text">Foundation Batch</a></li>
									</ul>
								</li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="<?php echo e(route('faq')); ?>" class="drop-text">Faq's</a></li>
										<li><a href="<?php echo e(route('gallery')); ?>" class="drop-text">Gallery</a></li>
	
										<li><a href="<?php echo e(route('team')); ?>" class="drop-text">Our Faculty</a></li>
									</ul>
								</li>
								<li><a href="<?php echo e(route('student-form')); ?>">Log In</a></li>
							</ul>
						</nav>
					</div>
					<!-- //nav -->
				</div>
			</div>
		</header>
<!-- /navigation -->
<!-- banner section -->
<section class="banner" >
	<div class="cover-slider__wrap" style="height: 450px; width: 1500px; margin-top: 10px; margin-bottom: 10px; border-style: ridge;">
		<ul class="cover-slider">
			<li class="cover-slider__slide">
				<span class="hide">Alt Tag</span>
			</li>
			<li class="cover-slider__slide">
				<span class="hide">Alt Tag</span>
			</li>
			<li class="cover-slider__slide">
				<span class="hide">Alt Tag</span>
			</li>
		</ul>
	</div>
</section>	
<!-- /banner section -->
<!-- About Section -->
<section class="about-us" id="about">
	<div class="container-fluid">
		<div class="row">	
			<div class="col-lg-6 about-info1 slideanim" style="padding: 30px 0px 0px 5px; ">
				<img src="images/about-img.jpg" alt="about" class="img-responsive">
			</div>
			<div class="col-lg-6 about-info2 slideanim">
				<div class="about-details" style="">
					<div class="row" >
   <div class="col-md-12">
       <div class="widget-item" style="zoom:0.92;">
            <h2>Welcome to&nbsp;Inspire Academy</h2>
<p><strong>Inspire Academy is a&nbsp;premier coaching institute in Kohlapur&nbsp;which trains students preparing for JEE (Mains), JEE (Advanced), NEET, MHT-CET and other engineering and medical entrance exams.</strong></p>
<p>What&nbsp;was started in 2017 with the purpose of providing the students a world class studying experience and prepare them for competitive exams, Inspire Academy has turned into one of the successful coaching institutes since then. Inspire Academy is about consistency in results, commitment , dedication and culture.&nbsp; We believe in maintaining quality and giving our best to the student.</p>

                        </div> <!-- /.widget-item -->
                    </div> <!-- /.col-md-12 -->
                                   </div>
				</div>	
			</div>
		</div>
	</div>		
</section>
<!-- /About Section -->
<!-- Service Section -->
<section class="our-services slideanim" id="service" >
	<h3 class="text-center slideanim">Our Advantages </h3>
	<p class="text-center slideanim">Stay ahead with all-round performance in your chosen stream.</p>
	<div class="container">
		<div class="row">
			
			
			<div class="col-lg-4 col-md-6 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-graduation-cap" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>Experienced IITian Faculty</h4>
							<p class="serv">With a large pool highly qualified and experienced faculty members.</p>
						</div>	
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-signal" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4> Excelent Selection Performance</h4>
							<p class="serv">We provide a good ratio of selection in every type of exam. </p>
						</div>	
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-bars" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>Comprehensive Study Material</h4>
							<p class="serv">We provide complete study material pakage with regular assignmen for daily learning.</p>
						</div>	
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-desktop" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>Weekly Tests</h4>
							<p class="serv">Weekly we conduct our paper online as well as offline to prepare student for online exam.</p>
						</div>	
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-video-camera" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>Motivational Lectures</h4>
							<p class="serv">Stories for mentally happiness and satisfaction by which students get motivated for better learning. </p>
						</div>	
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-hourglass" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>Parents Teacher Meeting</h4>
							<p class="serv">PTM are conducted on a regular basis for interaction with guardians.</p>
						</div>	
					</div>
				</div>
			</div>
			
			
	</div>
</section>
<!-- /Service Section -->

<!-- Google Map -->
<section class="map">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 slideanim">
				<iframe class="googlemaps" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d19396.72988070512!2d74.23992354330721!3d16.701944511800782!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc100401e5815d7%3A0xec1c1df0f7a2d0e3!2sInspire%20Academy!5e0!3m2!1sen!2sin!4v1580742009413!5m2!1sen!2sin" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>	
		</div>
	</div>
</section>
<!-- /Google Map -->
<!-- Contact -->
<section class="contact-us slideanim" id="contact">
	<h3 class="text-center slideanim">Contact Us</h3>
	<p class="text-center slideanim"></p>
	<div class="container">		
		<div class="row">
			<div class="col-lg-5 col-md-5">
				<div class="contact-info">
					<h4>Connect With Us :-</h4>
					<p><strong>Phone :</strong> 070667 14281</p>
					<p><strong>Email :</strong> <a href="mailto:name@example.com">name@example.com</a></p>
					<p class="addr"><strong>Address :</strong> P62R+GJ Shahupuri, Kolhapur, Maharashtra</p>
					<ul class="social-icons2">
						<li><a href="#"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-7 col-md-7">
				<form action="#" method="post" >
					<div class="row" style="color: black;">
						<div class="col-sm-12 form-group slideanim">
							<input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
						</div>
					</div>
					<div class="row email-bar">
						<div class="col-sm-12 form-group slideanim">
							<input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
						</div>
					</div>
					<textarea class="form-control slideanim" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
					<div class="row">
						<div class="col-sm-12 form-group">
							<button class="btn btn-outline1 btn-lg" type="submit">Send</button>
						</div>
					</div>
				</form>			
			</div>
		</div>
	</div>
</section>
<!-- /Contact -->
<!-- Footer Section -->
<section class="footer">
	<div class="container">
				<div class="copyright">
					<p style="text-align: center;"> 2020 Inspire Academy. All Rights Reserved | Design by Delta-Trek </a></p>
				</div>
			</div>
</section>
<!-- /Footer Section -->
<!-- js files -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/SmoothScroll.min.js')); ?>"> </script>
<!-- js for banner -->
<script src="<?php echo e(asset('js/index.js')); ?>"></script>
<!-- /js for banner -->
<!-- js for gallery -->
<script src="<?php echo e(asset('js/darkbox.js')); ?>"></script>
<!-- /js for gallery -->
<!-- js for smooth navigation -->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

  // Store hash
  var hash = this.hash;

  // Using jQuery's animate() method to add smooth page scroll
  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
  $('html, body').animate({
    scrollTop: $(hash).offset().top
  }, 900, function(){

    // Add hash (#) to URL when done scrolling (default click behavior)
    window.location.hash = hash;
    });
  });
})
</script>
<!-- /js for smooth navigation -->
<!-- js for sliding animations -->
<script>
$(window).scroll(function() {
  $(".slideanim").each(function(){
    var pos = $(this).offset().top;

    var winTop = $(window).scrollTop();
    if (pos < winTop + 600) {
      $(this).addClass("slide");
    }
  });
});
</script>
<!-- /js for sliding animations -->
<!-- /js files -->
</body>
</html>
