<html>
<head>
<?php echo $__env->yieldContent('title'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- css files -->
<link href="<?php echo e(asset('website/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/team.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
<!-- /css files -->
<!-- fonts -->
<link href='fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
<link href='fonts.googleapis.com/css?family=Nunito:400,300,700' rel='stylesheet' type='text/css'>
<!-- /fonts -->
<!-- js files -->
<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
<!-- /js files -->
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
<!-- navigation -->
<header>
			<div class="container-fluid" >
				<div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
					<!-- logo -->
					<div id="logo"  style="padding: 10px;">
						<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.jpg')); ?>"></a>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav_w3ls">
						<nav>
							<label for="drop" class="toggle">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu" style="color: #777; `margin-top: 5px;">
								<li><a  href="<?php echo e(route('home')); ?>" > Home </a></li>
								<li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Courses <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Courses <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
									<li><a href="<?php echo e(route('regular_courses')); ?>" class="drop-text">Regular Batch</a></li>
									<li><a href="<?php echo e(route('foundation_courses')); ?>" class="drop-text">Foundation Batch</a></li>
									</ul>
								</li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="<?php echo e(route('faq')); ?>" class="drop-text">Faq's</a></li>
										<li><a class="active" href="<?php echo e(route('gallery')); ?>" class="drop-text">Gallery</a></li>
										
										<li><a href="<?php echo e(route('team')); ?>" class="drop-text">Our Faculty</a></li>
									</ul>
								</li>
								<li><a href="<?php echo e(route('student-form')); ?>">Log In</a></li>
							</ul>
						</nav>
					</div>
					<!-- //nav -->
				</div>
			</div>
		</header>
<!-- /navigation -->
<!-- /Service Section -->
<!-- Gallery Section -->
<section class="our-gallery" id="gallery" style="background-color: rgb(255,255,255); margin-top: -80px;">
	<h3 class="text-center ">Our Gallery</h3>
	<p class="text-center ">Our Institute gallery showing various picture of events,student,location and many other thing about our institute.</p>
	<div class="container" style="background-color: rgb(255,255,255);">
		<img src="images/g1.jpeg" data-darkbox="images/g1.jpeg" class="img-responsive">
        <img src="images/g2.jpg" data-darkbox="images/g2.jpg" class="img-responsive">
		<img src="images/g14.jpg" data-darkbox="images/g14.jpg" class="img-responsive">
		<img src="images/g6.jpg" data-darkbox="images/g6.jpg" class="img-responsive">
		<img src="images/g5.jpeg" data-darkbox="images/g5.jpeg" class="img-responsive slideanim">
		<img src="images/g4.jpeg" data-darkbox="images/g4.jpeg" class="img-responsive slideanim">
		<img src="images/g7.jpg" data-darkbox="images/g7.jpg" class="img-responsive slideanim">
		<img src="images/g8.jpg" data-darkbox="images/g8.jpg" class="img-responsive slideanim">
		<img src="images/g9.jpg" data-darkbox="images/g9.jpg" class="img-responsive slideanim">
		<img src="images/g10.jpg" data-darkbox="images/g10.jpg" class="img-responsive slideanim">
		<img src="images/g11.jpg" data-darkbox="images/g11.jpg" class="img-responsive slideanim">
		<img src="images/g12.jpg" data-darkbox="images/g12.jpg" class="img-responsive slideanim">
		<img src="images/g13.jpg" data-darkbox="images/g13.jpg" class="img-responsive slideanim">
		<img src="images/g3.jpeg" data-darkbox="images/g3.jpeg" class="img-responsive slideanim">
		<img src="images/g15.jpg" data-darkbox="images/g15.jpg" class="img-responsive slideanim">
		<img src="images/g16.jpg" data-darkbox="images/g16.jpg" class="img-responsive slideanim">
	</div>
</section>	
<!-- /Gallery section -->
<section class="footer">
	<div class="container">
				<div class="copyright">
					<p style="text-align: center;"> 2020 Inspire Academy. All Rights Reserved | Design by Delta-Trek </a></p>
				</div>
			</div>
</section>


<!-- js files -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/SmoothScroll.min.js')); ?>"> </script>
<!-- js for banner -->
<script src="<?php echo e(asset('js/index.js')); ?>"></script>
<!-- /js for banner -->
<!-- js for gallery -->
<script src="<?php echo e(asset('js/darkbox.js')); ?>"></script>
<!-- /js for gallery -->
<!-- js for smooth navigation -->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

  // Store hash
  var hash = this.hash;

  // Using jQuery's animate() method to add smooth page scroll
  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
  $('html, body').animate({
    scrollTop: $(hash).offset().top
  }, 900, function(){

    // Add hash (#) to URL when done scrolling (default click behavior)
    window.location.hash = hash;
    });
  });
})
</script>
<!-- /js for smooth navigation -->
<!-- js for sliding animations -->
<script>
$(window).scroll(function() {
  $(".slideanim").each(function(){
    var pos = $(this).offset().top;

    var winTop = $(window).scrollTop();
    if (pos < winTop + 600) {
      $(this).addClass("slide");
    }
  });
});
</script>
<!-- /js for sliding animations -->
<!-- /js files -->
</body>
</html>
<?php echo $__env->make('layout/details', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>