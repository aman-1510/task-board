<?php $__env->startSection('body'); ?>
<!-- services -->
	<section class="banner-bottom-bg-li py-5" id="services" >
		<div class="container py-xl-5 py-lg-3">
			<h3 class="tittle text-center font-weight-bold" style="margin-top: 25px;">Our Faculty</h3>
			<p class="sub-tittle text-center mt-3 mb-sm-5 mb-4">A teacher is a compass that activates the magnets of curiosity, knowledge, and wisdom in the pupils</p>
			<div class="row pt-lg-4">
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('website/images/teacher1.png')); ?>" width="80%" style="max-height: 300px; max-width: 250px;"  alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Dipak Gupta</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px;">B-Tech IIT-Kharagpur</h5>
								<p style="padding: 5px 0px 0px 0px;">Physics</p>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('website/images/teacher2.png')); ?>" width="80%" style="max-height: 300px; max-width: 250px;"  alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Vasu Guduri</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px">B-Tech IIT-Bombay</h5>
								<p style="padding: 5px 0px 5px 0px">Chemistry</p>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('website/images/teacher3.png')); ?>" width="80%" style="max-height: 300px; max-width: 250px;"  alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Shubham Kr. Bansal</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px">B-Tech IIT-Varanasi</h5>
								<p style="padding: 5px 0px 5px 0px">Mathematics</p>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('website/images/teacher4.png')); ?>" width="80%" style="max-height: 300px; max-width: 250px;" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Sajid Shaikh</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px">PhD Shivaji University</h5>
								<p style="padding: 5px 0px 5px 0px">Biology</p>
							</p>
						</div>
					</div>
				</div>
			<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('website/images/teacher5.png')); ?>" width="80%" style="max-height: 300px; max-width: 250px;"  alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Varsha Sankpal</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px">Post Graduate</h5>
								<p style="padding: 5px 0px 5px 0px">Manager</p>
							</p>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- //services -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>