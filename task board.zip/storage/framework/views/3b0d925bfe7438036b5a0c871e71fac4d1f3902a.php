<html>
<head>
<?php echo $__env->yieldContent('title'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- css files -->
<link href="<?php echo e(asset('website/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/team.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
<!-- /css files -->
<!-- fonts -->
<link href='fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
<link href='fonts.googleapis.com/css?family=Nunito:400,300,700' rel='stylesheet' type='text/css'>
<!-- /fonts -->
<!-- js files -->
<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
<!-- /js files -->
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
	<!-- navigation -->
<header>
			<div class="container-fluid" style="margin-top: 15px;">
				<div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
					<!-- logo -->
					<div id="logo">
						<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.jpg')); ?>"></a>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav_w3ls">
						<nav>
							<label for="drop" class="toggle">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu" style="color: #777; `margin-top: 5px;">
								<li><a  href="<?php echo e(route('home')); ?>" > Home </a></li>
								<li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Courses <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Courses <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
									<li><a href="<?php echo e(route('regular_courses')); ?>" class="drop-text">Regular Batch</a></li>
									<li><a href="<?php echo e(route('foundation_courses')); ?>" class="drop-text">Foundation Batch</a></li>
									</ul>
								</li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="<?php echo e(route('faq')); ?>" class="drop-text">Faq's</a></li>
										<li><a href="<?php echo e(route('gallery')); ?>" class="drop-text">Gallery</a></li>
										
										<li><a class="active" href="<?php echo e(route('team')); ?>" class="drop-text">Our Faculty</a></li>
									</ul>
								</li>
								<li><a href="<?php echo e(route('student-form')); ?>">Log In</a></li>
							</ul>
						</nav>
					</div>
					<!-- //nav -->
				</div>
			</div>
		</header>
<!-- /navigation -->
<!-- services -->
	<section class="banner-bottom-bg-li py-5" id="services" >
		<div class="container py-xl-5 py-lg-3">
			<h3 class="tittle text-center font-weight-bold" style="margin-top: 25px;">Our Faculty</h3>
			<p class="sub-tittle text-center mt-3 mb-sm-5 mb-4">A teacher is a compass that activates the magnets of curiosity, knowledge, and wisdom in the pupils</p>
			<div class="row pt-lg-4">
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('images/team2.jpg')); ?>" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Dipak Gupta</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px;">B-Tech IIT-Kharagpur</h5>
								<p style="padding: 5px 0px 0px 0px;">Physics</p>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('images/team1.jpg')); ?>" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Vasu Guduri</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px">B-Tech IIT-Bombay</h5>
								<p style="padding: 5px 0px 5px 0px">Chemistry</p>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('images/team3.jpg')); ?>" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Shubham Kr. Bansal</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px">B-Tech IIT-Varanasi</h5>
								<p style="padding: 5px 0px 5px 0px">Mathematics</p>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('images/team4.jpg')); ?>" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Sajid Shaikh</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px">PhD Shivaji University</h5>
								<p style="padding: 5px 0px 5px 0px">Biology</p>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 about-in text-center" style="padding: 15px 15px 15px 15px;">
					<div class="card">
						<img class="card-img-top" src="<?php echo e(asset('images/team4.jpg')); ?>" alt="Card image cap">
						<div class="card-body"style="font-size: 15px;">
							<h4 class="card-title mt-4 mb-3"style="font-size: 18px; padding: 25px 0px 5px 0px;">Varsha Sankalp</h4>
							<p class="card-text" style="zoom:1.4;">
								<h5 style="padding: 5px 0px 5px 0px">Management</h5>
									<p style="padding: 5px 0px 5px 0px"> </p>
							</p>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- //services -->

<!-- /Team -->

<section class="footer">
	<div class="container">
				<div class="copyright">
					<p style="text-align: center;"> 2020 Inspire Academy. All Rights Reserved | Design by Delta-Trek </a></p>
				</div>
			</div>
</section>


<!-- js files -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/SmoothScroll.min.js')); ?>"> </script>
<!-- js for banner -->
<script src="<?php echo e(asset('js/index.js')); ?>"></script>
<!-- /js for banner -->
<!-- js for gallery -->
<script src="<?php echo e(asset('js/darkbox.js')); ?>"></script>
<!-- /js for gallery -->
<!-- js for smooth navigation -->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

  // Store hash
  var hash = this.hash;

  // Using jQuery's animate() method to add smooth page scroll
  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
  $('html, body').animate({
    scrollTop: $(hash).offset().top
  }, 900, function(){

    // Add hash (#) to URL when done scrolling (default click behavior)
    window.location.hash = hash;
    });
  });
})
</script>
<!-- /js for smooth navigation -->
<!-- js for sliding animations -->
<script>
$(window).scroll(function() {
  $(".slideanim").each(function(){
    var pos = $(this).offset().top;

    var winTop = $(window).scrollTop();
    if (pos < winTop + 600) {
      $(this).addClass("slide");
    }
  });
});
</script>
<!-- /js for sliding animations -->
<!-- /js files -->
</body>
</html>

<?php echo $__env->make('layout/details', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>