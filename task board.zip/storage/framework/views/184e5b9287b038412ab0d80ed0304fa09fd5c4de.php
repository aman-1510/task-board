<?php $n=1;?>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><b>Question <?php echo e($user->qid); ?></b></li>
<?php if($user->quesimg!=''): ?>
<li><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_ques" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="fst" data-id="<?php echo e($user->quesimg); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$user->quesimg")); ?>" />
<?php $name = explode(".", $user->quesimg);
$img_1 = $name[0].'_1.'.$name[1]; $img_2 = $name[0].'_2.'.$name[1];?>
<?php if(file_exists($img_1)): ?><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_ques" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="scnd" data-id="<?php echo e($img_1); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$img_1")); ?>" class="img-responsive"></div><?php endif; ?> 
<?php if(file_exists($img_2)): ?><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_ques" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="scnd" data-id="<?php echo e($img_2); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$img_2")); ?>" class="img-responsive"></div><?php endif; ?></li>
<?php else: ?>
<li style="color: #d9d9d9">Question Not Available</li>
<?php endif; ?>
<?php if($user->type=='normal'): ?>
<?php if($user->q1!=NULL): ?>
<li class="l2" id="q<?php echo e($user->qid); ?>"style="color: #555555;">Correct Answer : <?php echo e($user->q1); ?></li>
<?php else: ?>
<li class="l3" id="q<?php echo e($user->qid); ?>"style="color: #555555;">Correct Answer : Not Available</li>
<?php endif; ?>
<?php else: ?>
<?php if($user->q1==NULL&&$user->q2==NULL&&$user->q3==NULL&&$user->q4==NULL): ?>
<li class="l3" id="q<?php echo e($user->qid); ?>"style="color: #555555;">Correct Answer : Not Available</li>
<?php else: ?>
<?php if($user->type=='single'||$user->type=='integer'||$user->type=='passage'||$user->type=='match_column'): ?>
<li class="l2" id="q<?php echo e($user->qid); ?>"style="color: #555555;">Correct Answer : <?php echo e($user->q1); ?></li>
<?php elseif($user->type=='multiple'): ?>
<li class="l2" id="q<?php echo e($user->qid); ?>"style="color: #555555;">Correct Answers : <?php echo e($user->q1 . $user->q2 . $user->q3 . $user->q4); ?></li>
<?php elseif($user->type=='numerical'): ?>
<li class="l2" id="q<?php echo e($user->qid); ?>"style="color: #555555;">Correct Answer : Between <?php echo e($user->q1); ?> To <?php echo e($user->q2); ?></li>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?>
<li><b>Solution <?php echo e($user->qid); ?></b></li>
<?php if($user->solimg!=''): ?>
<li><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_sol" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="fst" data-id="<?php echo e($user->solimg); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$user->solimg")); ?>" /></div>
<?php $name = explode(".", $user->solimg);
$img_1 = $name[0].'_1.'.$name[1]; $img_2 = $name[0].'_2.'.$name[1];?>
<?php if(file_exists($img_1)): ?><div class="<?php echo e('hide'.$n++); ?>"><a  style="margin-top: 5px;float: right;"><i  class="glyphicon glyphicon-trash delete_sol" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="scnd" data-id="<?php echo e($img_1); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$img_1")); ?>" class="img-responsive"></div><?php endif; ?> 
<?php if(file_exists($img_2)): ?><div class="<?php echo e('hide'.$n++); ?>"><a style="margin-top: 5px;float: right;"><i class="glyphicon glyphicon-trash delete_sol" data-q="<?php echo e($user->qid); ?>" data-no="<?php echo e($n-1); ?>" data-ty="scnd" data-id="<?php echo e($img_2); ?>" style="color: #ff5c33"></i></a><img src="<?php echo e(asset("$img_2")); ?>" class="img-responsive"></div><?php endif; ?></li>
<?php else: ?>
<li  style="color: #d9d9d9">Solution Not Available</li>
<?php endif; ?>
<li style=" height: 3px;background-color: rgba(244,132,83,0.8);"></li>
<script type="text/javascript">$("#loading").fadeOut(500);</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
	
	$('.delete_ques').on('click', function() {
		var img = $(this).data('id');
		var n = $(this).data('no');
		var dt = $(this).data('ty');
		var q = $(this).data('q');
		var no ='hide'+n;
		var img_type = 'ques';
		var answer = window.confirm("Are you sure to delete Question no.("+q+") ?")
if (answer) {
   var loading = document.getElementById('loading');
		$("#loading").attr('style','z-index:99999;display:none;');
    loading.style.display='';
	 $.ajax({
     type: "POST",
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }, 
    url: "delete_image",  
    data: {img:img,img_type:img_type},
    success: function(data) {
    $('.'+no).empty().html('<li style="color: #d9d9d9">Question Not Available</li>');
   $("#loading").fadeOut(500);
     },

  }); 
	 if(dt=='scnd'){
	 	  $('.'+no).empty().html('<li style="color: #d9d9d9">Question Not Available</li>');
   $("#loading").fadeOut(500);
	 }
}	
	});
	$('.delete_sol').on('click', function() {
		var img = $(this).data('id');
		var n = $(this).data('no');
		var dt = $(this).data('ty');
		var q = $(this).data('q');
		var no ='hide'+n;
		var img_type = 'sol';
			var answer = window.confirm("Are you sure to delete Solution no.("+q+") ?")
if (answer) {
		var loading = document.getElementById('loading');
		$("#loading").attr('style','z-index:99999;display:none;');
    loading.style.display='';
	 $.ajax({
     type: "POST",
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }, 
    url: "delete_image",  
    data: {img:img,img_type:img_type},
    success: function(data) {
    	 $('.'+no).empty().html('<li style="color: #d9d9d9">Solution Not Available</li>');
   $("#loading").fadeOut(500);
     },
  }); 
	 if(dt=='scnd'){
	  $('.'+no).empty().html('<li style="color: #d9d9d9">Solution Not Available</li>');
   $("#loading").fadeOut(500);
	 }
	}
	});
	
	
</script>
<style type="text/css">
	.l2{
		margin-top: 8px;color: #555555;opacity:0.8;border-radius: 5px;border:2px solid rgb(6, 217, 149,0.8); padding: 0px 0px 5px 5px;height: 25px;background-color: rgb(6, 220, 149,0.4);
	}
	.l3{
		margin-top: 8px;color: #555555;opacity: 0.8;border-radius: 5px;border:2px solid rgba(253,92,99,0.8); padding: 0px 0px 5px 5px;height: 25px;background-color: rgba(253,92,99,0.4);
	}
</style>