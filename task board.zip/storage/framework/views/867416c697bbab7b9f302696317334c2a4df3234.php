<?php $__env->startSection('inner_block'); ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/enquiry_table_style.css')); ?>">
<div class="limiter">
    <div  class="title">
    <div class="searchBox">
    <h4><b>Online Students</b></h4> 
</div></div>
   <div class="container-table100" >
      <div class="wrap-table100" style="overflow-x: scroll;">
        <div class="table100" id="tbody">
           <table>
            <thead>
              <tr class="table100-head">
                 <th style="margin-left: 10px;" class="column1">S.No</th>
                <th class="column2">Name</th>
                <th class="column3">Email</th>
                <th class="column4">Mobile</th>
                <th class="column4">Class</th>
                <th class="column4">Course</th>
                <th style="margin-right: 10px;" class="column5">Status</th>
         </tr>
                </thead>
                <tbody>
      <?php  $no=1; ?>
       <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
        <tr class="user<?php echo e($student->id); ?>" <?php if($student->status=='Pending'): ?> style=" background-color:#fd6e70; color: #fff" <?php endif; ?>>
          <td style="margin-left: 10px;"><?php echo e($no++); ?></td>
          <td><?php echo e($student->name); ?></td>
          <td><?php echo e($student->email); ?></td>
          <td><?php echo e($student->mobile); ?></td>
          <td><?php echo e($student->class); ?></td>
          <td><?php echo e($student->course); ?></td>
          
          <td style="margin-right: 10px; color: #808080;">
          <select class="enquiry_status" id="enquiry_status<?php echo e($student->id); ?>" data-id="<?php echo e($student->id); ?>">
            <option <?php if($student->status=='Pending'): ?> selected <?php endif; ?> value="Pending" >Pending</option>
            <option <?php if($student->status=='Completed'): ?> selected <?php endif; ?> value="Completed">Completed</option>
          </select>
        </td>
         </tr>
          <tr class="users<?php echo e($student->id); ?>" <?php if($student->status=='Pending'): ?> style=" background-color:#fd6e70; color: #fff; margin-bottom: 10px;"<?php else: ?> style="background-color: #fff; margin-bottom: 10px;"  <?php endif; ?> >
          <td colspan="7" style="color: #000;">Comments : <?php echo e($student->comments); ?></td>
         </tr>
         <tr class="gap"><td  style="background-color: #f4f7f9;padding: 2px !important" colspan="7"></td></tr>
         
      
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
      
   </table>
    </div>
    </div>
    </div>
    </div>
     <script type="text/javascript">
         $('.enquiry_status').on('change', function() {
   var loading = document.getElementById('loading');
      loading.style.display='';
      var id = $(this).data('id');
      var value = $('#enquiry_status'+id+' option:selected').val();
      $.ajax({
      type: 'POST',
      url: '<?php echo e(route('admin-enquiries_status')); ?>',
      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
      data: {
        'id': id,
        'status': value
      },
      success: function(data){
       if(data.status=='Pending'){
        $('.user'+id+'').css('background-color','#fd6e70');
        $('.users'+id+'').css('background-color','#fd6e70');
        $('.user'+id+'').css('color','#fff');
       }
       else{
        $('.user'+id+'').css('background-color','#fff');
        $('.users'+id+'').css('background-color','#fff');
        $('.user'+id+'').css('color','#808080');
       }
       $("#loading").fadeOut(500);
      },
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/details', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout/admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>