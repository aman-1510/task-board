
<?php echo $__env->make('layout/normal_paper', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>