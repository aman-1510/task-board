<html>
<head>
<?php echo $__env->yieldContent('title'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- css files -->
<link href="<?php echo e(asset('website/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/team.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>

    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
    <!-- navigation -->
<header>
            <div class="container-fluid" >
                <div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
                    <!-- logo -->
                    <div id="logo"  style="padding: 10px;">
                        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.jpg')); ?>"></a>
                    </div>
                    <!-- //logo -->
                    <!-- nav -->
                    <div class="nav_w3ls">
                        <nav>
                            <label for="drop" class="toggle">Menu</label>
                            <input type="checkbox" id="drop" />
                            <ul class="menu" style="color: #777; `margin-top: 5px;">
                                <li><a  href="<?php echo e(route('home')); ?>" > Home </a></li>
                                <li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
                                <li>
                                    <!-- First Tier Drop Down -->
                                    <label for="drop-2" class="toggle toogle-2">Courses <span class="fa fa-angle-down" aria-hidden="true"></span>
                                    </label>
                                    <a href="#">Courses <span class="fa fa-angle-down" aria-hidden="true"></span></a>
                                    <input type="checkbox" id="drop-2" />
                                    <ul>
                                    <li><a href="<?php echo e(route('regular_courses')); ?>" class="drop-text">Regular Batch</a></li>
                                    <li><a href="<?php echo e(route('foundation_courses')); ?>" class="drop-text">Foundation Batch</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <!-- First Tier Drop Down -->
                                    <label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
                                    </label>
                                    <a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
                                    <input type="checkbox" id="drop-2" />
                                    <ul>
                                        <li><a href="<?php echo e(route('faq')); ?>" class="drop-text">Faq's</a></li>
                                        <li><a href="<?php echo e(route('gallery')); ?>" class="drop-text">Gallery</a></li>
                                       
                                        <li><a href="<?php echo e(route('team')); ?>" class="drop-text">Our Faculty</a></li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo e(route('student-form')); ?>">Log In</a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- //nav -->
                </div>
            </div>
        </header>
    <!-- contact -->
    <h2 style="margin-top: 30px; text-align: center;">Enrollment & Enquiry Form</h2>
    <div class="contact py-5" id="contact" style="margin-top: 30px;">
        <div class="container pb-xl-5 pb-lg-3">
            <div class="row">
                <div class="col-lg-6">
                    <img src="images/b2.png" alt="image" style="width: 360px; height: 500px;" />
                </div>
                <div class="col-lg-6 mt-lg-0 mt-5">
                    <!-- contact form grid -->
                    <div class="contact-top1">
                        <form autocomplete="off" method="POST" action="" class="login100-form validate-form p-b-33 p-t-5">
                        <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>
                                            Student Name :
                                        </label>
                                        <br> 
                                        <input class="form-control" type="text" placeholder="Your Name" name="name" required="">
                                    </div>
                                </div>
                            </div>
                             <div class="form-group">
                                <div class="row">
                                   <div class="col-md-6">
                                        <label>
                                            Mobile :
                                        </label> <br>
                                        <input class="form-control" type="text" placeholder="xxxxxxxxxx" name="mobile" required="">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">    
                                     <div class="col-md-6 mt-md-0 mt-4" style="">
                                        <label>
                                            Foundation Classroom Course :
                                        </label> <br>
                                     <div class="row">    
                                       <input type="radio" name="class" value="8th" required=""> 8th<br>
                                <input type="radio" name="class" value="9th" required=""> 9th<br>
                                <input type="radio" name="class" value="10th" required=""> 10th<br>
                           </div>
                                    </div>

                                    <div class="col-md-6 mt-md-0 mt-4">
                                        <label>
                                           Homi Bhabh Batch :
                                        </label> <br>
                                     <div class="row">    
                                <input type="radio" name="class" value="6th" required=""> 6th<br>
                           </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-12">
                                        <label>
                                           Comments : 
                                        </label> <br>
                                        <textarea placeholder="Add your Description here" name="message" class="form-control"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary btn-block mt-4">Send</button>
                                </div>
                            </div>
                        </form>
                    </div>
                                    </div>
            </div>
        </div>
    </div>
    

              
</body>
</html>

<?php echo $__env->make('layout/details', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>