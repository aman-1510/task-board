<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Album example for Bootstrap</title>

     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>

  <body>
  <!-- new team -->
 <div class="modal fade" id="add-team" role="dialog" style="zoom:.8;">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Create Team</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <p id="add-team-error" class="add-error text-center alert alert-danger" style="display: none;"></p>
        <p id="add-team-success" class=" text-center alert alert-success" style="display: none;">Team created successfully...</p>
         <div class="container" id="container">
    <div class="form-container sign-up-container">
     
       <form id="form2" class="form-horizontal" role="modal" >
        <?php echo csrf_field(); ?>
        <input type="text" placeholder="Team Name"  name="team_name" id="add-team_name" required="">
       
        <button type="button" id="create-team">Create Team</button>
      </form>
    </div>
   
      </div>
        </div>
      </div>
      
    </div></div>
     <!-- end new team -->
 <!-- add board -->
  <div class="modal fade" id="add-board" role="dialog" style="zoom:.8;">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Create Board</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <p id="add-board-error" class="add-error text-center alert alert-danger" style="display: none;"></p>
        <p id="add-board-success" class=" text-center alert alert-success" style="display: none;">Board created successfully...</p>
         <div class="container" id="container">
    <div class="form-container sign-up-container">
     
       <form id="form2" class="form-horizontal" role="modal" >
        <?php echo csrf_field(); ?>
        <input type="text" placeholder="board Name"  name="board_name" id="add-board_name" required="">
        <button type="button" id="create-board">Create Board</button>
      </form>
    </div>
   
      </div>
        </div>
      </div>
      
    </div></div>
  <!-- add member -->
    <header>
      <div class="navbar navbar-dark bg-dark box-shadow">
          <a href="#" class="navbar-brand d-flex align-items-center">
            <strong>Task Dashboard</strong>
          </a>
      </div>
    </header>

    <main role="main">

      <div class="album bg-light col-lg-12 row">
<div class="col-lg-2" style="float: left;">
  <ul class="sidebar">
      <li onclick="home()"><a>Home</a></li>
      <li onclick="personal_board()"><a>Personal Board</a></li>
      <li onclick="team_board()"><a>Team Board</a></li>
      <li onclick="addboard()"><a>Create Board<i class="fa fa-plus"></i></a></li>
      <li onclick="my_team()"><a>My Teams</a></li>
      <li  onclick="addteam()"><a>Create Team<i class="fa fa-plus"></i></a></li>

      </ul>
</div>
        <div class="col-lg-10" style="float: right;">
          <div id="personal-board">
           <div class="box-shadow card mt-2"><p class="ml-2 pt-2"><b>Personal Boards</b></p></div>
          <div class="row px-3">
   <?php $n=0; ?>
<?php $__currentLoopData = $board; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($b->Btype=='Personal'): ?>
 <?php $n++; ?>
            <div class="p-1">
              <div class="card mb-2 box-shadow">  
                <div class="card-body" style="background-color: <?php echo e($b->bg); ?>; color: #fff">
                  <p class="card-text"><?php echo e($b->title); ?></p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                     <span class="box-shadow btn btn-outline-secondary"><i class="fa fa-trash"></i></span>
                      <span class="box-shadow btn btn-outline-secondary"><i class="fa fa-pencil"></i></span>
                    </div>
                   <small class="text-muted ml-3"><?php echo e($b->status); ?></small>
                  </div>
                </div>
              </div>
            </div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php if($n==0): ?>
   <div class="box-shadow card mt-2"><p class="ml-2 pt-2"><b>Sorry!! No Personal Board Available.</b></p></div>
   <?php endif; ?> 
         </div>
       </div>


        <div id="team-board">
           <div class="box-shadow card mt-2"><p class="ml-2 pt-2"><b>Team Boards</b></p></div>
          <div class="row px-3">
         <?php $n=0; ?>
<?php $__currentLoopData = $board; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($b->Btype=='Team'): ?>
 <?php $n++; ?>
            <div class="p-1">
              <div class="card mb-2 box-shadow">  
                <div class="card-body" style="background-color: <?php echo e($b->bg); ?>; color: #fff">
                  <p class="card-text"><?php echo e($b->title); ?></p>
                  <div class="d-flex justify-content-between align-items-center">
                   <?php if($b->Aid==Auth::user()->id): ?> 
                     <div class="btn-group">
                     <span class="box-shadow btn btn-outline-secondary"><i class="fa fa-trash"></i></span>
                      <span class="box-shadow btn btn-outline-secondary"><i class="fa fa-pencil"></i></span>
                    </div>
                     <?php endif; ?>
                    <small class="text-muted ml-3"><?php echo e($b->status); ?></small>
                  </div>
                </div>
              </div>
            </div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php if($n==0): ?>
   <div class="box-shadow card mt-2"><p class="ml-2 pt-2"><b>Sorry!! No Team Board Available.</b></p></div>
   <?php endif; ?> 
         
</div>
</div>
  <div id="my-team">
           <div class="box-shadow card mt-2"><p class="ml-2 pt-2"><b>My Team</b></p></div>
          <div class="row px-3">
   <?php $n=0; ?>
<?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php $n++; ?>
            <div class="p-1">
              <div class="card mb-2 box-shadow">  
                <div class="card-body">
                  <p class="card-text"><?php echo e($t->Tname); ?></p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                     <span class="box-shadow btn btn-outline-secondary"><i class="fa fa-trash"></i></span>
                      <span class="box-shadow btn btn-outline-secondary"><i class="fa fa-pencil"></i></span>
                    </div>
                 <small class="text-muted ml-4"><i class="fa fa-user"></i> <?php echo e($t->members); ?></small>
                  </div>
                </div>
              </div>
            </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php if($n==0): ?>
   <div class="box-shadow card mt-2"><p class="ml-2 pt-2"><b>Sorry!! You are not member of any Team.</b></p></div>
   <?php endif; ?> 
   </      </div>
          </div>
        </div> 
          </div>
      </div>
    </main>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript">
       function addteam() {
  $('#add-team').modal("show");
  $('.modal-backdrop').css('display','none');
  }
   function addboard() {
  $('#add-board').modal("show");
  $('.modal-backdrop').css('display','none');
  }
  function home() {
  $('#personal-board').css('display','block');
  $('#team-board').css('display','block');
  $('#my-team').css('display','block');
  }
  function personal_board() {
  $('#personal-board').css('display','block');
  $('#team-board').css('display','none');
  $('#my-team').css('display','none');
  }
  function team_board() {
  $('#team-board').css('display','block');
  $('#personal-board').css('display','none');
  $('#my-team').css('display','none');
  }
  function my_team() {
  $('#personal-board').css('display','none');
  $('#team-board').css('display','none');
  $('#my-team').css('display','block');
  }
    </script>
    <script type="text/javascript">
      $('#create-team').click(function () {
  $('#add-team-error').css('display','none');
  $('#add-team-success').css('display','none');
  if($('#add-team_name').val()!=''){
       $.ajax({
      type: 'POST',
      url: '<?php echo e(route('admin-addteam')); ?>',
      data: {
        '_token': $('input[name=_token]').val(),
        'teamname': $('#add-team_name').val()
      },
      success: function(data){
        if ((data.error)) {
     $('#add-team-error').html('** team name already exist.');
    $('#add-team-error').css('display','block');
        }
        else{
      $('#add-team-error').css('display','none');
      $('#add-team-success').css('display','block');
      $('#add-team_name').val('');
      }},
    });
  }
  else{
  $('#add-team-error').html('** Please enter team name.');
    $('#add-team-error').css('display','block');
    $('#add-team-success').css('display','none');
  }
});

   $('#add-board').click(function () {
  $('#add-board-error').css('display','none');
  $('#add-board-success').css('display','none');
  if($('#add-board_name').val()!=''){
       $.ajax({
      type: 'POST',
      url: '<?php echo e(route('admin-addboard')); ?>',
      data: {
        '_token': $('input[name=_token]').val(),
        'title': $('#add-board_name').val(),
      },
      success: function(data){
        if ((data.error)) {
     $('#add-board-error').html('** Board name already exist.');
    $('#add-board-error').css('display','block');
        }
        else{
      $('#add-board-error').css('display','none');
      $('#add-board-success').css('display','block');
      $('#add-board_name').val('');
      }},
    });
  }
  else{
  $('#add-member-error').html('** Please enter Board name.');
    $('#add-member-error').css('display','block');
    $('#add-member-success').css('display','none');
  }
});


    </script>
    <style type="text/css">
      .sidebar {
  list-style-type:none;
  background-color:#333;
  width: 100%;
  height:100%;
  top:0;
  bottom:0;
  left:0;
  text-align:left;
  position: absolute;
  margin: 0;
  padding: 0;
  list-style: none;
  transition:1s ease;
}

.sidebar a {
  text-decoration:none;
  color:white;
  transition:1s ease;
}

.sidebar li {
  text-indent: 20px;
  line-height: 40px;
  transition:0.5s ease;
}

.sidebar li:hover {
  background-color:#777;
  cursor:pointer;
  text-indent: 30px;
}

.sidebar > .sidebar-brand {
height: 65px;
font-size: 18px;
line-height: 60px;
}
.album{
  height: 100vh;
}
  .modal-backdrop.in{
    opacity: 0;
  }
.signup_div{
text-align: center;
width: 90%;
margin-left: 5%;
 margin-top: 10px;
 padding: 20px;
 color: #fff;
 background-color: #31b0d5;
  box-shadow: 0 14px 28px rgba(0,0,0,0.35), 0 10px 10px rgba(0,0,0,0.32);
}
.container{
  border-radius: 10px;
  position: relative;
  overflow: hidden;
  width:1200px;
  max-width: 100%;
}

.form-container form {
  background: #fff;
  display: flex;
  flex-direction: column;
  padding: 0 5%;
  width: 100%;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.form-container input {
  background: #eee;
  border: none;
  padding: 12px 15px;
  margin: 8px 0;
  width: 100%;
}
button {
  border-radius: 20px;
  border: 1px solid #ff4b2b;
  background: #ff4b2b;
  color: #fff;
  font-size: 12px;
  font-weight: bold;
  padding: 12px 45px;
  letter-spacing: 1px;
  text-transform: uppercase;
  transition: transform 80ms ease-in;
}
button:active {
  transform: scale(0.95);
}
button:focus{
  outline: none;
}
button.ghost{
  background: transparent;
  border-color: #fff;
}
.form-container{
  top: 0;
  transition: all 0.6s ease-in-out;
}

</style>
</body>
</html>
    
