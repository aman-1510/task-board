<html>
<head>
<title>Inspire Academy || IIT-JEE, NEET & MHT-CET</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Best success rate in all over maharashtra in JEE, NEET, CET & Olympiads.Inspire Academy achieves more than 80% selections from classroom courses and crash courses each year.Branches : Kolhapur,Karad & Satara
Add.: 2nd floor,Tathastu Corner,Shahupuri,Opp.railway Gate-416001 Contact:7972961299">
<meta name="keywords" content="inspire kolhapur, inspire, inspire Academy, inspire portal, inspirekolhapur, inspirekolhapur.com">
<link rel="canonical" href="https://inspirekolhapur.in" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico')); ?>"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- css files -->
<link href="<?php echo e(asset('website/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/team.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('website/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
<link href="<?php echo e(asset('website/css/sidebar.css')); ?>" rel="stylesheet" type="text/css" media="all"/>

<!-- /css files -->

<!-- js files -->
<script
  src="https://code.jquery.com/jquery-2.2.4.js"></script>
<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
<!-- /js files -->
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
<!-- navigation -->
<header>
    
  <div id="menu-header-container" class="page-header">
    <div id="menu-header-container-wrapper" class="page-header-wrapper">
      <div class="hamburger-wrapper">
        <a id="menu-hamburger-menu" class="hamburger-menu" href="#" title="Menu">
          <span class="line line-1"></span>
          <span class="line line-2"></span>
          <span class="line line-3"></span>
        </a>
      </div>
    </div>
  </div>

  <div id="menu" class="sidebar">
    <div id="menu-wrapper" class="sidebar-wrapper">
      <ul id="home">
        <li><a data-id="<?php echo e(route('home')); ?>" class="sidelink"><i class="fa fa-home"></i> Home</a></li>
       
         <li><a class="sidelink" data-id="<?php echo e(route('about_us')); ?>" ><i class="fa fa-edit"></i> About Us</a></li>
         <li><a class="sidelink" data-id="<?php echo e(route('gallery')); ?>"><i class="fa fa-image"></i> Gallery</a></li>
        <li><a class="sidelink" data-id="<?php echo e(route('team')); ?>" ><i class="fa fa-file"></i> Our Faculty</a></li>
        <li><a class="sidelink" data-id="<?php echo e(route('faq')); ?>"><i class="fa fa-location-arrow"></i> Faq's</a></li>
        <li><a class="sidelink" data-id="<?php echo e(route('student-form')); ?>"><i class="fa fa-sign-in"></i> Login</a></li>
        <li class="section"><i class="fa fa-book"></i> Courses</li>
        <li><a class="sidelink" data-id="<?php echo e(route('regular_courses')); ?>"><i class="fa fa-book"></i> Regular Batch</a></li>
        <li><a class="sidelink" data-id="<?php echo e(route('foundation_courses')); ?>"><i class="fa fa-book"></i> Foundation Batch</a></li>
          

      </ul>
    </div>
  </div>

            <div class="container-fluid " >
                <div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
                    <!-- logo -->
                    <div id="logo" style="padding: 10px;">
                        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.jpg')); ?>"></a>
                    </div>
                    <!-- //logo -->
                    <!-- nav -->
                    <div class="nav">
                        <nav>
                            <input type="checkbox" id="drop" />
                            <ul class="menu" style="color: #777; `margin-top: 5px;">
                                <li><a class="active" href="<?php echo e(route('home')); ?>" > Home </a></li>
                                <li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
                                <li>
                                    <!-- First Tier Drop Down -->
                                    <label for="drop-2" class="toggle toogle-2">Courses <span class="fa fa-angle-down" aria-hidden="true"></span>
                                    </label>
                                    <a href="#">Courses <span class="fa fa-angle-down" aria-hidden="true"></span></a>
                                    <input type="checkbox" id="drop-2" />
                                    <ul>
                                    <li><a href="<?php echo e(route('regular_courses')); ?>" class="drop-text">Regular Batch</a></li>
                                    <li><a href="<?php echo e(route('foundation_courses')); ?>" class="drop-text">Foundation Batch</a></li>
                                    </ul>
                                </li>
                                    <li><a href="<?php echo e(route('faq')); ?>" class="drop-text">Faq's</a></li>
                                        <li><a href="<?php echo e(route('gallery')); ?>" class="drop-text">Gallery</a></li>
    
                                        <li><a href="<?php echo e(route('team')); ?>" class="drop-text">Our Faculty</a></li>
                                <li><a href="<?php echo e(route('student-form')); ?>">Log In</a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- //nav -->
                </div>
            </div>
        </header>
<!-- /navigation -->
  <div class="col-lg-2"></div>
   <div class="col-md-8 about-in text-center" style="padding: 15px 15px 15px 15px; ">
                    <div class="card" style="padding-bottom: 90px;">
                        <div class="card-body"style="font-size: 15px;">
                            <h2 style="margin-top: 30px; text-align: center;">Thank You For Enquiry.</h2>
    <h4 style="margin-top: 20px; text-align: center;"> Our Enquiry Team Contact You ASAP.</h4>
                          <div class="col-lg-4"></div>
                                <div class="col-md-4" style="margin-top: 20px">
                                    <a type="submit" href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-block col-md-4">home</a>
                                </div>
                    <div class="col-lg-4"></div>
                              </div>
                    </div>
                </div>
    <div class="col-lg-2"></div>                    

<div class="wsk-float">
  <a onclick="login()" class="pulse-button">Login
  </a>
</div>
<!-- /Footer Section -->
<!-- js files -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/SmoothScroll.min.js')); ?>"> </script>
<!-- js for banner -->
<script src="<?php echo e(asset('js/index.js')); ?>"></script>
<!-- /js for banner -->
<!-- js for gallery -->
<script src="<?php echo e(asset('js/darkbox.js')); ?>"></script>
<!-- /js for gallery -->
<!-- js for smooth navigation -->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

  // Store hash
  var hash = this.hash;

  // Using jQuery's animate() method to add smooth page scroll
  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
  $('html, body').animate({
    scrollTop: $(hash).offset().top
  }, 900, function(){

    // Add hash (#) to URL when done scrolling (default click behavior)
    window.location.hash = hash;
    });
  });
})
</script>
<!-- /js for smooth navigation -->
<!-- js for sliding animations -->
<script>
$(window).scroll(function() {
  $(".slideanim").each(function(){
    var pos = $(this).offset().top;

    var winTop = $(window).scrollTop();
    if (pos < winTop + 600) {
      $(this).addClass("slide");
    }
  });
});
</script>
<script type="text/javascript">
    $('.sidelink').click(function () {
        var id = $(this).data('id');
        location.href = id;
    });
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 3000);    
}
function login() {
    location.href="<?php echo e(route('student-form')); ?>";
}
</script>

<script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function() {
  var self = this;
  this.elements = {
    header: {
      container: function() {
        return document.getElementById("menu-header-container");
      },
      hamburgerMenu: function() {
        return document.getElementById("menu-hamburger-menu");
      }
    },
    sidebar: {
      overlay: function() {
        return document.getElementById("menu");
      },
      wrapper: function() {
        return document.getElementById("menu-wrapper");
      }
    }
  };
  this.binds = function() {
    var sideLinks = document.querySelectorAll(".sidebar-wrapper li a");
  
    // Changes header colour after scrolled by 100px
    window.addEventListener("scroll", function(e) {
      var scrollTop =
        window.pageYOffset !== undefined
          ? window.pageYOffset
          : (document.documentElement ||
              document.body.parentNode ||
              document.body
            ).scrollTop;
      if (scrollTop > 100) {
        if (self.elements.header.container()) {
          self.elements.header.container().classList.add("scrolled");
        }
      } else {
        if (self.elements.header.container()) {
          self.elements.header.container().classList.remove("scrolled");
        }
      }
    });

    // Hamburger menu
    if (this.elements.header.hamburgerMenu()) {
      self.elements.header
        .hamburgerMenu()
        .addEventListener("click", function(e) {
          e.preventDefault();

          this.classList.toggle("active");
          document.querySelector("body").classList.toggle("disable-scroll");
          self.elements.sidebar.overlay().classList.toggle("active");
          self.elements.sidebar.wrapper().classList.toggle("active");
          self.elements.header.container().classList.toggle("sidebar-open");
        });
    }

    // Hide sidebar when click target is not a link
    if (this.elements.sidebar.overlay()) {
      self.elements.sidebar.overlay().addEventListener("click", function(e) {
        e.preventDefault();

        document.querySelector("body").classList.remove("disable-scroll");
        if (e.target.tagName.toLowerCase() !== "a") {
          self.elements.header.hamburgerMenu().classList.remove("active");
          self.elements.sidebar.overlay().classList.remove("active");
          self.elements.sidebar.wrapper().classList.remove("active");
          self.elements.header.container().classList.remove("sidebar-open");
        }
      });
    }
  };

  this.binds();
});

</script>
</body>
</html>
